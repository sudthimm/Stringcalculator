/*
 * Created on Feb 7, 2005 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */
package com.itaas.util;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Date;

import com.itaas.dsmcc.base.DSMCCObject;

/**
 * @author krishna TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class DateSecondsFrom1970 extends DSMCCObject {

    protected long m__SecondsFrom1970;

    /**
     * @return Returns the m__SecondsFrom1970.
     */
    public long getSecondsFrom1970() {
        return this.m__SecondsFrom1970;
    }

    /**
     * @param secondsFrom1970
     *            The m__SecondsFrom1970 to set.
     */
    public void setSecondsFrom1970(final long secondsFrom1970) {
        this.m__SecondsFrom1970 = secondsFrom1970;
    }

    @Override
    public void dump(final PrintStream ps) throws IOException {
        this.setPrintWriter(ps);
        final Date currentTime = new Date();
        currentTime.setTime(this.m__SecondsFrom1970 * 1000);
        ps.println("m__SecondsFrom1970: " + this.m__SecondsFrom1970 + " (" + currentTime + ")");
    }

}
