/*
 * Created on Oct 15, 2004 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */
package com.itaas.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author developer TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class DateUtil {

    private static SimpleDateFormat m_sdf;
    static {
        DateUtil.m_sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss z");
    }

    public static String getString(final Date dt) {
        return DateUtil.m_sdf.format(dt);
    }
}
