/*
 * Created on Oct 15, 2004 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */
package com.itaas.util;

import java.io.PrintStream;

/**
 * @author developer TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class Indent {

    private static StringBuffer m_indent;

    private static StringBuffer m_oneLevel;

    private static int m_level;
    static {
        Indent.m_indent = new StringBuffer(16);
        Indent.m_oneLevel = new StringBuffer("  ");
        Indent.m_level = 1;
    }

    public static int increaseLevel() {
        Indent.m_indent.append(Indent.m_oneLevel);
        Indent.m_level++;
        return (Indent.m_indent.length());
    }

    public static int decreaseLevel() {
        final int iLength = Indent.m_indent.length();
        Indent.m_indent.delete(iLength - 2, iLength);
        Indent.m_level--;
        return (iLength - 2);
    }

    public static StringBuffer getIndent() {
        return Indent.m_indent;
    }

    public static void printIndented(final PrintStream ps, final String msg) {
        ps.println(Indent.m_indent + msg);
    }
}
