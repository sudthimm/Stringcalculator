// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.message.server;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum DSMCCServerMessageType {
    enUnknown_Message(0x0000),
    enServer_Session_Setup_Indication(0x8012),
    enServer_Session_Setup_Response(0x8013),
    enServer_Add_Resource_Request(0x8030),
    enServer_Add_Resource_Confirm(0x8031),
    enServer_Release_Request(0x8020),
    enServer_Release_Confirm(0x8021),
    enServer_Release_Indication(0x8022),
    enServer_Release_Response(0x8023),
    enServer_CFS_Request(0x8050),
    enServer_CFS_Confirm(0x8051),
    enServer_Status_Request(0x8060),
    enServer_Status_Confirm(0x8061),
    enServer_Status_Indication(0x8062),
    enServer_Status_Response(0x8063),
    enServer_Proceeding_Indication(0x8082),
    enServer_Connect_Indication(0x8092),
    enServer_Session_In_Progress(0x80b0);

    
    private static Map<Integer, DSMCCServerMessageType> reverseMap;
    
    static {
        reverseMap = new HashMap<Integer, DSMCCServerMessageType>();
        for (DSMCCServerMessageType type : EnumSet.allOf(DSMCCServerMessageType.class)) {
            reverseMap.put(type.getMessageType(), type);
        }
    }
    
    
    private int messageType;

    /**
     * 
     */
    DSMCCServerMessageType(int messageType) {
        this.messageType = messageType;
    }
    
    /**
     * 
     * @return
     */
    public int getMessageType() {
        return messageType;
    }
    
    /**
     * 
     * @param value
     * @return
     */
    public static DSMCCServerMessageType valueOf(int value) {
        return reverseMap.get(value);
    }

}
