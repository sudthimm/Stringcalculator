// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.message.client;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum DSMCCClientMessageType {
    enClient_Session_Setup_Request(0x4010),
    enClient_Session_Setup_Confirm(0x4011),
    enClient_Release_Request(0x4020),
    enClient_Release_Confirm(0x4021),
    enClient_Release_Indication(0x4022),
    enClient_Release_Response(0x4023),
    enClient_Status_Request(0x4060),
    enClient_Status_Confirm(0x4061),
    enClient_Status_Indication(0x4062),
    enClient_Status_Response(0x4063),
    enClient_Proceeding_Indication(0x4082),
    enClient_Connect_Request(0x4090),
    enClient_Session_In_Progress(0x40b0);

    private static Map<Integer, DSMCCClientMessageType> reverseMap;

    static {
        reverseMap = new HashMap<Integer, DSMCCClientMessageType>();
        for (DSMCCClientMessageType type : EnumSet.allOf(DSMCCClientMessageType.class)) {
            reverseMap.put(type.getMessageType(), type);
        }
    }

    private int messageType;

    /**
     * @param messageType
     */
    DSMCCClientMessageType(int messageType) {
        this.messageType = messageType;
    }

    /**
     * @return the messageType
     */
    public int getMessageType() {
        return this.messageType;
    }

    /**
     * @param value
     * @return
     */
    public static DSMCCClientMessageType valueOf(int value) {
        return reverseMap.get(value);
    }

}
