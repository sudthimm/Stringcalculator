package com.itaas.dsmcc.Pegasus;

/*
 * PegasusSSP.java Created on Sept 26, 2003, 04:04 PM
 */

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCOutputStream;

/**
 * Private data descriptors for Pegasus ISA SSP
 * 
 * @author chintan Desai.
 */
public class SSPDescriptor extends DSMCCObject {

    /**
     * Defined Private Data Descriptor tags All other tag values are unknown.
     */
    public static final short AssetIdDescTag = 1;

    public static final short NodeGroupDescTag = 2;

    public static final short IpDescTag = 3;

    public static final short StreamHandleDescTag = 4;

    public static final short AppReqDataDescTag = 5;

    public static final short AppRspDataDescTag = 6;

    public static final short MystroSessionIDDescTag = 0xb8;

    public static final short DVDChapterDescTag = 0xbd;

    public static final short DurationDescTag = 0xb3;

    protected short m__Tag = 0;

    protected short m__DescriptorLength = 0;

    /**
     * Creates a new instance of SSPDescriptor
     * 
     * @param tag
     *            the private data descriptor tag.
     */
    public SSPDescriptor(final short tag, final int length) {
        this.m__Tag = tag;
        this.m__DescriptorLength = (short) length;
    }

    /**
     * Get the private data descriptor tag.
     * 
     * @return the private data descriptor tag.
     */
    public short getTag() {
        return this.m__Tag;
    }

    /**
     * Set the private data descriptor tag.
     * 
     * @param tag
     *            the private data descriptor tag.
     */
    public void setTag(final short tag) {
        this.m__Tag = tag;
    }

    /**
    *
    */
    public int getDescriptorLength() {
        return this.m__DescriptorLength;
    }

    /*
    *
    */
    // public void setDescriptorLength(int LengthVal)
    // {
    // m__DescriptorLength = LengthVal;
    // }

    /**
    *
    */
    public int getTotalLength() {
        // Add 2 for the tag and length bytes.
        return this.m__DescriptorLength + 2;
    }

    /**
    *
    */
    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 2;
        dos.writeUByte(this.m__Tag);
        dos.writeUByte(this.m__DescriptorLength);
        iRet += this.write(this, dos);

        return iRet;
    }

}
