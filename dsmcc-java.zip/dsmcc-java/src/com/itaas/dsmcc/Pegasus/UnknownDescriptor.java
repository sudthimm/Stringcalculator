package com.itaas.dsmcc.Pegasus;

/*
 * Created on Aug 30, 2004 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */

/**
 * @author krishna TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */


/**
 * @author chintan Desai
 */
public class UnknownDescriptor extends ByteArrayDescriptor {

    public static final byte Tag = 0x00;

    /** Creates a new instance of PegasusAssetIDDescriptor */
    public UnknownDescriptor(final short LengthVal) {
        // FIXME we should not force the tag to zero.
        super(UnknownDescriptor.Tag, LengthVal);
    }

}
