package com.itaas.dsmcc.Pegasus;

/*
 * ByteArrayDescriptor.java Created on August 12, 2003, 12:08 PM
 */

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * @author chintan Desai
 */
public class ByteArrayDescriptor extends SSPDescriptor {

    protected ByteArray m__Data;

    /**
     * Creates a new instance of PegasusAssetIDDescriptor
     */
    public ByteArrayDescriptor(final short tagVal, final int LengthVal) {
        super(tagVal, LengthVal);
    }

    /**
    *
    */
    public void setData(final ByteArray valData) {
        this.m__Data = valData;
        this.m__DescriptorLength = (short) this.m__Data.getLength();
    }

    /**
    *
    */
    public ByteArray getData() {
        return this.m__Data;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__Data = new ByteArray(this.m__DescriptorLength, ByteArray.EMPTY);
        iRet += this.m__Data.read(dis);

        return iRet;
    }
}
