package com.itaas.dsmcc.Pegasus;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;

public class DVDChapterSSPDescriptor extends SSPDescriptor {

    long m__NPT;

    ByteArray m__ChapterId;

    public static final short Tag = SSPDescriptor.DVDChapterDescTag;

    /** Creates a new instance of DVDChapter Descriptor */
    public DVDChapterSSPDescriptor(final int LengthVal) {
        super(DVDChapterSSPDescriptor.Tag, LengthVal);
    }

    public void setNPT(final long millis) {
        this.m__NPT = millis;
    }

    public long getNPT() {
        return this.m__NPT;
    }

    public void setChapterId(final ByteArray valChapterId) {
        this.m__ChapterId = valChapterId;
        this.m__DescriptorLength = (short) (this.m__ChapterId.getLength() + 4);
    }

    public ByteArray getChapterId() {
        return this.m__ChapterId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        // Skip 2 bytes as last 4 bytes of 6 byes are the node group
        // dis.readUShort();
        // iRet += 2;

        this.m__NPT = dis.readUInteger();
        iRet += 4;
        this.m__ChapterId = new ByteArray((this.m__DescriptorLength - 4), ByteArray.EMPTY);
        iRet += this.m__ChapterId.read(dis);

        return iRet;
    }
}
