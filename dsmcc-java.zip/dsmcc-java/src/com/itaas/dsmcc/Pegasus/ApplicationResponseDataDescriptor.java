package com.itaas.dsmcc.Pegasus;

/*
 * ApplicationResponseDataDescriptor.java Created on August 12, 2003, 5:17 PM
 */

/**
 * @author Chintan Desai
 */
public class ApplicationResponseDataDescriptor extends ByteArrayDescriptor {

    public static final byte Tag = SSPDescriptor.AppRspDataDescTag;

    /**
     * Creates a new instance of PegasusApplicationResponseDataDescriptor
     */
    public ApplicationResponseDataDescriptor(final short LengthVal) {
        super(ApplicationResponseDataDescriptor.Tag, LengthVal);
    }

}
