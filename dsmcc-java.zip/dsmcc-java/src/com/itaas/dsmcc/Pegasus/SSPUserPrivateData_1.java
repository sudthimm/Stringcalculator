// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Sept 26, 2003 , 4:40 PM
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.Pegasus;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCOutputStream;
import com.itaas.dsmcc.base.DSMCCQueue;

/**
 * TODO see if there is a way to subclass SSPUserPrivateData_1 and SSPUserPrivateData_2 from a parent class
 * with common data members Also, this would allow SSPDescriptorFactory to return the parent class and narrow
 * down the scope from all the potential sublclasses of DSMCCObject.
 * 
 * @author Krishna C Tripathi
 */
public class SSPUserPrivateData_1 extends DSMCCObject {

    private short m__Protocol;

    private short m__Version;

    private DSMCCQueue m__ServiceData;

    public SSPUserPrivateData_1() {
        this.m__Protocol = 0x01;
        this.m__Version = 0x01;
        this.m__ServiceData = new DSMCCQueue(DSMCCQueue.UNSIGNED_BYTE, null);
    }

    public SSPUserPrivateData_1(final ByteArray upData) throws IOException {
        // make a stream
        final ByteArrayInputStream bis = new ByteArrayInputStream(upData.getBytes());
        final DSMCCInputStream dis = new DSMCCInputStream(bis);
        this.read(dis);
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__Protocol = dis.readUByte();
        iRet += 1;

        this.m__Version = dis.readUByte();
        iRet += 1;

        final short cnt = dis.readUByte();
        iRet += 1;
        this.m__ServiceData = new DSMCCQueue(DSMCCQueue.UNSIGNED_BYTE, null);
        final int[] iRead = new int[1];
        iRead[0] = 0;
        while (dis.available() > 0) {
            final SSPDescriptor obj = SSPDescriptorFactory.create(dis, iRead);
            iRet += iRead[0];
            if (obj == null) {
                break;
            }
            this.m__ServiceData.add(obj);
        }

        return iRet;
    }

    public short getProtocol() {
        return this.m__Protocol;
    }

    public void setProtocol(final short valProtocol) {
        this.m__Protocol = valProtocol;
    }

    public short getVersion() {
        return this.m__Version;
    }

    public void setVersion(final short valVersion) {
        this.m__Version = valVersion;
    }

    public DSMCCQueue getServiceData() {
        return this.m__ServiceData;
    }

    public void setServiceData(final DSMCCQueue valServiceData) {
        this.m__ServiceData = valServiceData;
    }

    public int addResource(final SSPDescriptor res) {
        this.m__ServiceData.add(res);
        return this.m__ServiceData.size();
    }

    ByteArray getBytes() {
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final DSMCCOutputStream dos = new DSMCCOutputStream(bos);
        try {
            this.write(dos);
        } catch (final IOException ex) {
        }
        return new ByteArray(bos.toByteArray());
    }
}
