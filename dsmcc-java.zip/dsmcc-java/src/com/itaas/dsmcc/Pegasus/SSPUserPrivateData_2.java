// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Sept 26, 2003 , 4:30 PM
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.Pegasus;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCOutputStream;
import com.itaas.dsmcc.base.DSMCCQueue;

/**
 * @author Krishna C Tripathi
 */
public class SSPUserPrivateData_2 extends DSMCCObject {

    // 16 bytes of zeros for EmptyServiceGateway
    public static ByteArray EmptyServiceGateway = new ByteArray(16, ByteArray.EMPTY);

    // 16 bytes of zeros for EmptyServiceG
    public static ByteArray EmptyService = new ByteArray(16, ByteArray.EMPTY);

    // Zero(0) bytes for NoService
    // public static ByteArray NoService = new ByteArray(0, ByteArray.EMPTY);

    private short m__Protocol;

    private short m__Version;

    private ByteArray m__ServiceGateway = SSPUserPrivateData_2.EmptyServiceGateway;

    private long m__ServiceGatewayDataLength = 0;

    private ByteArray m__Service = null; // NoService;

    private long m__ServiceLength = 0;

    private DSMCCQueue m__ServiceData;

    /**
    * 
    */
    public SSPUserPrivateData_2() {
        this.m__Protocol = 0x02;
        this.m__Version = 0x01;
        this.m__ServiceData = new DSMCCQueue(DSMCCQueue.UNSIGNED_BYTE, null);
    }

    /**
    * 
    */
    public SSPUserPrivateData_2(final ByteArray upData) throws IOException {
        // make a stream
        final ByteArrayInputStream bis = new ByteArrayInputStream(upData.getBytes());
        final DSMCCInputStream dis = new DSMCCInputStream(bis);
        this.read(dis);
    }

    /**
    * 
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__Protocol = dis.readUByte();
        iRet += 1;

        this.m__Version = dis.readUByte();
        iRet += 1;

        // 
        // Create byte array of size 16
        this.m__ServiceGateway = new ByteArray(16, ByteArray.EMPTY);
        this.m__ServiceGateway.read(dis);
        iRet += 16;

        this.m__ServiceGatewayDataLength = dis.readUInteger();
        iRet += 4;

        // Create byte array of size 16
        this.m__Service = new ByteArray(16, ByteArray.EMPTY);
        this.m__Service.read(dis);
        iRet += 16;

        this.m__ServiceLength = dis.readUInteger();
        iRet += 4;

        final short cnt = dis.readUByte();
        this.m__ServiceData = new DSMCCQueue(DSMCCQueue.UNSIGNED_BYTE, null);
        final int[] iRead = new int[1];
        iRead[0] = 0;
        // for ( int iCnt =0 ; iCnt < cnt ; iCnt++)
        while (dis.available() > 0) {
            final SSPDescriptor obj = SSPDescriptorFactory.create(dis, iRead);
            iRet += iRead[0];
            if (obj == null) {
                break;
            }
            this.m__ServiceData.add(obj);
        }

        return iRet;
    }

    /**
    * 
    */
    public short getProtocol() {
        return this.m__Protocol;
    }

    /**
    * 
    */
    public void setProtocol(final short valProtocol) {
        this.m__Protocol = valProtocol;
    }

    /**
    * 
    */
    public short getVersion() {
        return this.m__Version;
    }

    /**
    * 
    */
    public void setVersion(final short valVersion) {
        this.m__Version = valVersion;
    }

    /**
    * 
    */
    public ByteArray getServiceGateway() {
        return this.m__ServiceGateway;
    }

    /**
    * 
    */
    public void setServiceGateway(final ByteArray valServiceGateway) {
        this.m__ServiceGateway = valServiceGateway;
    }

    /**
    * 
    */
    public long getServiceGatewayDataLength() {
        return this.m__ServiceGatewayDataLength;
    }

    /**
    * 
    */
    public void setServiceGatewayDataLength(final long valServiceGatewayDataLength) {
        this.m__ServiceGatewayDataLength = valServiceGatewayDataLength;
    }

    /**
    * 
    */
    public ByteArray getService() {
        return this.m__Service;
    }

    /**
    * 
    */
    public void setService(final ByteArray valService) {
        this.m__Service = valService;
    }

    /**
    * 
    */
    public long getServiceLength() {
        return this.m__ServiceLength;
    }

    /**
    * 
    */
    public void setServiceLength(final long valServiceLength) {
        this.m__ServiceLength = valServiceLength;
    }

    /**
    * 
    */
    public DSMCCQueue getServiceData() {
        return this.m__ServiceData;
    }

    /**
    * 
    */
    public void setServiceData(final DSMCCQueue valServiceData) {
        // FIXME adjust the values of
        // m__ServiceLength
        // m__ServiceGatewayDataLength = m__ServiceLength + 20.
        // For each element in the queue
        // element.getLength(); (from DSMCCObject).
        this.m__ServiceData = valServiceData;
    }

    /**
    * 
    */
    public int addDescriptor(final SSPDescriptor desc) {
        if (desc != null) {
            this.m__ServiceData.add(desc);
            this.m__ServiceLength += desc.getTotalLength();
            if (this.m__Service == null) {
                this.m__Service = SSPUserPrivateData_2.EmptyService;
            }
            // Add 20 for size of Service (16) and size of the ServiceLength (4).
            this.m__ServiceGatewayDataLength = this.m__ServiceLength + 20;
        }
        return this.m__ServiceData.size();
    }

    /**
    * 
    */
    ByteArray getBytes() {
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final DSMCCOutputStream dos = new DSMCCOutputStream(bos);
        try {
            this.write(dos);
        } catch (final IOException ex) {
        }
        return new ByteArray(bos.toByteArray());
    }

}
