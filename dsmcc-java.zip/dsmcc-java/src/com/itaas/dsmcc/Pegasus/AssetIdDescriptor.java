package com.itaas.dsmcc.Pegasus;

/*
 * PegasusAssetIDDescriptor.java Created on August 12, 2003, 12:08 PM
 */

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * TODO make this a ByteArrayDescriptor and map the string AssetId into the byte array.
 * 
 * @author chintan Desai
 */
public class AssetIdDescriptor extends SSPDescriptor {

    protected ByteArray m__AssetId;

    public static final byte Tag = SSPDescriptor.AssetIdDescTag;

    /**
     * Creates a new instance of PegasusAssetIDDescriptor
     */
    public AssetIdDescriptor(final int LengthVal) {
        super(AssetIdDescriptor.Tag, LengthVal);
    }

    /**
    *
    */
    public void setAssetId(final ByteArray valAssetId) {
        this.m__AssetId = valAssetId;
        this.m__DescriptorLength = (short) this.m__AssetId.getLength();
    }

    /**
    *
    */
    public ByteArray getAssetId() {
        return this.m__AssetId;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__AssetId = new ByteArray(this.m__DescriptorLength, ByteArray.EMPTY);
        iRet += this.m__AssetId.read(dis);

        return iRet;
    }
}
