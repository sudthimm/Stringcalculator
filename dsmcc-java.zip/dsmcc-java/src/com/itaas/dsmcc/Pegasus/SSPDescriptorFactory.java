/*
 * PegasusSSP.java Created on August 12, 2003, 11:04 AM
 */

package com.itaas.dsmcc.Pegasus;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;

/**
 * @author chintan Desai.
 */
public class SSPDescriptorFactory extends DSMCCObject {

    /**
     * Creates a new instance of PegasusSSP
     */
    private SSPDescriptorFactory() {
    }

    public static SSPDescriptor create(final DSMCCInputStream dis, final int[] IRead) throws IOException {
        SSPDescriptor obj = null;
        int iRead = 0;
        short tag;
        short length;

        try {

            tag = dis.readUByte();
            iRead++;
            length = dis.readUByte();
            iRead++;

            switch (tag) {
                case 0x01: {
                    obj = new AssetIdDescriptor(length);
                    break;
                }
                case 0x02: {
                    obj = new NodeGroupIdDescriptor(length);
                    break;
                }
                case 0x03: {
                    obj = new IPDescriptor(length);
                    break;
                }
                case 0x04: {
                    obj = new StreamHandleDescriptor(length);
                    break;
                }
                case 0x05: {
                    obj = new ApplicationRequestDataDescriptor(length);
                    break;
                }
                case 0x06: {
                    obj = new ApplicationResponseDataDescriptor(length);
                    break;
                }
                default: {
                    final UnknownDescriptor unobj = new UnknownDescriptor(length);
                    unobj.setTag(tag);
                    obj = unobj;
                }
            } // end of switch

            if (obj != null) {
                if (dis.available() >= length) {
                    iRead += obj.read(dis);
                } else {
                    obj = null;
                }
            } // end of if
        } // end of try
        catch (final IOException ex) {

        }
        IRead[0] = iRead;

        return obj;
    } // end of method

    public static DSMCCObject createUserPrivateData(final ByteArray bytesA) throws IOException {
        final byte[] bytes = bytesA.getBytes();
        if ((bytes != null) && (bytes.length > 0)) {
            // read the first byte
            final int iProtocol = bytesA.getBytes()[0];
            if (iProtocol == 2) {
                return new SSPUserPrivateData_2(bytesA);
            } else if ((iProtocol == 1) /* SSP1 */
                    || (iProtocol == 0x68) /* Concurrent */) {
                return new SSPUserPrivateData_1(bytesA);
            } else {
                return null;
            }
        } else {
            return null;
        }

    }

}
