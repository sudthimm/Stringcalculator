package com.itaas.dsmcc.Pegasus;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

public class DurationSSPDescriptor extends SSPDescriptor {

    long m__TimeLenInMillis;

    public static final short Tag = SSPDescriptor.DurationDescTag;

    /** Creates a new instance of NodeGroupIDDescriptor */
    public DurationSSPDescriptor(final int LengthVal) {
        super(SSPDescriptor.DurationDescTag, LengthVal);
    }

    public void setTimeLenInMilliSecs(final long millis) {
        this.m__TimeLenInMillis = millis;
    }

    public long getTimeLenInMilliSecs() {
        return this.m__TimeLenInMillis;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        // Skip 2 bytes as last 4 bytes of 6 byes are the node group
        // dis.readUShort();
        // iRet += 2;

        this.m__TimeLenInMillis = dis.readUInteger();
        iRet += 4;

        return iRet;
    }
}
