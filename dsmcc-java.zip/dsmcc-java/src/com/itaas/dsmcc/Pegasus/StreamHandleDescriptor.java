package com.itaas.dsmcc.Pegasus;

/*
 * StreamHandleDescriptor.java Created on August 12, 2003, 4:35 PM
 */
import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * @author chintan Desai
 */
public class StreamHandleDescriptor extends SSPDescriptor {

    long m__StreamHandle;

    public static final byte Tag = SSPDescriptor.StreamHandleDescTag;

    /**
     * Creates a new instance of StreamHandleDescriptor
     */
    public StreamHandleDescriptor(final int LengthVal) {
        super(StreamHandleDescriptor.Tag, 4);
        // FIXME this forces a length value, we should validate the length.
        // super(Tag, LengthVal);
    }

    /**
    *
    */
    public void setStreamHandle(final long valStreamHandle) {
        this.m__StreamHandle = valStreamHandle;
    }

    /**
    *
    */
    public long getStreamHandle() {
        return this.m__StreamHandle;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__StreamHandle = dis.readUInteger();
        iRet += 4;

        return iRet;
    }

}
