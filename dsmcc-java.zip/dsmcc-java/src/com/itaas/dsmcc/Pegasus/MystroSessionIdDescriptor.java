/*
 * NodeGroupIDDescriptor.java Created on August 12, 2003, 3:11 PM
 */

package com.itaas.dsmcc.Pegasus;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * @author chintan Desai
 */
public class MystroSessionIdDescriptor extends SSPDescriptor {

    long m__MystroId;

    public static final short Tag = SSPDescriptor.MystroSessionIDDescTag;

    /** Creates a new instance of NodeGroupIDDescriptor */
    public MystroSessionIdDescriptor(final int LengthVal) {
        super(MystroSessionIdDescriptor.Tag, LengthVal);
    }

    public void setMystroId(final long valMystroId) {
        this.m__MystroId = valMystroId;
    }

    public long getMystroId() {
        return this.m__MystroId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        // Skip 2 bytes as last 4 bytes of 6 byes are the node group
        // dis.readUShort();
        // iRet += 2;

        this.m__MystroId = dis.readUInteger();
        iRet += 4;

        return iRet;
    }

}
