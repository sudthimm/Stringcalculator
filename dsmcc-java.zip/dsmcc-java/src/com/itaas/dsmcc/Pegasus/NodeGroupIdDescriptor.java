package com.itaas.dsmcc.Pegasus;

/*
 * NodeGroupIDDescriptor.java Created on August 12, 2003, 3:11 PM
 */

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * @author chintan Desai
 */
public class NodeGroupIdDescriptor extends SSPDescriptor {

    // int m__Unused; // 2 bytes unused
    long m__NodeGroupId;

    public static final byte Tag = 0x02;

    /** Creates a new instance of NodeGroupIDDescriptor */
    public NodeGroupIdDescriptor(final int LengthVal) {
        super(NodeGroupIdDescriptor.Tag, 6);
        // super(Tag, LengthVal);
    }

    /**
    *
    */
    public void setNodeGroupId(final long val) {
        this.m__NodeGroupId = val;
    }

    /**
    *
    */
    public long getNodeGroupId() {
        return this.m__NodeGroupId;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        // Skip 2 bytes as last 4 bytes of 6 byes are the node group
        dis.readUShort();
        iRet += 2;

        this.m__NodeGroupId = dis.readUInteger();
        iRet += 4;

        return iRet;
    }
}
