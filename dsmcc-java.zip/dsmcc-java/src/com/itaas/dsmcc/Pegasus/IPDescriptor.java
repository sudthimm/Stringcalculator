package com.itaas.dsmcc.Pegasus;

/*
 * IPDescriptor.java Created on August 12, 2003, 3:30 PM
 */

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.IpAddress;

/**
 * @author chintan Desai
 */
public class IPDescriptor extends SSPDescriptor {

    int m__Port; // 2 bytes

    IpAddress m__IPAddress; // 4 bytes

    public static final byte Tag = SSPDescriptor.IpDescTag;

    /** Creates a new instance of IPDescriptor */
    public IPDescriptor(final int LengthVal) {
        // This constructor is just so that it looks consistent with others
        super(IPDescriptor.Tag, LengthVal);
        // m__DescriptorLength = 4;
        // m__Tag = Tag;
    }

    /**
    *
    */
    public void setPort(final int valPort) {
        this.m__Port = valPort;
    }

    /**
    *
    */
    public int getPort() {
        return this.m__Port;
    }

    /**
    *
    */
    public void setIPAddress(final IpAddress valIPAddress) {
        this.m__IPAddress = valIPAddress;
    }

    /**
    *
    */
    public IpAddress getIPAddress() {
        return this.m__IPAddress;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;
        // Read the port
        this.m__Port = dis.readUShort();
        iRet += 2;
        // Read the ip address
        this.m__IPAddress = new IpAddress();
        iRet += this.m__IPAddress.read(dis);

        return iRet;
    }
}
