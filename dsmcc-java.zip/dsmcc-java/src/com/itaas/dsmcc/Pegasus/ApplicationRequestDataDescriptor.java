package com.itaas.dsmcc.Pegasus;

/*
 * ApplicationRequestDataDescriptor.java Created on August 12, 2003, 5:03 PM
 */

/**
 * @author chintan.Desai
 */
public class ApplicationRequestDataDescriptor extends ByteArrayDescriptor {

    public static final byte Tag = SSPDescriptor.AppReqDataDescTag;

    /**
     * Creates a new instance of ApplicationRequestDataDescriptor
     */
    public ApplicationRequestDataDescriptor(final short LengthVal) {
        super(ApplicationRequestDataDescriptor.Tag, LengthVal);
    }

}
