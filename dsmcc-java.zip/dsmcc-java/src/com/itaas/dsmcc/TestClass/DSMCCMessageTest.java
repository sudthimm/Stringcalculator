/*
 * DSMCCMessageTest.java Created on July 9, 2003, 10:56 AM
 */

package com.itaas.dsmcc.TestClass;

import com.itaas.dsmcc.Pegasus.SSPDescriptor;
import com.itaas.dsmcc.Pegasus.SSPDescriptorFactory;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageFactory;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptor;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorFactory;

/**
 * @author chintan.desai
 */
public class DSMCCMessageTest extends DSMCCObject {

    static void testMessages() {
        try

        {
            final java.io.FileInputStream fis = new java.io.FileInputStream(
                    "z:\\isa\\src\\com\\itaas\\dsmcc\\TestClass\\Resources.bin");
            final DSMCCInputStream dis = new DSMCCInputStream(fis);

            while (dis.available() > 0) {
                final DSMCCMessage msg = DSMCCMessageFactory.create(dis);
                if (msg != null) {
                    msg.dump(System.out);
                }
                System.out.println("");
            }
            // DSMCCOutputStream dos = new DSMCCOutputStream( new ByteArrayOutputStream());
            // msg.write(dos);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

    }

    static void testResources(final String fileName) {
        try

        {
            final java.io.FileInputStream fis = new java.io.FileInputStream(fileName);
            final DSMCCInputStream dis = new DSMCCInputStream(fis);

            final int iSize = dis.readUnsignedShort();
            System.out.println("Number of resources=" + iSize);
            int iCnt = 0;
            while (dis.available() > 0) {
                final Integer iRead = new Integer(0);
                final DSMCCResourceDescriptor res = DSMCCResourceDescriptorFactory.create(dis, iRead);
                if (res != null) {
                    System.out.println("\nPrinting resource number: " + ++iCnt);
                    res.dump(System.out);
                }
            }
            // DSMCCOutputStream dos = new DSMCCOutputStream( new ByteArrayOutputStream());
            // msg.write(dos);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

    }

    static void testSSPResources(final String fileName) {
        try

        {
            final java.io.FileInputStream fis = new java.io.FileInputStream(fileName);
            final DSMCCInputStream dis = new DSMCCInputStream(fis);

            final int iSize = dis.readUnsignedShort();
            System.out.println("Number of resources=" + iSize);
            int iCnt = 0;
            while (dis.available() > 0) {
                final int[] iRead = new int[1];
                final SSPDescriptor res = SSPDescriptorFactory.create(dis, iRead);
                if (res != null) {
                    System.out.println("\nPrinting resource number: " + ++iCnt);
                    res.dump(System.out);
                }
            }
            // DSMCCOutputStream dos = new DSMCCOutputStream( new ByteArrayOutputStream());
            // msg.write(dos);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

    }

    public static void main(final String[] args) {
        // testResources(args[0]);

        DSMCCMessageTest.testSSPResources(args[0]);
    }
}
