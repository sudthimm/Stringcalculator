/*
 * Copyright iTaas, Inc. 2005 Created by krishna on Jun 27, 2005 No Portion of this file can be copied or
 * reproduced in any form without prior written approval. TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package com.itaas.dsmcc.TestClass;

// Import log4j classes.
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PatternLayout;

import com.itaas.dsmcc.base.*;
import com.itaas.dsmcc.client.DSMCCClientReleaseConfirm;
import com.itaas.dsmcc.client.DSMCCClientReleaseRequest;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpConfirm;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpRequest;
import com.itaas.dsmcc.server.*;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;
import com.itaas.dsmcc.resources.*;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * @author krishna
 */
public class SRMEmulator2 {

    static final int DSMCC_PORT = 13819;

    static Logger m_logger = Logger.getLogger("SRMEmulator");
    
    private DatagramSocket dsmccSocket;


    /**
	 * 
	 */
    public SRMEmulator2() {
        super();
        
    }
    
    public void init() {
        try {
            dsmccSocket = new DatagramSocket(DSMCC_PORT);
        } catch (SocketException exception) {
            exception.printStackTrace();
        }
    }

    public void run() {
        // Open a UDP dsmccSocket
        
       
        try {

            while (true) {
                byte packetDataBuffer[] = new byte[2048];
                DatagramPacket packet = new DatagramPacket(packetDataBuffer, packetDataBuffer.length);
                dsmccSocket.receive(packet);
                System.out.println("Recieved Message At: " + new Date(System.currentTimeMillis()));
                DSMCCMessage message = constructDSMCCMessage(packet);
                DSMCCMessage responseMessage = constructResponseMessage(message);

                if (responseMessage != null) {
                    sendResponse(packet, responseMessage);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }

    /**
     * @param packet
     * @param responseMessage
     * @throws IOException
     */
    private void sendResponse(DatagramPacket packet, DSMCCMessage responseMessage) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(2048);
        DSMCCOutputStream dos = new DSMCCOutputStream(baos);
        int iWrite = responseMessage.write(dos);
        byte bao[] = baos.toByteArray();
        DatagramPacket destinationPacket = new DatagramPacket(bao, iWrite, packet.getAddress(),
        packet.getPort());
        System.out.println("Sending Response At: " + new Date(System.currentTimeMillis()) + " to " + destinationPacket.getSocketAddress());
        responseMessage.dump(System.out);
        dsmccSocket.send(destinationPacket);
        System.out.println("Finished Sending Response At: " + new Date(System.currentTimeMillis()));
        System.out.println("\n\n\n\n\n\n");
    }
    
    private DSMCCMessage constructDSMCCMessage(DatagramPacket packet) throws IOException {
        DSMCCMessage message = null;
        System.out.println("Constructing DSMCC Message");
        ByteArrayInputStream inputStream = new ByteArrayInputStream(packet.getData(), 0, packet.getLength());
        DSMCCInputStream dsmccInputStream = new DSMCCInputStream(inputStream);
        message = DSMCCMessageFactory.create(dsmccInputStream);
        message.dump(System.out);
        System.out.println("Finished Constructing DSMCC Message");
        return message;
    }
    
    private DSMCCMessage constructResponseMessage(DSMCCMessage requestMessage) {
        DSMCCMessage responseMessage = null;
        DSMCCClientMessageType clientMessageType = DSMCCClientMessageType.valueOf(requestMessage.getMessageType());
        switch(clientMessageType) {
            case enClient_Session_Setup_Request:
                DSMCCClientSessionSetUpRequest sessionSetupRequestMessage = (DSMCCClientSessionSetUpRequest) requestMessage;
                DSMCCClientSessionSetUpConfirm sessionSetupConfirmationMessage = new DSMCCClientSessionSetUpConfirm(sessionSetupRequestMessage.getHeader());
                sessionSetupConfirmationMessage.setSessionID(sessionSetupRequestMessage.getSessionId());
                sessionSetupConfirmationMessage.setServerId(sessionSetupRequestMessage.getServerId());
                sessionSetupConfirmationMessage.setResponseCode(0);
                responseMessage = sessionSetupConfirmationMessage;
                break;
            case enClient_Release_Request:
                DSMCCClientReleaseRequest clientReleaseRequest = (DSMCCClientReleaseRequest) requestMessage;
                DSMCCClientReleaseConfirm clientReleaseConfirmation = new DSMCCClientReleaseConfirm(clientReleaseRequest.getHeader());
                clientReleaseConfirmation.setResponse(0);
                clientReleaseConfirmation.setSessionId(clientReleaseRequest.getSessionId());
                responseMessage = clientReleaseConfirmation;
                break;
        }
        return responseMessage; 
    }



    public static void main(String[] args) {
        SRMEmulator2 srmEmulator = new SRMEmulator2();
        srmEmulator.init();
        srmEmulator.run();
    }
}
