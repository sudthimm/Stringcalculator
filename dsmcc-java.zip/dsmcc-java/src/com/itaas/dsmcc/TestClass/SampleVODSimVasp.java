// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 12, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.TestClass;

// Import log4j classes.
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;
import java.util.Hashtable;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import com.itaas.dsmcc.Pegasus.DVDChapterSSPDescriptor;
import com.itaas.dsmcc.Pegasus.DurationSSPDescriptor;
import com.itaas.dsmcc.Pegasus.IPDescriptor;
import com.itaas.dsmcc.Pegasus.MystroSessionIdDescriptor;
import com.itaas.dsmcc.Pegasus.SSPUserPrivateData_1;
import com.itaas.dsmcc.Pegasus.SSPUserPrivateData_2;
import com.itaas.dsmcc.Pegasus.StreamHandleDescriptor;
import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCAdaptationHeader;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCMessageFactory;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCOutputStream;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.base.IpAddress;
import com.itaas.dsmcc.base.ResponseCode;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.resources.DSMCCHeadEndIdResourceDescriptor;
import com.itaas.dsmcc.resources.DSMCCMpegProgramResourceDescriptor;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorContainer;
import com.itaas.dsmcc.resources.DSMCCServiceGroupResourceDescriptor;
import com.itaas.dsmcc.resources.DSMCCTSDSBWResourceDescriptor;
import com.itaas.dsmcc.server.DSMCCServerAddResourceConfirm;
import com.itaas.dsmcc.server.DSMCCServerAddResourceRequest;
import com.itaas.dsmcc.server.DSMCCServerReleaseConfirm;
import com.itaas.dsmcc.server.DSMCCServerReleaseIndication;
import com.itaas.dsmcc.server.DSMCCServerReleaseRequest;
import com.itaas.dsmcc.server.DSMCCServerReleaseResponse;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpIndication;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpResponse;
import com.itaas.dsmcc.server.DSMCCServerStatusConfirm;
import com.itaas.dsmcc.server.DSMCCServerStatusIndication;
import com.itaas.dsmcc.server.DSMCCServerStatusRequest;

public class SampleVODSimVasp {

    // Define a static logger variable so that it references the
    // Logger instance named "MyApp".
    static final int DSMCC_PORT = 13819;

    static Logger m_logger = Logger.getLogger(SampleVODSimVasp.class);

    InetAddress m_dncsIp;

    InetAddress m_myIp;

    DSMCCNsapAddress m_myNsap;

    Socket m_dncsSock;

    DSMCCInputStream m_dis;

    DSMCCOutputStream m_dos;

    // This map will use the bytes from session id as key
    Hashtable m_sessionInfoTable;

    // Variable to get unique transaction ids
    int m_txnId;

    int m_pgmNumber;

    // Error percent: This is the value specifying how many errors we want to
    // produce. This will be helpful in testing
    float m_errorPercent;

    int m_tsIDOut;

    int m_tsIDIn;

    int m_ISA = 0;

    int[] m_tsIDOutArray = { 6013, 6014, 6015 };

    int[] m_tsIDInArray = { 6003, 6004, 6005 };

    int m_tsIDInIndex = 0;

    int m_tsIDOutIndex = 0;

    int m_tsIDIndex = 0;

    boolean bSecondSetIPPort = false;

    int VODServerPort = 10000;

    long StreamHandle = 1;

    int count = 0;

    // A Private class to maintain the TxnId and last_msg time for each session
    class SessionInfo {

        DSMCCServerSessionSetUpIndication m_indicationMsg;

        Date m_lastMsg;

        public SessionInfo(final DSMCCServerSessionSetUpIndication indicationMsg)

        {
            this.m_indicationMsg = indicationMsg;
            this.updateTime();
        }

        public void updateTime() {
            this.m_lastMsg = new Date();
        }
    }

    private static void setLogger() {
        /*
         * String pattern = "Milliseconds since program start: %r %n"; pattern +=
         * "Classname of caller: %C %n"; pattern += "Date in ISO8601 format: %d{ISO8601} %n"; pattern +=
         * "Location of log event: %l %n"; pattern += "Message: %m %n %n"; The above pattrern will generate
         * logs like this, =============================================== Milliseconds since program start: 0
         * Classname of caller: consandpatt Date in ISO8601 format: 2002-08-16 14:58:30,393 Location of log
         * event: consandpatt.main(consandpatt.java:22) Message: Here is some DEBUG
         * ===============================================
         */
        final String pattern = "%d{ISO8601}";
        final PatternLayout layout = new PatternLayout(pattern);
        final ConsoleAppender appender = new ConsoleAppender(layout);
        SampleVODSimVasp.m_logger.addAppender(appender);
    }

    // 
    SampleVODSimVasp(final String[] args) throws java.net.UnknownHostException {
        this.m_pgmNumber = 1001;
        try {
            SampleVODSimVasp.setLogger();
            this.parseArguments(args);
        } catch (final Exception ex) {
            SampleVODSimVasp.fatalStackTrace(ex);
            SampleVODSimVasp.usage();
            System.exit(1);
        }
    }

    public void parseArguments(final String[] args) throws Exception {
        // take the arguments in local variable
        final String dncsip = args[0];

        final String myIp = args[1];

        final String tsIdIn = args[2];
        this.m_tsIDIn = Integer.parseInt(tsIdIn);

        final String tsID = args[3];
        this.m_tsIDOut = Integer.parseInt(tsID);

        this.m_errorPercent = Float.parseFloat(args[4]);

        this.m_ISA = Integer.parseInt(args[5]);

        // Create the session info table
        this.m_sessionInfoTable = new Hashtable();

        // Set the dncs ip
        this.m_dncsIp = InetAddress.getByName(dncsip);

        // get the local ip
        this.m_myIp = InetAddress.getByName(myIp);

        // create my NSAP Address
        final IpAddress ip = new IpAddress();
        ip.setIPAddress(this.m_myIp);
        this.m_myNsap = new DSMCCNsapAddress(ip);
    }

    public static void main(final String[] args) {

        // Set up a simple configuration that logs on the console.
        BasicConfigurator.configure();

        SampleVODSimVasp.m_logger.info("Entering application.");

        if (SampleVODSimVasp.checkArguments(args) == 0) {
            try {
                final SampleVODSimVasp vasp = new SampleVODSimVasp(args);
                vasp.dumpStartingParams();
                // vasp.test();
                vasp.run();
            } catch (final Exception ex) {
                ex.printStackTrace();
                SampleVODSimVasp.m_logger.fatal("Exception: " + ex.toString());
                SampleVODSimVasp.fatalStackTrace(ex);
            }
        } else {
            SampleVODSimVasp.usage();
        }

        SampleVODSimVasp.m_logger.info("Exiting application.");
    }

    public void run() {

        // //////////////////////////////////////////////////////////////////////
        // Get the input and output streams
        try {
            this.connectToDNCS();
        } catch (final Exception ex) {
            SampleVODSimVasp.m_logger.fatal("Can not connect to DNCS");
            return;
        }

        // do the handshake
        this.doHandShake();

        // //////////////////////////////////////////////////////////////////////
        //
        // go int the loop

        while (true) {
            DSMCCMessage readMsg = null;
            try {
                readMsg = DSMCCMessageFactory.create(this.m_dis);
            } catch (final Exception ex) {
                ex.printStackTrace();
            }

            if (readMsg != null) {
                try {
                    // readMsg.dump(System.out);
                } catch (final Exception ex) {
                    SampleVODSimVasp.m_logger.fatal("Could not dump the message");
                    return;
                }

            }

            // get the message type
            final DSMCCServerMessageType msgType = DSMCCServerMessageType.valueOf(readMsg.getMessageType());
            
            switch (msgType) {
                case enServer_Session_Setup_Indication: {
                    // Process the session setup indication
                    final DSMCCServerSessionSetUpIndication msg = (DSMCCServerSessionSetUpIndication) readMsg;
                    this.ProcessServerSessionSetupIndication(msg);
                    break;
                }

                case enServer_Session_Setup_Response: {
                    // Process the

                    break;
                }

                case enServer_Add_Resource_Request: {
                    // We will never recieve this message but lets keep it

                    break;
                }

                case enServer_Add_Resource_Confirm: {
                    // Process the Add Resource Confirm
                    final DSMCCServerAddResourceConfirm msg = (DSMCCServerAddResourceConfirm) readMsg;
                    this.ProcessServerAddResourceConfirm(msg);
                    break;
                }

                case enServer_Release_Request: {
                    // Process the
                    final DSMCCServerReleaseRequest msg = (DSMCCServerReleaseRequest) readMsg;
                    this.ProcessServerReleaseRequest(msg);
                    break;
                }

                case enServer_Release_Confirm: {
                    // Process the
                    final DSMCCServerReleaseConfirm msg = (DSMCCServerReleaseConfirm) readMsg;
                    this.ProcessServerReleaseConfirm(msg);
                    break;
                }

                case enServer_Release_Indication: {
                    // Process the
                    final DSMCCServerReleaseIndication msg = (DSMCCServerReleaseIndication) readMsg;
                    this.ProcessServerReleaseIndication(msg);
                    break;
                }

                case enServer_Release_Response: {
                    // Process the

                    break;
                }
                    /*
                     * case DSMCCServerMessageType.enServer_CFS_Request: { // Process the break; }
                     */
                    /*
                     * case DSMCCServerMessageType.enServer_CFS_Confirm: { // Process the
                     * DSMCCServerCFSConfirm msg = (DSMCCServerCFSConfirm) readMsg;
                     * ProcessServerCFSConfirm(msg); break; }
                     */
                case enServer_Status_Request: {
                    // Process the

                    break;
                }

                case enServer_Status_Confirm: {
                    // Process the
                    final DSMCCServerStatusConfirm msg = (DSMCCServerStatusConfirm) readMsg;
                    this.ProcessServerStatusConfirm(msg);
                    break;
                }

                case enServer_Status_Indication: {
                    // Process the
                    final DSMCCServerStatusIndication msg = (DSMCCServerStatusIndication) readMsg;
                    this.ProcessServerStatusIndication(msg);
                    break;
                }

                case enServer_Status_Response: {
                    // Process the

                    break;
                }

                    /*
                     * case DSMCCServerMessageType.enServer_Proceeding_Indication: { // Process the
                     * DSMCCServerProceedingIndication msg = (DSMCCServerProceedingIndication ) readMsg;
                     * ProcessServerProceedingIndication (msg); break; }
                     */
                    /*
                     * case DSMCCServerMessageType.enServer_Connect_Indication: { // Process the
                     * DSMCCServerConnectIndication msg = (DSMCCServerConnectIndication) readMsg;
                     * ProcessServerConnectIndication(msg); break; }
                     */
                case enServer_Session_In_Progress: {
                    // Process the

                    break;
                }

                default:
                    ;
            }
            System.out.println("");

        }
        //
        // //////////////////////////////////////////////////////////////////////

    }

    public void doHandShake() {
        // //////////////////////////////////////////////////////////////////////
        // Get the input and output streams
        final DSMCCInputStream dis;
        final DSMCCOutputStream dos;
        try {
            // dos = new DSMCCOutputStream(new FileOutputStream("f:\\tmp\\pvt\\fos.bin"));

            // Create a Server Status Request Message
            // DSMCCServerStatusRequest req =
            // DSMCCServerStatusRequest.createSessionStatusRequest(m_myNsap,m_cfsSessioId);
            final DSMCCServerStatusRequest req = DSMCCServerStatusRequest.createSessionListRequest(this.m_myNsap);
            req.setTransactionId(0x0101);
            // req.dump(System.out);
            // Send this to DNCS
            req.write(this.m_dos);
            this.m_dos.flush();

            // dis = new DSMCCInputStream(new FileInputStream("f:\\tmp\\pvt\\fos.bin"));
            // wait for the response
            SampleVODSimVasp.m_logger.info("Waiting for status confirm");
            final DSMCCMessage msg = DSMCCMessageFactory.create(this.m_dis);
            // msg.dump(System.out);
        } catch (final Exception ex) {
            SampleVODSimVasp.m_logger.fatal("Can not get the status from DNCS");
            SampleVODSimVasp.m_logger.fatal(ex.getMessage());
            ex.printStackTrace();
            return;
        }

    }

    protected void connectToDNCS() {
        // Connect to dncs
        try {
            this.m_dncsSock = new Socket(this.m_dncsIp, SampleVODSimVasp.DSMCC_PORT);
            this.m_dis = new DSMCCInputStream(this.m_dncsSock.getInputStream());
            this.m_dos = new DSMCCOutputStream(this.m_dncsSock.getOutputStream());

        } catch (final Exception ex) {
            SampleVODSimVasp.m_logger.fatal("Can not connect to DNCS " + this.m_dncsIp + SampleVODSimVasp.DSMCC_PORT);
            return;
        }

    }

    // This method will check the passed arguments to determine if it possible
    // continue with them and return return 0 if they are OK
    public static int checkArguments(final String[] args) {
        int iRet = 0;
        // //////////////////////////////////////////////////////////////////////
        //
        //
        if (args.length == 6) {
            iRet = 0;
        } else {
            iRet = -1;
        }
        // //////////////////////////////////////////////////////////////////////

        return iRet;
    }

    public int dumpStartingParams() {
        try {
            // log all the starting parameters
            SampleVODSimVasp.m_logger.info("Using My IP as       " + this.m_myIp.getHostAddress());
            SampleVODSimVasp.m_logger.info("Using DNCS ip as     " + this.m_dncsIp.getHostAddress());
            SampleVODSimVasp.m_logger.info("Using TSID Out as    " + this.m_tsIDOut);
            SampleVODSimVasp.m_logger.info("Using TSID In  as    " + this.m_tsIDIn);
            SampleVODSimVasp.m_logger.info("We will produce " + this.m_errorPercent + " % errors randomly");

            // Now start doing the real work
        } catch (final Exception ex) {

        }

        return 0;
    }

    public int ProcessServerSessionSetupIndication(final DSMCCServerSessionSetUpIndication msg) {
        int iRet = 0;
        // Get the session id from the message
        final DSMCCSessionID sessId = msg.getSessionId();
        SampleVODSimVasp.m_logger.debug("Recieved\t SSSI for " + sessId);
        // Get the txn id
        final long txnId = msg.getTransactionId();

        // create a session info and put in the session info table
        final SessionInfo sessInfo = new SessionInfo(msg);
        // get the bytes from session id and use as key
        // byte [] sessKey = sessId.getAsBytes();
        this.putIntoTable(sessId, sessInfo);

        int err = 0;
        DSMCCMessage retMsg = null;
        if (this.m_errorPercent != 0) {
            final double rand = Math.random();
            final int randInt = (int) (rand * 10000);
            if (randInt < this.m_errorPercent * 100) {
                err = (randInt % 31) + 1;
            } else {
                err = 0;
            }
        }
        if (err == 0) {
            retMsg = this.composeServerAddResourceRequest(msg);
            try {
                // retMsg.dump(System.out);
            } catch (final Exception ex) {

            }
            if (retMsg != null) {
                iRet = this.write(retMsg);
                SampleVODSimVasp.m_logger.debug("Sent\t SARR for " + sessId);
            } else {
                err = ResponseCode.enRspSeProcError;
            }
        } else {
            retMsg = this.composeServerSessionSetupFailureResponse(msg, ResponseCode.enRspSeProcError);
            iRet = this.write(retMsg);
            SampleVODSimVasp.m_logger.debug("Send SARR for " + sessId + " with error " + err);
            // remove the session info from the hashtable
            this.removeFromTable(sessId);
        }
        return iRet;
    }

    public DSMCCUserData getDesiredSSPUserData() {
        // this is a sample vasp so we really do not care about the user data
        // but a real vasp should.

        // ... Look at the UserData and take decisions based upon that
        DSMCCUserData userData;
        if (this.m_ISA == 1) {
            userData = this.createNONISAUserData();
        } else {
            userData = this.createISAUserData();
        }
        return userData;
    }

    public int ProcessServerAddResourceConfirm(final DSMCCServerAddResourceConfirm msg) {
        int iRet = 0;
        // Get the resopnse code
        final int responseCode = msg.getResponse();
        final DSMCCMessage retMsg = null;
        // Get the session Id
        final DSMCCSessionID sessId = msg.getSessionId();
        SampleVODSimVasp.m_logger.debug("Recieved\t SARC for " + sessId + " Response code " + responseCode);
        // byte [] key = sessId.getAsBytes();
        // find the session info for this session
        final SessionInfo sessInfo = this.getFromTable(sessId);
        if (sessInfo != null) {
            DSMCCServerSessionSetUpResponse response = null;
            // get the header
            final DSMCCMessageCommonHeader hdr = sessInfo.m_indicationMsg.getHeader();
            hdr.setAdaptationHeader(DSMCCAdaptationHeader.createUserIdAdaptationHeader(this.m_myNsap));
            switch (responseCode) {
                case ResponseCode.enRspOK: {
                    response = new DSMCCServerSessionSetUpResponse(hdr, sessId, ResponseCode.enRspOK,
                            sessInfo.m_indicationMsg.getServerId(), new DSMCCNsapAddress(), msg.getResources(), this
                                    .getDesiredSSPUserData() // new DSMCCUserData()
                    );
                    SampleVODSimVasp.m_logger.debug("Sent\t SSSR for " + sessId);
                    break;
                }
                default: {
                    response = new DSMCCServerSessionSetUpResponse(hdr, sessId, responseCode, sessInfo.m_indicationMsg
                            .getServerId(), new DSMCCNsapAddress(), new DSMCCResourceDescriptorContainer(), this
                            .getDesiredSSPUserData() // new DSMCCUserData()
                    );
                    this.removeFromTable(sessId);
                    SampleVODSimVasp.m_logger.debug("Sent\t\t SSSR for " + sessId + " with resp code " + responseCode);
                }
            }

            // write the message
            iRet = this.write(response);
        } else {
            final DSMCCMessage failedMsg = new DSMCCServerSessionSetUpResponse(msg.getHeader(), sessId,
                    ResponseCode.enRspSeNoSession, this.m_myNsap, new DSMCCNsapAddress(),
                    new DSMCCResourceDescriptorContainer(), new DSMCCUserData());
            iRet = this.write(failedMsg);
        }

        return iRet;
    }

    public int ProcessServerReleaseRequest(final DSMCCServerReleaseRequest msg) {
        final int iRet = 0;
        return iRet;
    }

    public int ProcessServerReleaseConfirm(final DSMCCServerReleaseConfirm msg) {
        // Get the session Id
        final DSMCCSessionID sessId = msg.getSessionId();
        // byte [] sessKey = sessId.getAsBytes();
        this.removeFromTable(sessId);

        return 1;
    }

    public int ProcessServerReleaseIndication(final DSMCCServerReleaseIndication msg) {
        int iRet = 0;
        // Get the session Id
        final DSMCCSessionID sessId = msg.getSessionId();
        SampleVODSimVasp.m_logger.debug("Recieved\t SSRI for " + sessId);
        // byte [] sessKey = sessId.getAsBytes();
        // find the session info for this session
        final SessionInfo sessInfo = this.getFromTable(sessId);

        // fix the header the header
        final DSMCCMessageCommonHeader hdr = msg.getHeader();
        hdr.setAdaptationHeader(DSMCCAdaptationHeader.createUserIdAdaptationHeader(this.m_myNsap));
        // Compose the response
        DSMCCServerReleaseResponse retMsg = null;
        if (sessInfo == null) {
            retMsg = new DSMCCServerReleaseResponse(hdr, sessId, ResponseCode.enRspSeNoSession, new DSMCCUserData());
        } else {
            retMsg = new DSMCCServerReleaseResponse(hdr, sessId, ResponseCode.enRspOK, new DSMCCUserData());
            // remove the session info from the hashtable
            this.removeFromTable(sessId);
        }
        SampleVODSimVasp.m_logger.debug("Sent\t SSRR for " + sessId);
        iRet = this.write(retMsg);
        return 0;
    }

    public int ProcessServerStatusConfirm(final DSMCCServerStatusConfirm msg) {

        return 0;
    }

    public int ProcessServerStatusIndication(final DSMCCServerStatusIndication msg) {

        return 0;
    }

    /*
     * public int ProcessServerProceedingIndication (DSMCCServerProceedingIndication msg ) { return 0; }
     */
    /*
     * public int ProcessServerConnectIndication(DSMCCServerConnectIndication msg) { return 0; }
     */

    public DSMCCResourceDescriptorContainer getDesiredResources(final DSMCCUserData userData) {
        // this is a sample vasp so we really do not care about the user data
        // but a real vasp should.

        // ... Look at the UserData and take decisions based upon that

        final DSMCCResourceDescriptorContainer retResContainer = new DSMCCResourceDescriptorContainer();

        final DSMCCMpegProgramResourceDescriptor mpgPgmRes = DSMCCMpegProgramResourceDescriptor
                .createMpegProgramNumberServerView(this.m_pgmNumber++);
        mpgPgmRes.getHeader().setResourceRequestId(0x01);

        if (this.m_tsIDIndex >= 2) {
            this.m_tsIDIndex = 0;
        } else {
            this.m_tsIDIndex++;
        }
        // if(m_tsIDOutIndex >= 3)
        // {
        // m_tsIDOutIndex = 0;
        // }
        // else
        // {
        // m_tsIDOutIndex++;
        // }
        // m_tsIDOut = m_tsIDOutArray[m_tsIDIndex];
        final DSMCCTSDSBWResourceDescriptor tsdBw = DSMCCTSDSBWResourceDescriptor
                .createResource(100000, this.m_tsIDOut);
        tsdBw.getHeader().setResourceRequestId(0x002);

        final DSMCCServiceGroupResourceDescriptor sgRes = DSMCCServiceGroupResourceDescriptor.createResource(1);
        sgRes.getHeader().setResourceRequestId(0x03);

        // if(m_tsIDInIndex >=3)
        // {
        // m_tsIDInIndex = 0;
        // }
        // else
        // {
        // m_tsIDInIndex++;
        // }
        // m_tsIDIn = m_tsIDInArray[m_tsIDIndex];
        final DSMCCHeadEndIdResourceDescriptor headEndRes = DSMCCHeadEndIdResourceDescriptor
                .createresourceFromTSID_IN(this.m_tsIDIn);
        headEndRes.getHeader().setResourceRequestId(0x04);

        // add the cfs desc in the container
        retResContainer.addResourceField(mpgPgmRes);
        retResContainer.addResourceField((tsdBw));
        retResContainer.addResourceField((sgRes));
        retResContainer.addResourceField((headEndRes));

        return retResContainer;
    }

    int getNextTxnId() {
        return ++this.m_txnId;
    }

    private DSMCCServerAddResourceRequest composeServerAddResourceRequest(final DSMCCServerSessionSetUpIndication msg) {
        // Get the session id from the message
        final DSMCCSessionID sessId = msg.getSessionId();
        // Get the private data and compose the resources for the AddResourceRequest message
        final DSMCCResourceDescriptorContainer addResReqResorces = this.getDesiredResources(msg.getUserData());

        // start creating the AddResourceRequest msg
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(this.m_myNsap);
        final DSMCCMessageCommonHeader hdr = new DSMCCMessageCommonHeader(msg.getHeader());
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        final DSMCCServerAddResourceRequest arrMsg = new DSMCCServerAddResourceRequest(hdr, sessId, addResReqResorces,
                new DSMCCUserData());

        // set the txn id
        arrMsg.setTransactionId(this.getNextTxnId());

        return arrMsg;
    }

    /*
     * public void test1() { try { String inputFile1
     * ="D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerSessionSetupIndication.bin"; String outputFile1
     * ="D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerAddResourceRequest.bin"; byte [] byes = new
     * byte[1024]; DSMCCInputStream dis = new DSMCCInputStream(new FileInputStream(inputFile1));
     * DSMCCServerSessionSetUpIndication sssrMsg = (DSMCCServerSessionSetUpIndication
     * )DSMCCMessageFactory.create(dis); //sssrMsg.dump(System.out); DSMCCOutputStream dos = new
     * DSMCCOutputStream(new FileOutputStream(outputFile1)); DSMCCServerAddResourceRequest sarr =
     * composeServerAddResourceRequest(sssrMsg); System.out.println("=============================");
     * sarr.dump(System.out); sarr.write(dos); dos.close(); String inputFile2 = outputFile1; String
     * outputFile2 = outputFile1+ ".txt"; DSMCCInputStream dis2 = new DSMCCInputStream(new
     * FileInputStream(inputFile2)); DSMCCOutputStream dos2 = new DSMCCOutputStream(new
     * FileOutputStream(outputFile2)); DSMCCMessage msg = DSMCCMessageFactory.create(dis2);
     * msg.dump(System.out); msg.write(dos2); } catch( Exception ex) { ex.printStackTrace(); System.exit(0); }
     * System.exit(0); }
     */
    /*
     * public void test2() { try { //String inputFile1
     * ="D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerSessionSetupIndication.bin"; String inputFile1
     * ="D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerAddResourceRequest.bin"; byte [] bytes = new
     * byte[1024]; FileInputStream fis = new FileInputStream(inputFile1); int iRead = fis.read(bytes); int
     * iCnt =0; logger.debug("Start At " + new Date()); for (iCnt = 0; iCnt < 100000; iCnt++) {
     * DSMCCInputStream dis = new DSMCCInputStream(new ByteArrayInputStream(bytes,0,iRead) ); DSMCCMessage msg
     * = DSMCCMessageFactory.create(dis); //msg.dump(System.out); } logger.debug("End At " + (new Date()) +
     * " Loops " + iCnt); } catch( Exception ex) { ex.printStackTrace(); System.exit(0); } System.exit(0); }
     */
    public int write(final DSMCCMessage msg) {
        int iRet = 0;
        try {
            iRet = msg.write(this.m_dos);
        } catch (final Exception ex) {
            SampleVODSimVasp.m_logger.error("Could not write " + msg.getClass());
            this.connectToDNCS();
        }

        return iRet;
    }

    private DSMCCServerSessionSetUpResponse composeServerSessionSetupFailureResponse(
            final DSMCCServerSessionSetUpIndication msg, final int responseCode) {
        DSMCCServerSessionSetUpResponse retMsg = null;

        // Get the session id from the message
        final DSMCCSessionID sessId = msg.getSessionId();
        // Get the private data and compose the resources for the AddResourceRequest message
        final DSMCCResourceDescriptorContainer addResReqResorces = this.getDesiredResources(msg.getUserData());

        // start creating the AddResourceRequest msg
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(this.m_myNsap);
        final DSMCCMessageCommonHeader hdr = msg.getHeader();
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        retMsg = new DSMCCServerSessionSetUpResponse(hdr, msg.getSessionId(), responseCode, msg.getServerId(),
                new DSMCCNsapAddress(), new DSMCCResourceDescriptorContainer(), new DSMCCUserData());
        // set the txn id
        retMsg.setTransactionId(this.getNextTxnId());

        return retMsg;
    }

    public static void usage() {
        SampleVODSimVasp.m_logger.fatal("Usage: SamplVODSimVasp DNCS_IP MY_IP TSID_OUT TSID_IN PERCENT_ERRORS ");
        SampleVODSimVasp.m_logger.fatal("DNCS_IP:        nnn.nnn.nnn.nnn");
        SampleVODSimVasp.m_logger.fatal("MY_IP:          nnn.nnn.nnn.nnn");
        SampleVODSimVasp.m_logger.fatal("TSID_IN:        TS ID In of the QAM");
        SampleVODSimVasp.m_logger.fatal("TSID_OUT:       TS ID Out of the QAM");
        SampleVODSimVasp.m_logger.fatal("PERCENT_ERRORS: nn.nn // from 0 to 99");
    }

    public static void fatalStackTrace(final Exception ex) {
        final StackTraceElement[] steArray = ex.getStackTrace();
        for (final StackTraceElement element : steArray) {
            SampleVODSimVasp.m_logger.fatal(steArray.toString());
        }
    }

    public void test3() {
        // create a data input stream
        try {
            /*
             * DSMCCOutputStream dos = new DSMCCOutputStream(new ByteArrayOutputStream());
             * DSMCCResourceValue_Variable var = new DSMCCResourceValue_Single( new
             * DSMCCResourceValue_2Byte(2)); var.write(dos); var.dump(System.out);
             */

            final String inputFile = "D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerSessionSetupIndication.bin";
            final String outputFile = "D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerAddResourceRequest.bin";
            final DSMCCInputStream dis = new DSMCCInputStream(new FileInputStream(inputFile));
            final DSMCCOutputStream dos = new DSMCCOutputStream(new FileOutputStream(outputFile));
            final DSMCCServerSessionSetUpIndication sessI = (DSMCCServerSessionSetUpIndication) DSMCCMessageFactory
                    .create(dis);
            final DSMCCMessage msg = this.composeServerAddResourceRequest(sessI);
            final int iRet = msg.getLength();
            msg.write(dos);
            msg.dump(System.out);

        } catch (final Exception ex) {

        }
        System.exit(0);
    }

    private void putIntoTable(final DSMCCSessionID sess, final SessionInfo info) {

        this.m_sessionInfoTable.put(sess, info);
        SampleVODSimVasp.m_logger.debug("Put\t\t " + sess + " into table");
    }

    private SessionInfo getFromTable(final DSMCCSessionID sess) {
        final Object obj = this.m_sessionInfoTable.get(sess);
        if (obj != null) {
            return (SampleVODSimVasp.SessionInfo) obj;
        }
        SampleVODSimVasp.m_logger.debug("Could not find " + sess);
        return null;
    }

    private void removeFromTable(final DSMCCSessionID sess) {
        this.m_sessionInfoTable.remove(sess);
    }

    private boolean tableContains(final DSMCCSessionID sess) {
        return this.m_sessionInfoTable.containsKey(sess);
    }

    public void test() {
        try {
            // vasp.test3();
            // test4();
            this.test5();
        } catch (final Exception ex) {
            ex.printStackTrace();
        }
        System.exit(0);
    }

    public void test5() {
        // Test the session hasing code
        String sessionIdstr = "";
        // for ( int iLoop = 0;iLoop < 0x8FFFFFFF/10000 ; iLoop++)
        {
            for (int iCnt = 1; iCnt < 10; iCnt++) {
                sessionIdstr = "00:02:de:00:01:01:" + iCnt;
                // System.out.println(sessionIdstr);
                final DSMCCSessionID sess = new DSMCCSessionID(sessionIdstr);
                this.m_sessionInfoTable.put(sess, new Integer(iCnt));
                System.out.println("Hash " + sess.hashCode());
            }
            System.out.println("Total Entries " + this.m_sessionInfoTable.size());
            for (int iCnt = 1; iCnt <= this.m_sessionInfoTable.size(); iCnt++) {
                sessionIdstr = "00:02:de:00:01:01:" + iCnt;
                final DSMCCSessionID sess = new DSMCCSessionID(sessionIdstr);
                final Object obj = this.m_sessionInfoTable.get(sess);
                if (obj != null) {
                    final Integer iTest = (Integer) obj;
                    System.out.println(sessionIdstr + iTest);
                } else {
                    System.out.println("Could not find " + iCnt);
                }

            }
        }

    }

    public void test4() throws Exception {
        final String inputFile = "D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerAddResourceConfirm.bin";
        final String outputFile = "D:\\iTaas\\DSMCC\\examples\\dumpMessage\\ServerSessionSetupResponse.bin";
        final DSMCCInputStream dis = new DSMCCInputStream(new FileInputStream(inputFile));
        // DSMCCOutputStream dos = new DSMCCOutputStream( new FileOutputStream(outputFile));

        DSMCCMessage msgBase = null;
        try {
            msgBase = DSMCCMessageFactory.create(dis);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

        final DSMCCServerAddResourceConfirm msg = (DSMCCServerAddResourceConfirm) msgBase;
        final int iRet = 0;
        // Get the resopnse code
        final int responseCode = msg.getResponse();
        final DSMCCMessage retMsg = null;
        // Get the session Id
        final DSMCCSessionID sessId = msg.getSessionId();
        SampleVODSimVasp.m_logger.debug("Recieved\t SARC for " + sessId + " Response code " + responseCode);
        // byte [] key = sessId.getAsBytes();
        // find the session info for this session
        // SessionInfo sessInfo = getFromTable(sessId);
        DSMCCServerSessionSetUpResponse response = null;
        // get the header
        final DSMCCMessageCommonHeader hdr = msg.getHeader();
        hdr.setAdaptationHeader(DSMCCAdaptationHeader.createUserIdAdaptationHeader(this.m_myNsap));
        final DSMCCResourceDescriptorContainer cont = msg.getResources();
        cont.dump(System.out);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final DSMCCOutputStream dos = new DSMCCOutputStream(baos);
        // cont.write(dos);
        response = new DSMCCServerSessionSetUpResponse(hdr, sessId, ResponseCode.enRspOK, this.m_myNsap,
                new DSMCCNsapAddress(), msg.getResources(), new DSMCCUserData());
        response.write(dos);
        final ByteArray temp = new ByteArray(baos.toByteArray());
        temp.dump(System.out);

        SampleVODSimVasp.m_logger.debug("Sent\t SSSR for " + sessId);

        System.exit(0);
        // return iRet;
    }

    public void tearDownAllSessions() {

    }

    private DSMCCUserData createISAUserData() {
        final SSPUserPrivateData_2 sspContainer = new SSPUserPrivateData_2();

        final byte[] svcGwyArr = { 'B', 'M', 'S', 's', 'v', 'c', 'g', 'a', 't', 'e', 'w', 'a', 'y', 0x00, 0x00, 0x00 };
        final byte[] svcbArr = { 'P', 'B', 'S', '_', 'K', 'I', 'D', 'S', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

        final String sgwStr = "BMSsvcgetway";
        final ByteArray sgwArr = new ByteArray();
        sgwArr.copy(svcGwyArr);
        sspContainer.setServiceGateway(sgwArr);

        final String svcStr = "PBS_KIDS";
        final ByteArray svcArr = new ByteArray();
        svcArr.copy(svcbArr);
        sspContainer.setService(svcArr);

        final IPDescriptor ipSSP = new IPDescriptor(0x06);
        final String gsIpStr = "192.168.20.136";
        /*
         * if (bSecondSetIPPort == false) { String gsIpStr = "192.168.20.155"; } else { }
         */

        IpAddress ipaddr = null;
        try {
            ipaddr = IpAddress.valueOf(gsIpStr);
        } catch (final IllegalArgumentException iaex) {
            SampleVODSimVasp.m_logger.error("Failed to create IpAddress: " + iaex);
        }
        ipSSP.setIPAddress(ipaddr);
        /*
         * try { ipaddr.setIPAddress(InetAddress.getByName("192.168.0.234")); } catch(Exception e) {
         * e.printStackTrace(); }
         */
        // ipSSP.setIPAddress(ipaddr);
        this.VODServerPort = 8556;
        ipSSP.setPort(this.VODServerPort);

        System.out.println(" port sent = " + this.VODServerPort);
        /*
         * count++; if(VODServerPort == 65000) { VODServerPort = 10000; } else { VODServerPort += 1; }
         */
        sspContainer.addDescriptor(ipSSP);

        // Create random StreamHandle
        final double rand = Math.random();
        final int randInt = (int) (rand * 10000);

        final StreamHandleDescriptor hndl = new StreamHandleDescriptor(0x04);
        hndl.setStreamHandle(this.StreamHandle/* randInt */);
        sspContainer.addDescriptor(hndl);
        this.StreamHandle++;

        final MystroSessionIdDescriptor mystro = new MystroSessionIdDescriptor(0x04);
        mystro.setMystroId(0xd20);
        sspContainer.addDescriptor(mystro);

        final DurationSSPDescriptor duration = new DurationSSPDescriptor(0x04);
        duration.setTimeLenInMilliSecs(0x01627e0);
        sspContainer.addDescriptor(duration);

        final DVDChapterSSPDescriptor dvd = new DVDChapterSSPDescriptor(0xe);
        dvd.setNPT(0x00);
        final byte[] by = { 0x0, 0x30, 0x30, 0x3a, 0x30, 0x30, 0x3a, 0x30, 0x30, 0x00 };
        final ByteArray bArr = new ByteArray();
        bArr.copy(by);
        dvd.setChapterId(bArr);
        sspContainer.addDescriptor(dvd);

        final DVDChapterSSPDescriptor otherDVD = new DVDChapterSSPDescriptor(0xe);
        otherDVD.setNPT(0x0dbba0);
        final byte[] oby = { 0x00, 0x30, 0x30, 0x3a, 0x31, 0x35, 0x3a, 0x30, 0x30, 0x00 };
        final ByteArray obArr = new ByteArray();
        obArr.copy(oby);
        otherDVD.setChapterId(obArr);
        sspContainer.addDescriptor(otherDVD);

        // Write the descriptors to a ByteArrayOutputStream and then get
        // the bytes.
        final ByteArrayOutputStream byteStrm = new ByteArrayOutputStream(64);
        final DSMCCOutputStream tmpStrm = new DSMCCOutputStream(byteStrm);

        int writeRet;
        try {
            writeRet = sspContainer.write(tmpStrm); // 3
            // logger.info("SSPUserPrivateData write returns: " + writeRet);
        } catch (final IOException ioex) {
            SampleVODSimVasp.m_logger.error("Failed to write UserData descriptors" + ioex);
        }

        final byte[] privateDataBytes = byteStrm.toByteArray();
        // logger.info("privateData Length: " + uuDataBytes.length);
        final ByteArray privateData_barray = new ByteArray(privateDataBytes, ByteArray.UNSIGNED_SHORT);
        final ByteArray uuData_barray = new ByteArray(0, ByteArray.UNSIGNED_SHORT);

        final DSMCCUserData uData = new DSMCCUserData(uuData_barray, privateData_barray);
        return uData;
    }

    private DSMCCUserData createNONISAUserData() {
        final SSPUserPrivateData_1 sspContainer = new SSPUserPrivateData_1();

        final StreamHandleDescriptor hndl = new StreamHandleDescriptor(0x04);
        hndl.setStreamHandle(this.StreamHandle);
        sspContainer.addResource(hndl);
        this.StreamHandle++;

        final IPDescriptor ipSSP = new IPDescriptor(0x06);
        final String gsIpStr = "192.168.20.136";
        IpAddress ipaddr = null;
        try {
            ipaddr = IpAddress.valueOf(gsIpStr);
        } catch (final IllegalArgumentException iaex) {
            SampleVODSimVasp.m_logger.error("Failed to create IpAddress: " + iaex);
        }
        ipSSP.setIPAddress(ipaddr);
        this.VODServerPort = 8556;
        ipSSP.setPort(this.VODServerPort);

        System.out.println(" port sent = " + this.VODServerPort);
        sspContainer.addResource(ipSSP);

        // Write the descriptors to a ByteArrayOutputStream and then get
        // the bytes.
        final ByteArrayOutputStream byteStrm = new ByteArrayOutputStream(64);
        final DSMCCOutputStream tmpStrm = new DSMCCOutputStream(byteStrm);

        int writeRet;
        try {
            writeRet = sspContainer.write(tmpStrm); // 3
            // logger.info("SSPUserPrivateData write returns: " + writeRet);
        } catch (final IOException ioex) {
            SampleVODSimVasp.m_logger.error("Failed to write UserData descriptors" + ioex);
        }

        final byte[] privateDataBytes = byteStrm.toByteArray();
        // logger.info("privateData Length: " + uuDataBytes.length);
        final ByteArray privateData_barray = new ByteArray(privateDataBytes, ByteArray.UNSIGNED_SHORT);
        final ByteArray uuData_barray = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        final DSMCCUserData uData = new DSMCCUserData(uuData_barray, privateData_barray);
        return uData;
    }
}
