/*
 * Copyright iTaas, Inc. 2005 Created by krishna on Jun 27, 2005 No Portion of this file can be copied or
 * reproduced in any form without prior written approval.
 */
package com.itaas.dsmcc.TestClass;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Hashtable;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageFactory;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCOutputStream;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.IpAddress;
import com.itaas.dsmcc.base.ResponseCodes;
import com.itaas.dsmcc.base.StatusType;
import com.itaas.dsmcc.client.DSMCCClientReleaseConfirm;
import com.itaas.dsmcc.client.DSMCCClientReleaseIndication;
import com.itaas.dsmcc.client.DSMCCClientReleaseRequest;
import com.itaas.dsmcc.client.DSMCCClientReleaseResponse;
import com.itaas.dsmcc.client.DSMCCClientSessionInProgress;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpConfirm;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpRequest;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.server.DSMCCServerAddResourceConfirm;
import com.itaas.dsmcc.server.DSMCCServerAddResourceRequest;
import com.itaas.dsmcc.server.DSMCCServerReleaseConfirm;
import com.itaas.dsmcc.server.DSMCCServerReleaseIndication;
import com.itaas.dsmcc.server.DSMCCServerReleaseRequest;
import com.itaas.dsmcc.server.DSMCCServerReleaseResponse;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpIndication;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpResponse;
import com.itaas.dsmcc.server.DSMCCServerStatusConfirm;
import com.itaas.dsmcc.server.DSMCCServerStatusRequest;

/**
 * @author krishna
 */
// Emulation of SRM - DNCS
public class SRMEmulator extends Thread {

    /**
     * 
     */
    private static final int DSMCC_MAX_PACKET_SIZE = 2048;

    private final static int DSMCC_PORT = 13819; // Port for communication with clients i.e. DHCTs and VASP

    // Servers

    static int m_FailureRate; // Failure Rate in perecnt

    public VASPServerCommunication srvr = null; // VASP server's reference

    int sessionsCreating = 0;

    int sessionsCreated = 0;

    int sessionsexisting = 0;

    int sessionsfailed = 0;

    int sessionstorned = 0;

    int sessionstearing = 0;

    private boolean running;

    // This map will use the bytes from session id as key
    Hashtable<DSMCCSessionID, SessionInfo> m_sessionInfoTable; // Mapping of session objects

    Hashtable<InetAddress, DSMCCOutputStream> m_VASPServers; // Mapping of VASP servers

    private DatagramSocket sock = null; // Socket for sending data to the clients

    // A Private class to maintain the TxnId and last_msg time for each session
    class SessionInfo {

        private DSMCCClientSessionSetUpRequest m_setupReqMsg = null;

        private DSMCCServerAddResourceRequest m_addResourceRequest = null;

        Date m_lastMsg = null;

        // Constructor
        public SessionInfo(final DSMCCClientSessionSetUpRequest setupReqMsg) {
            this.m_setupReqMsg = setupReqMsg;
            this.updateTime();
        }

        // Updates current time
        public void updateTime() {
            this.m_lastMsg = new Date();
        }

        // Gets the Client session set up request for a particular session
        public DSMCCClientSessionSetUpRequest get_setupReqMsg() {
            return this.m_setupReqMsg;
        }

        // Sets the Client session set up request for a particular session
        public void set_setupReqMsg(final DSMCCClientSessionSetUpRequest reqMsg) {
            this.m_setupReqMsg = reqMsg;
        }

        // Returns the Server Add Resource request for the session
        public DSMCCServerAddResourceRequest get_addResourceRequest() {
            return this.m_addResourceRequest;
        }

        // Sets the Server Add Resource request for the session
        public void set_addResourceRequest(final DSMCCServerAddResourceRequest resourceRequest) {
            this.m_addResourceRequest = resourceRequest;
        }
    }

    // Constructor
    public SRMEmulator() {
        super();

        SRMEmulator.m_FailureRate = 1; // Sets the default failure rate

        // create new session information mapping table
        this.m_sessionInfoTable = new Hashtable<DSMCCSessionID, SessionInfo>();

        // create new VASP Servers information mapping table
        this.m_VASPServers = new Hashtable<InetAddress, DSMCCOutputStream>();

        // Create and start the thread to communicate with the VASP server
        this.srvr = new VASPServerCommunication(this);
        this.srvr.start();
    }

    // Adds to the key, value mapping for the session
    private void putIntoTable(final DSMCCSessionID sess, final SessionInfo info) {
        this.m_sessionInfoTable.put(sess, info);
    }

    // Retrieves from th sessionInfo object stored for the session
    private SessionInfo getFromTable(final DSMCCSessionID sess) {
        final Object obj = this.m_sessionInfoTable.get(sess);
        if (obj != null) {
            return (SRMEmulator.SessionInfo) obj;
        } else {
            System.out.println("Could not find session " + sess);
            return null;
        }
    }

    // Removes SessionInfo object stored for the session
    private void removeFromTable(final DSMCCSessionID sess) {
        this.m_sessionInfoTable.remove(sess);
    }

    // Checks if SessionInfo object is stored for the session
    protected boolean tableContains(final DSMCCSessionID sess) {
        return this.m_sessionInfoTable.containsKey(sess);
    }

    // Thread routine
    @Override
    public void run() {
        try {
            System.out.println("SRMEmulator creating datagram socket on: " + SRMEmulator.DSMCC_PORT);

            this.sock = new DatagramSocket(SRMEmulator.DSMCC_PORT);

            System.out.println("SRMEmulator listening for UDP Requests on: " + this.sock.getLocalAddress() + ":"
                    + this.sock.getLocalPort());
            final byte bai[] = new byte[SRMEmulator.DSMCC_MAX_PACKET_SIZE];
            final DatagramPacket packet = new DatagramPacket(bai, bai.length);
            System.out.println("SRMEmulator going into run loop: " + SRMEmulator.DSMCC_PORT);
            this.setRunning(true);
            while (this.isRunning()) {
                this.sock.receive(packet);
                System.out.println("SRMEmulator recieved packet on: " + SRMEmulator.DSMCC_PORT);
                // int iResp = (int) ((Math.random() * (100 + m_FailureRate)) / 100); // Five percent failure
                // System.out.println("SRMEmulator processing DSMCC Message ");
                final DSMCCMessage ret = this.processOneMessage(packet, 0);
                // System.out.println("SRMEmulator processed DSMCC Message");
                if (ret != null) {
                    // Write response of the DSMCC Request
                    final ByteArrayOutputStream baos = new ByteArrayOutputStream(SRMEmulator.DSMCC_MAX_PACKET_SIZE);
                    final DSMCCOutputStream dos = new DSMCCOutputStream(baos);
                    final int iWrite = ret.write(dos);
                    final byte bao[] = baos.toByteArray();
                    final DatagramPacket dpckt = new DatagramPacket(bao, iWrite, packet.getAddress(), packet.getPort());
                    this.sock.send(dpckt);
                }
            }
        } catch (final Exception ex) {
            // Exception while reading/writting DSMCC message
            ex.printStackTrace(System.err);
        }
    }

    // Process DSMCC Request received from the client
    public DSMCCMessage processOneMessage(final DatagramPacket packet, final int iRespCode) {
        final ByteArrayInputStream bais = new ByteArrayInputStream(packet.getData(), 0, packet.getLength());
        final DSMCCInputStream dis = new DSMCCInputStream(bais);
        DSMCCMessage ret = null;

        try {
            final DSMCCMessage msg = DSMCCMessageFactory.create(dis);
            if (msg != null) {

                // msg.dump(System.out);
                // Parse and handle the DSMCC Request
                DSMCCClientMessageType messageType = DSMCCClientMessageType.valueOf(msg.getMessageType());
                switch (messageType) {
                    case enClient_Session_Setup_Request: {
                        final DSMCCClientSessionSetUpRequest ssr = (DSMCCClientSessionSetUpRequest) msg;
                        // System.out.print("666, enClient_Session_Setup_Request, " + ssr.getSessionId() +
                        // "\n");
                        // Process sessions et up request by sending the server
                        // session set up indication
                        this.processSessionSetupRequest(packet, ssr);

                        // Send client session proceeding indication to the client
                        final DSMCCClientSessionInProgress cssp = new DSMCCClientSessionInProgress(msg.getHeader());
                        cssp.setTransactionId(msg.getTransactionId());
                        ret = cssp;
                        this.sessionsCreating++;
                        // System.out.println("Sessions creating = "+ sessionsCreating);
                        break;
                    }
                    case enClient_Release_Request: {
                        final DSMCCClientReleaseRequest crr = (DSMCCClientReleaseRequest) msg;
                        // System.out.print("666, enClient_Release_Request, " + crr.getSessionId() + "\n");
                        this.processReleaseRequest(crr);
                        this.sessionstearing++;
                        // System.out.println("sessions tearing ="+ sessionstearing);
                        ret = null;
                        break;
                    }
                    case enClient_Connect_Request: {
                        // System.out.print("Received enClient_Connect_Request \n");
                        // client connect request not handled
                        ret = null;
                        break;
                    }
                    case enClient_Release_Response: {
                        final DSMCCClientReleaseResponse crr = (DSMCCClientReleaseResponse) msg;
                        // System.out.print("666, enClient_Release_Response, " + crr.getSessionId() + "\n");
                        this.processReleaseResponse(crr);
                        ret = null;
                        break;
                    }
                    default: {
                        System.out.println("DEFAULT MSG ON DSMCC PORT OF SRMEmualtor- client thread");
                        break;
                    }
                }
            }
        } catch (final IOException ioex) {
            // Exception while creating a DSMCC Message
            ioex.printStackTrace(System.err);
        }

        return ret;
    }

    // Forwards session set up request tot he server
    public void processSessionSetupRequest(final DatagramPacket packet, final DSMCCClientSessionSetUpRequest msg) {
        // store client details with the request
        final IpAddress clientIP = new IpAddress();
        clientIP.setIPAddress(packet.getAddress());

        msg.setClientId(new DSMCCNsapAddress(clientIP));

        // store the session details
        final SessionInfo sessInfo = new SessionInfo(msg);
        this.putIntoTable(msg.getSessionId(), sessInfo);

        // System.out.println("Session set up request stored for client : " +
        // msg.getClientId().getIpAddress().getIPAddress());

        // Prepare server session set up indication response
       final DSMCCServerSessionSetUpIndication sssi = new DSMCCServerSessionSetUpIndication(msg.getHeader());

        // set adaptation header
        sssi.getHeader().setAdaLength(msg.getHeader().getAdaLength());
        sssi.getHeader().setAdaptationHeader(msg.getHeader().getAdaptationHeader());

        // Set server session set up msg details
        sssi.setSessionId(msg.getSessionId());
        sssi.setReserved(msg.getReserved());
        sssi.setClientId(msg.getClientId());
        sssi.setServerId(msg.getServerId());
        sssi.setUserData(msg.getUserData());

        // TO DO
        // Forward servers Queue
        // copy the message to the buffer send UDP packet to the server
        // Buffer to send the msg to VASP server
        // System.out.println("And for Server : " + msg.getServerId().getIpAddress().getIPAddress());
//        this.srvr.sendServerData(sssi, sssi.getSessionId(), msg.getServerId().getIpAddress().getIPAddress());
    }

    // Handles the client release response
    public void processReleaseResponse(final DSMCCClientReleaseResponse crr) {
        // Send the confirmation to the server
        final DSMCCServerReleaseConfirm src = new DSMCCServerReleaseConfirm(crr.getHeader());

        // set the appropriate data
        src.setResponse(crr.getResponse());
        src.setSessionId(crr.getSessionId());
        src.setTransactionId(crr.getTransactionId());
        src.setUserData(crr.getUserData());
        // Remove session details sicne session is released succesfuly
        if (crr.getResponse() == ResponseCodes.enRspOK) {
            this.removeFromTable(crr.getSessionId());
        } else {
            System.out.println("Error releasing session");
        }

        // send confirmation to the server
        final InetAddress serverAddress = this.getFromTable(crr.getSessionId()).m_setupReqMsg.getServerId()
                .getIpAddress().getIPAddress();
        this.srvr.sendServerData(src, src.getSessionId(), serverAddress);
    }

    // Handle client release session request
    public void processReleaseRequest(final DSMCCClientReleaseRequest request) {
        // create server release indiaction message
        final DSMCCServerReleaseIndication sri = new DSMCCServerReleaseIndication(request.getHeader());
        // set session release reason, transaction id, user data etc
        sri.setSessionId(request.getSessionId());
        sri.setReason(request.getReason());
        sri.setTransactionId(request.getTransactionId());
        sri.setUserData(request.getUserData());

        // send the server release indication to the server
        // for the particular session
        // send add resource confirmation to the server
        final InetAddress serverAddress = this.getFromTable(request.getSessionId()).m_setupReqMsg.getServerId()
                .getIpAddress().getIPAddress();
        this.srvr.sendServerData(sri, sri.getSessionId(), serverAddress);

        /*
         * { counter = 0; DSMCCClientReleaseIndication cri = new
         * DSMCCClientReleaseIndication(request.getHeader(), request.getSessionId(), ResponseCodes.enRspOK,
         * new DSMCCUserData()); // Retrieve the session id of the session to be released SessionInfo
         * sessionInfo = getFromTable(request.getSessionId()); // Send response to the client
         * srvr.sendClientData((DSMCCMessage)cri,
         * sessionInfo.get_setupReqMsg().getClientId().getIpAddress().getIPAddress()); }
         */
    }

    class VASPServerCommunication extends Thread {

        private boolean running;

        public SRMEmulator m_pSRMEmulator = null; // Reference of SRMEmulator

        // Default Constructor
        public VASPServerCommunication() {
            this.m_pSRMEmulator = null;
        }

        // Constructor
        public VASPServerCommunication(final SRMEmulator pSRMEmulator) {
            // Set the SRMEmulator reference
            this.m_pSRMEmulator = pSRMEmulator;
        }

        // Thread Routine
        @Override
        public void run() {
            try {
                // Wait for VASP servers to register with the SRM
                final ServerSocket srvr = new ServerSocket(SRMEmulator.DSMCC_PORT);
                Socket skt = null;
                this.setRunning(true);
                while (this.isRunning()) {
                    // Accept the connection request from VASP server
                    skt = srvr.accept();

                    if (skt != null) {
                        // Handle the VASP server messages
                        // Spawn a thread for each client
                        new VASPSereverHandler(this.m_pSRMEmulator, skt).start();
                    }
                    skt = null;
                }
                // Close socket
                srvr.close();
            } catch (final Exception e) {
                // Exception while waiting for requests from VASP Servers
                e.printStackTrace(System.err);
            }
        }

        // Handle Server release response
        public void processReleaseResponse(final DSMCCServerReleaseResponse srr) {
            // Retrieve the session id of the session to be released
            final SessionInfo sessionInfo = this.m_pSRMEmulator.getFromTable(srr.getSessionId());

            final DSMCCClientReleaseConfirm crc = new DSMCCClientReleaseConfirm(srr.getHeader());
            crc.setResponse(srr.getResponse());
            crc.setSessionId(srr.getSessionId());

            // Send response to the client
            this.sendClientData(crc, sessionInfo.get_setupReqMsg().getClientId().getIpAddress().getIPAddress());

            // As session is teared successfully, need to delete session details
            if (srr.getResponse() == ResponseCodes.enRspOK) {
                SRMEmulator.this.removeFromTable(srr.getSessionId());
                SRMEmulator.this.sessionstorned++;
                SRMEmulator.this.sessionsexisting--;
                // System.out.println("sessions torned = "+ sessionstorned);
                // System.out.println("sessions active = "+ sessionsexisting);
            } else {
                System.out.println("Error releasing session...so not decreamented sessionsexisting counter");
                if (SRMEmulator.this.sessionsCreated != (SRMEmulator.this.sessionsexisting + SRMEmulator.this.sessionstorned)) {
                    SRMEmulator.this.sessionstorned++;
                    SRMEmulator.this.sessionsexisting--;
                    System.out.println("EXCEPTION sessions torned = " + SRMEmulator.this.sessionstorned);
                    System.out.println("sessions active = " + SRMEmulator.this.sessionsexisting);
                }
            }
        }

        // Handle Session set up response
        public void processSessionSetupResponse(final DSMCCServerSessionSetUpResponse sssr) {
            final SessionInfo sessionInfo = this.m_pSRMEmulator.getFromTable(sssr.getSessionId());
            // System.out.println("Session id = " + sssr.getSessionId());
            final int iResp = (int) ((Math.random() * (100 + 20)) / 100);
            // Create Client session set up confirm message to be sent to the client
            final DSMCCClientSessionSetUpConfirm cssc = new DSMCCClientSessionSetUpConfirm(sssr.getHeader());
            cssc.setResources(sssr.getResources());
            cssc.setResponseCode(iResp); // sssr.getResponse());
            cssc.setServerId(sssr.getServerId());
            cssc.setSessionID(sssr.getSessionId());
            cssc.setTransactionId(sssr.getTransactionId());
            cssc.setUserData(sssr.getUserData());
            // System.out.println("Session set up confirmed for client : " +
            // sessionInfo.get_setupReqMsg().getClientId().getIpAddress().getIPAddress());
            // System.out.println("666, enClient_Session_Setup_Confirm, " + cssc.getSessionId() + ", " +
            // cssc.getResponse() + "\n");

            // Send confirmation to client
            this.sendClientData(cssc, sessionInfo.get_setupReqMsg().getClientId().getIpAddress().getIPAddress());
        }

        // Sends data to the specified server
        public void sendServerData(final DSMCCMessage msg, final DSMCCSessionID sessID,
                final InetAddress VASPServerAddress) {
            // Retrieve outputstream for VASP server of the session
            final SessionInfo sessInfo = SRMEmulator.this.getFromTable(sessID);

            try {
                DSMCCOutputStream dos = null;
                while (true) {
                    dos = SRMEmulator.this.m_VASPServers.get(sessInfo.get_setupReqMsg().getServerId().getIpAddress()
                            .getIPAddress());
                    // Check if the output stream is available.
                    if (dos == null) {
                        // Wait for handshake of VASP server and SRM
                        // System.out.println("Waiting for the server to be connected");
                        Thread.sleep(1000);
                    } else {
                        break;
                    }
                }
                // System.out.println("Writing msg to Gateway from SRM : ");
                msg.write(dos);
                dos.flush();
            } catch (final Exception e) {
                // Exception while writting DSMCC message to the VASP sevrer
                e.printStackTrace(System.err);
            }
        }

        // Sends data to the client
        public void sendClientData(final DSMCCMessage msg, final InetAddress clientAddress) {
            try {
                // Create a UDP packet and send it to the specified client
                final ByteArrayOutputStream baos = new ByteArrayOutputStream(SRMEmulator.DSMCC_MAX_PACKET_SIZE);
                final DSMCCOutputStream dos = new DSMCCOutputStream(baos);
                msg.write(dos);
                final byte bao[] = baos.toByteArray();
                // create a UDP packet
                final DatagramPacket packet = new DatagramPacket(bao, bao.length, clientAddress, SRMEmulator.DSMCC_PORT);
                SRMEmulator.this.sock.send(packet);
            } catch (final Exception e) {
                // Exception while sending data to the client
                e.printStackTrace();
            }
        }

        // VASP server handler - created for each VASP server.
        class VASPSereverHandler extends Thread {

            private Socket m_clientSocket; // Client socket

            private DSMCCInputStream m_dis = null; // Inputstream

            private DSMCCOutputStream m_dos = null; // Outputstream

            // Default constructor
            public VASPSereverHandler() {
            }

            // Constructor
            public VASPSereverHandler(final SRMEmulator pEmulator, final Socket clientSocket) {
                this.m_clientSocket = clientSocket; // set client socket
            }

            // Thread routine
            @Override
            public void run() {
                try {
                    // Create input and output sreams to communicate with the VASP server
                    this.m_dis = new DSMCCInputStream(this.m_clientSocket.getInputStream());
                    this.m_dos = new DSMCCOutputStream(this.m_clientSocket.getOutputStream());
                } catch (final Exception e) {
                    // Exception while creating input/output stream
                    e.printStackTrace();
                }
                SRMEmulator.this.m_VASPServers.put(this.m_clientSocket.getInetAddress(), this.m_dos);
                while (true) {
                    try {
                        // System.out.print("Reading data from Server\n");
                        final DSMCCMessage readMsg = DSMCCMessageFactory.create(this.m_dis);
                        // System.out.print("Read data from Server\n");
                        if (readMsg != null) {
                            final DSMCCServerMessageType msgType = DSMCCServerMessageType.valueOf(readMsg.getMessageType());
   
                            switch (msgType) {
                                case enServer_Status_Request: {
                                    // System.out.print("Received enServer_Status_Request \n");
                                    // Return status confirm message to the server
                                    final DSMCCServerStatusRequest ssr = (DSMCCServerStatusRequest) readMsg;
                                    final DSMCCServerStatusConfirm ssc = new DSMCCServerStatusConfirm(ssr.getHeader());
                                    ssc.setResponse(ResponseCodes.enRspOK);
                                    final ByteArray statusBytes = new ByteArray(0);
                                    // TO Do check with Vipul
                                    ssc.setStatusBytes(statusBytes);
                                    // TO DO check with Vipul
                                    ssc.setStatusType(StatusType.enIdentifyConfiguration);
                                    ssc.setTransactionId(ssr.getTransactionId());

                                    // Send status confirmation to the VODVASP Server
                                    ssc.write(this.m_dos);
                                    this.m_dos.flush();
                                    break;
                                }
                                case enServer_Add_Resource_Request: {
                                    // System.out.print("Received enServer_Add_Resource_Request \n");
                                    // Server add resource request
                                    // Need to send the Server add resource confirm message.
                                    final DSMCCServerAddResourceRequest sarr = (DSMCCServerAddResourceRequest) readMsg;
                                    this.processAddResourceRequest(sarr);

                                    break;
                                }
                                case enServer_Session_Setup_Response: {
                                    // Receievd session set up response from server, forward io to the client
                                    final DSMCCServerSessionSetUpResponse sssr = (DSMCCServerSessionSetUpResponse) readMsg;
                                    VASPServerCommunication.this.processSessionSetupResponse(sssr);
                                    if (sssr.getResponse() == ResponseCodes.enRspOK) {
                                        SRMEmulator.this.sessionsCreated++;
                                        SRMEmulator.this.sessionsexisting++;
                                        // System.out.println("Sessions created =" + sessionsCreated);
                                    } else {
                                        SRMEmulator.this.sessionsfailed++;
                                        // System.out.println("Sessions failed =" + sessionsfailed);
                                    }

                                    break;
                                }
                                case enServer_Release_Response: {
                                    // System.out.print("Received enServer_Release_Response \n");
                                    // Need to send client release confirm
                                    final DSMCCServerReleaseResponse srr = (DSMCCServerReleaseResponse) readMsg;
                                    VASPServerCommunication.this.processReleaseResponse(srr);
                                    break;
                                }
                                case enServer_Release_Request: {
                                    // System.out.print("Received enServer_Release_Request \n");
                                    // Receievd session release request from server
                                    // Needs to be forwarded to the client
                                    final DSMCCServerReleaseRequest srr = (DSMCCServerReleaseRequest) readMsg;
                                    final DSMCCClientReleaseIndication cri = new DSMCCClientReleaseIndication(srr
                                            .getHeader());

                                    // Set the message details appropriately
                                    cri.setReason(srr.getReason());
                                    cri.setSessionId(srr.getSessionId());
                                    cri.setTransactionId(srr.getTransactionId());
                                    cri.setUserData(srr.getUserData());

                                    // send indication to client
                                    cri.write(this.m_dos);
                                    this.m_dos.flush();
                                    break;
                                }
                                default: {
                                    System.out.println("DEFAULT server msg case ");
                                    break;
                                }
                            }
                        }
                    } catch (final Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            // Handle add resource request and send confirmation to the server
            public void processAddResourceRequest(final DSMCCServerAddResourceRequest sarr) {
                final DSMCCServerAddResourceConfirm sarc = new DSMCCServerAddResourceConfirm(sarr.getHeader());

                // set adaptation header
                sarc.getHeader().setAdaLength(sarr.getHeader().getAdaLength());
                sarc.getHeader().setAdaptationHeader(sarr.getHeader().getAdaptationHeader());

                // set user data
                sarc.setUserData(sarr.getUserData());

                // set resources
                sarc.setResources(sarr.getResources());

                // set OK response
                sarc.setResponse(ResponseCodes.enRspOK);

                // set session ID
                sarc.setSessionId(sarr.getSessionId());

                // set transaction id
                sarc.setTransactionId(sarr.getTransactionId());

                // To Do need to check the way to retrieve the server id
                // Store the resources with it
                final SessionInfo sessInfo = SRMEmulator.this.getFromTable(sarr.getSessionId());
                sessInfo.set_addResourceRequest(sarr);

                // for the particular session
                // send add resource confirmation to the server
                final InetAddress serverAddress = SRMEmulator.this.getFromTable(sarr.getSessionId()).m_setupReqMsg
                        .getServerId().getIpAddress().getIPAddress();
                VASPServerCommunication.this.sendServerData(sarc, sarc.getSessionId(), serverAddress);
            }
        }

        /**
         * @return the running
         */
        public boolean isRunning() {
            return this.running;
        }

        /**
         * @param running
         *            the running to set
         */
        public void setRunning(boolean running) {
            this.running = running;
        }
    }

    /**
     * @param args
     */
    public static void main(final String[] args) {
        System.out.println("SRMEmulator Starting.");
        final SRMEmulator srmEm = new SRMEmulator();
        srmEm.start();
    }

    /**
     * @param running
     *            the running to set
     */
    private void setRunning(boolean running) {
        this.running = running;
    }

    /**
     * @return the running
     */
    private boolean isRunning() {
        return running;
    }
}
