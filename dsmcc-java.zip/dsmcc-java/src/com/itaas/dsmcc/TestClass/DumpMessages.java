/*
 * DSMCCMessageTest.java Created on July 9, 2003, 10:56 AM
 */

package com.itaas.dsmcc.TestClass;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;
import java.util.Vector;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageFactory;
import com.itaas.dsmcc.base.DSMCCObject;

/**
 * @author chintan.desai
 */
public class DumpMessages extends DSMCCObject {

    static void dumpMessages(final InputStream is) {
        try

        {
            final DSMCCInputStream dis = new DSMCCInputStream(is);

            while (dis.available() > 0) {
                final DSMCCMessage msg = DSMCCMessageFactory.create(dis);
                if (msg != null) {
                    msg.dump(System.out);
                }
                System.out.println("");
            }
            // DSMCCOutputStream dos = new DSMCCOutputStream( new ByteArrayOutputStream());
            // msg.write(dos);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

    }

    public static void main(final String[] args) {
        if (args.length < 2) {
            System.out.println("dumpMessages file_name format offset_length data_length ascii_length\n");
            System.out.println("format:        t means ascii and b means binary\n");
            System.out.println("offset_length: the length of offset string\n");
            System.out.println("data_length:   the length of data strings\n");
            System.out.println("ascii_length:  the length of ascii string\n");
            System.out.println("examples:\n");
            System.out
                    .println("0x00000000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 xxxxxxxxxxxxxxxx --> t 10 2 16\n");
            System.out.println("00000000 0000 0000 0000 0000 0000 0000 0000 0000 xxxxxxxxxxxxxxxx --> t 8 4 16\n");
            System.out.println("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 xxxxxxxxxxxxxxxx --> t 0 2 16\n");
            System.out.println("0x00000000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 --> t 10 2 0\n");
            System.out.println(" 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 --> t 0 2 0\n");

            System.out.println("");
            return;
        }

        final String fileName = args[0];
        final String format = args[1];

        InputStream is = null;
        try {
            if (format.charAt(0) != 'b') {
                if (args.length != 5) {
                    return;
                }
                final int iOffsetLength = Integer.parseInt(args[2]);
                final int iDataLength = Integer.parseInt(args[3]);
                final int iASCIILength = Integer.parseInt(args[4]);
                is = DumpMessages.getInputStream(fileName, iOffsetLength, iDataLength, iASCIILength);
            } else {
                is = new FileInputStream(fileName);

            }

            DumpMessages.dumpMessages(is);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }

    }

    public static InputStream getInputStream(final String fileName, final int iOffsetLength, final int iDataLength,
            final int iASCIILength) throws IOException {
        final byte[] bArrayRead = new byte[32];
        InputStream is = null;
        final BufferedReader in = new BufferedReader(new FileReader(fileName));

        // Read the first line
        String line = null;
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final DataOutputStream dos = new DataOutputStream(baos);
        while (in.ready()) {
            line = in.readLine();

            final int iIdx = 0;
            String strRelevant = line.substring(iOffsetLength, line.length() - iOffsetLength - iASCIILength);
            strRelevant = strRelevant.replaceAll(" ", "");
            int iStart = 0;
            while (iStart < strRelevant.length()) {
                if ((iStart + iDataLength) > strRelevant.length()) {
                    break;
                }
                String strTemp = strRelevant.substring(iStart, iStart + iDataLength);
                if (strTemp.equals("")) {
                    break;
                }
                int iRead = 0;
                try {
                    strTemp = strTemp.replaceAll(" ", "");
                    iRead = Integer.parseInt(strTemp, 16);
                    System.out.print(" " + strTemp);
                } catch (final NumberFormatException ex) {
                    System.out.println("Number format exception while parsing ->" + strTemp + "<-");
                }
                iStart += iDataLength;
                if (iDataLength == 2) {
                    dos.writeByte(iRead);
                } else if (iDataLength == 4) {
                    dos.writeShort(iRead);
                } else if (iDataLength == 8) {
                    dos.writeInt(iRead);
                } else {
                    throw new IOException("Invalid data length ");
                }
            }
            System.out.println("");
        }

        final byte[] bytes = baos.toByteArray();
        // ByteArray ba = new ByteArray(bytes);
        // ba.dump(System.out);
        is = new ByteArrayInputStream(bytes);

        return is;
    }

    public static Vector getAllTheTokens(final String strLine) {
        final Vector ret = new Vector(18);
        final StringTokenizer strTok = new StringTokenizer(strLine, " ", false);
        while (strTok.hasMoreElements()) {
            ret.addElement(strTok.nextElement());
        }

        return ret;
    }

}
