package com.itaas.dsmcc.TestClass;

#include "DSMCCAdaptationHeader.h"
#include "DSMCCNsapAddr.h"
#include "DSMCCAdaHdrUserId.h"
#include "DSMCCMessageFactory.h"
#include "DSMCCServerStatusRequest.h"
#include "DSMCCServerStatusConfirm.h"
#include "DSMCCServerAddResourceRequest.h"
#include "DSMCCServerAddResourceConfirm.h"

#include "DSMCCServerReleaseIndication.h"
#include "DSMCCServerReleaseResponse.h"
#include "DSMCCServerReleaseRequest.h"
#include "DSMCCServerReleaseConfirm.h"

#include "DSMCCServerSessionSetUpResponse.h"
#include "DSMCCServerSessionSetUpIndication.h"
#include "DSMCCMpegProgramResDesc.h"
#include "DSMCCPhysicalChannelResourceDescriptor.h"
#include "DSMCCTSDownStreamBandwidthResourceDescriptor.h"
#include "DSMCCContinuousFeedSessionResourceDescriptor.h"
#include "DSMCCSessionSetupIndUserPvtData.h"
#include "cc++/socket.h"
#include "common/iTaas.h"
#include "common/Errors.h"
#include <iostream>
#include <map>

using std::cout;
using std::endl;
using std::map;

#define SERVER_PORT 13819
#define CLIENT_PORT 7777

typedef struct 
{
	unsigned long SSSI_TxnNo;
	unsigned long SARR_TxnNo;
	CDSMCCNsapAddrPtr ServerId;
} SessionInfo;

typedef map<long double,SessionInfo*> SESSLIST_TYPE;
SESSLIST_TYPE sess_List;
int tnum = 1;

void getSessionId(const char* sessStr,string& sessionidBytes)
{
	char temp[10];
	int iread	= sscanf(sessStr,"%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x",
		&temp[0],&temp[1],&temp[2],&temp[3],&temp[4],
		&temp[5],&temp[6],&temp[7],&temp[8],&temp[9]
		);
	sessionidBytes	= string(temp,10);
}

void printSessionId(const unsigned char* mac, unsigned long sessioncnt, char* ret )
{
	sprintf(ret,"%02x:%02x:%02x:%02x:%02x:%02x:%5d",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],ntohl(sessioncnt));
}

long double makeKey(const unsigned char* sessionId)
{
	long double ret	=0;
	ret	= *(long double*)(sessionId+2);
	return ret;
}

// This routine initalizes the socket library for Win32 plate form
RESULT_TYPE IntialzeSocketLayer()
{
#ifdef WIN32
	WORD        wVersionRequested;
	WSADATA     wsaData;

	wVersionRequested = MAKEWORD( 2, 2 );
	int err = WSAStartup ( wVersionRequested, &wsaData );
	if ( err != 0 )
	{
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		return en_FAIL;
	}

	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */

	if (    LOBYTE( wsaData.wVersion ) != 2 
		 || HIBYTE( wsaData.wVersion ) != 2 
	   )
	{
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		WSACleanup( );
		return en_FAIL; 
	}
#endif
	return en_PASS;
}



// This program is a sample program to test usage of DSMCC library
int main(int argc, char **argv)
{
	// get the ip address
	ost::InetHostAddress host(argv[1]);
	// get the cfs session id
	string sessionid;
	getSessionId(argv[2],sessionid);


	// Initialize the socket layer library for use with this application
	if ( RESULT_SUCCESS != IntialzeSocketLayer() )
	{
		ERROR_STREAM << "Could not Initialize the socket layer\n";
		exit(UNABLE_TO_INITIALIZE_SOCKET_LIB);
	}

	ost::TCPStream tcp_stream(host, SERVER_PORT);
	// Get the local IP address
	in_addr local_addr	= tcp_stream.getLocal().getAddress(0);
	cout << "Using dncsIP= " << argv[1] << " and localIP= " << inet_ntoa(local_addr) << endl;

	char sessPrint[48];
	
	if(true)
	{

		CDSMCCMessagePtr readmp;

		// compose the nsap address of this machine
		CDSMCCNsapAddrPtr mynp(new CDSMCCNsapAddr((DSMCC_UINT32) local_addr.S_un.S_addr));
		// Create an adapatation header with above NSAP address
		CDSMCCAdaptationHeaderPtr ahdrp(new CDSMCCAdaHdrUserId(mynp));

		// Now create a message header for a ServerStatusRequest message

		DSMCC_UINT32 txnid = 5;
		CDSMCCMessageHeaderPtr 
				ah
					(
						new CDSMCCMessageHeader(enUNSession,
							enServer_Status_Request, 
							enTxnIdAssignedByServer, 
							txnid, 
							ahdrp
						)
					);

		// Create the actual DSMCC message with reason = normal and given
		// user id

		CDSMCCServerStatusRequest ServerStatusRequest(ah, enRsnNormal, mynp);
	
		//TestMsgIO(ServerStatusRequest);
		printf("Send Server Status request  \n");


		// Now write the above message to the output stream
		// In this case, it is ofstream 
		ah->SetTransactionNumber(tnum++);
		ServerStatusRequest.Write(tcp_stream);
		tcp_stream.flush();
		
		// Now create an input stream with the same socket
		// and use the factory create method
		
		readmp = CDSMCCMessageFactory :: CreateMessage(tcp_stream);

		if(readmp == 0)
		{
			printf(" Null message \n"); 
		}
		if (readmp != 0 && readmp->GetMessageId() == enServer_Status_Confirm) 
		{
			printf("ServerStatusConfirm ... Now Server is Ready to accept messages.\n");
		}
		else
		{
			printf("Unable to read ServerStatusConfirm message\n");
		}

		CDSMCCCommonDescriptorHeaderPtr cdhp(new CDSMCCCommonDescriptorHeader
			(0x0a0b, // resourceRequestId,
			enContinuousFeedSession,
			0x8004, // resourceNum - server assigned
			0x8056, // ATAG - server assigned,
			0x83, //server view,Mand,NNeg,ServerAll
			enResStatRequested));
		// Create the session ID
		CDSMCCNsapAddrPtr ServerId;
		CDSMCCSessionIdPtr SessionId;

		// Now create an input stream with the same socket
		// and use the factory create method and wait till you get ServerSessionSetUp Indication
		int iLoopCnt =0;
		
		while(1)
		{
			//SessionList.DisplayList();
			readmp = CDSMCCMessageFactory :: CreateMessage(tcp_stream);

			if(readmp )
			{
				switch (readmp->GetMessageId()) 
				{
				case enServer_Session_Setup_Indication :
					{
						
						SessionInfo* sessInf	= new SessionInfo;
						// create the resourse descriptor
						CDSMCCSessionId sessionId( (DSMCC_UINT8*)sessionid.c_str());
						CDSMCCResFldVSessionId cfsID( sessionId );
						std::deque<CDSMCCResFldVUINT16> resNums;
						resNums.push_back( 2);
						resNums.push_back( 3);
						CDSMCCResourceDescriptorPtr cfsrdp
							( new CDSMCCContinuousFeedSessionResourceDescriptor( cdhp , cfsID,resNums));
						CDSMCCResourceContainerPtr rc(new CDSMCCResourceContainer);
						rc->AddResourceDescriptor(cfsrdp);

						// get the session id from the message
						sessInf->SSSI_TxnNo	= readmp->GetMessageHeader()->GetTransactionId();
						CDSMCCServerSessionSetUpIndication *ssindp = 
							(CDSMCCServerSessionSetUpIndication *) (CDSMCCMessage *)readmp;
						sessInf->ServerId  = ssindp->GetServerId();

						CDSMCCServerAddResourceRequest ServerAddResourceRequest(ah);
						SessionId = ssindp->GetSessionId();
						// 
						printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
						std::cout <<"Got  SSSI. "<< sessPrint << "\tSessCnt= " <<sess_List.size()<<"\n";

						ServerAddResourceRequest.SetSessionId(SessionId);
						
						// set the resources
						ServerAddResourceRequest.SetResources(rc);
						// set the Txn number
						ah->SetTransactionNumber(tnum++);

						ServerAddResourceRequest.Write(tcp_stream);
						
						long double key	=makeKey(SessionId->GetSessionId());
						sessInf->SARR_TxnNo	= tnum;
						sess_List.insert(SESSLIST_TYPE::value_type(key,sessInf));
						printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
						std::cout <<"Sent  SARR. "<< sessPrint << "\tSessCnt= " <<sess_List.size()<<"\n";

						
						break;
					}

				case enServer_Release_Indication :
					{
						
						CDSMCCServerReleaseIndication *srInd = 
							(CDSMCCServerReleaseIndication *) (CDSMCCMessage *)readmp;
						CDSMCCSessionIdPtr SessionId;
						
						SessionId = srInd->GetSessionId();

						printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
						printf("Got  SSRI. %s \tSessCnt= %d\n",sessPrint,sess_List.size());

						long double key	=makeKey(SessionId->GetSessionId());

						CDSMCCUserDataPtr indudp = srInd->GetUserData();
						CDSMCCServerReleaseResponse ServerReleaseResp(ah);

						ServerReleaseResp.SetSessionId(SessionId);
						ah->SetTransactionNumber(readmp->GetMessageHeader()->GetTransactionId());
						ServerReleaseResp.Write(tcp_stream);
						

						SESSLIST_TYPE::iterator it	= sess_List.find(key);
						if ( it !=sess_List.end())
						{
							delete (it->second);
							sess_List.erase(it);
						}
						printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
						std::cout <<"Sent  SSRR. "<< sessPrint << "\tSessCnt= " <<sess_List.size()<<"\n";

						break;
					}

				case enServer_Add_Resource_Confirm :
					{
						
						CDSMCCServerAddResourceConfirm *ssconfp =
							(CDSMCCServerAddResourceConfirm *) (CDSMCCMessage *)readmp;

						// Get the key
						SessionId = ssconfp->GetSessionId();
						
						printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
						printf("Got  SARC. %s \tSessCnt= %d\n",sessPrint,sess_List.size());

						long double key	=makeKey(SessionId->GetSessionId());
						SESSLIST_TYPE::iterator it	= sess_List.find(key);


						if ( it != sess_List.end())
						{
							SessionInfo* sessInf	= it->second;
							
							ah->SetTransactionId(sessInf->SSSI_TxnNo);
							ah->SetAdaptationHeader(ahdrp);						
							CDSMCCServerSessionSetUpResponse ServerSessionSetUpResponse(ah);

							// Set the ServerId as read from ServerSessionSetUpIndication 
							ServerSessionSetUpResponse.SetServerId(sessInf->ServerId);
							ServerSessionSetUpResponse.SetSessionId(SessionId);

							if (ssconfp->GetResponse() == enRspOK )
							{

								CDSMCCResourceContainerPtr res(new CDSMCCResourceContainer);
								res = ssconfp->GetResources();
								
								// Set the resources as read from ServerAddResourceConfirm
								ServerSessionSetUpResponse.SetResources(res);

								CDSMCCByteContainerPtr bcp = new CDSMCCByteContainer();
								CDSMCCUserDataPtr udptr = new CDSMCCUserData(bcp);
								ServerSessionSetUpResponse.SetUserData(udptr);
								ServerSessionSetUpResponse.Write(tcp_stream);
							}else
							{
								ServerSessionSetUpResponse.SetResponse(ssconfp->GetResponse());

								SESSLIST_TYPE::iterator it	= sess_List.find(key);
								if ( it !=sess_List.end())
								{
									delete (it->second);
									sess_List.erase(it);
								}

							}
							printSessionId(SessionId->GetMacAddress(),SessionId->GetSessionNumber(),sessPrint);
							printf("Sent SSSR. %s \tSessCnt= %d\n",sessPrint,sess_List.size());

						}

						break;

					}

				default :
					printf("\n Got.. Session Message 0x%x \n",readmp->GetMessageId());
				}
				
				tcp_stream.flush();
			}
		}
	}
	
	return 1;
}

