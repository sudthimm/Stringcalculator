/*
 * DSMCCResourceValue_Object.java Created on August 5, 2003, 4:33 PM
 */

/**
 * @author chintan.Desai.
 */
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;

public class DSMCCResourceValue_Object extends DSMCCResourceDescriptorValue {

    protected DSMCCObject M__Value;

    // protected DSMCCObject m_Factory;

    private DSMCCResourceValue_Object() {
    }

    public DSMCCResourceValue_Object(final DSMCCObject val) {
        this.setValue(val);
    }

    public DSMCCObject getValue() {
        return this.M__Value;
    }

    public void setValue(final DSMCCObject valValue) {
        this.M__Value = valValue;
    }

    public int readValue(final DSMCCInputStream dis) throws IOException {
        return this.M__Value.read(dis);
    }

    @Override
    public DSMCCObject createNewInstance() {
        return this.M__Value.createNewInstance();
    }
}
