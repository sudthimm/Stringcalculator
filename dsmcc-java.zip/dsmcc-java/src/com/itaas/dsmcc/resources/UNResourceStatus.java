// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNResourceStatus {

    public static final short enResStatReserved = 0x00;

    public static final short enResStatRequested = 0x01;

    public static final short enResStatInProgress = 0x02;

    public static final short enResStatAlternateAssigned = 0x03;

    public static final short enResStatAssigned = 0x04;

    public static final short enResStatFailed = 0x05;

    public static final short enResStatUnprocessed = 0x06;

    public static final short enResStatInvalid = 0x07;

    public static final short enResStatReleased = 0x08;

}
