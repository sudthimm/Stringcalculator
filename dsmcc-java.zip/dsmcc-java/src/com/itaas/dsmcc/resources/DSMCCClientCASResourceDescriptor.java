/*
 * DSMCCClientCASResourceDescriptor.java Created on August 12, 2003, 10:26 AM
 */

/**
 * @author chintan Desai
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 * The client Conditional Access resource descriptor is sent from the network to a client to inform it that
 * requested session is protected by the network conditional access system,this descriptor also contains the
 * information required by the conditional access system to gain access to that session.
 */

public class DSMCCClientCASResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Fixed m__CaSystemId;

    // protected DSMCCResourceValue_Fixed m__CaInfoLength;
    protected ByteArray m__CaInfoByte;

    public static final int TYPE = 0xF005;

    /* Creates a new instance of DSMCCServerCASResourceDescriptor */
    public DSMCCClientCASResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    private void init_Construct() {
        // documents are not always right :)
        // m__CaSystemId = new DSMCCResourceValue_Fixed((byte)2);
        this.m__CaSystemId = new DSMCCResourceValue_Fixed((byte) 4);

        // m__CaInfoLength = new DSMCCResourceValue_Fixed((byte)2);
        this.m__CaInfoByte = new ByteArray(ByteArray.UNSIGNED_SHORT);
    }

    public DSMCCResourceValue_Fixed getCaSystemId() {
        return this.m__CaSystemId;
    }

    public void setCaSystemId(final DSMCCResourceValue_Fixed valCaSystemId) {
        this.m__CaSystemId = valCaSystemId;
    }

    // public DSMCCResourceValue_Fixed getCaInfoLength()
    // {
    // return m__CaInfoLength;
    // }

    // public void setCaInfoLength(DSMCCResourceValue_Fixed valCaInfoLength)
    // {
    // m__CaInfoLength = valCaInfoLength;
    // }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        // m__CaSystemId = new DSMCCResourceValue_Fixed((byte)2); //documents are not always right :)
        this.m__CaSystemId = new DSMCCResourceValue_Fixed((byte) 4);
        iRet += this.m__CaSystemId.read(dis);

        this.m__CaInfoByte = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        iRet += this.m__CaInfoByte.read(dis);

        return iRet;
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(3);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCClientCASResourceDescriptor.TYPE);
    }

    public void setCaInfoByte(final ByteArray valCaInfoByte) {
        this.m__CaInfoByte = valCaInfoByte;
    }

    public ByteArray getCaInfoByte() {
        return this.m__CaInfoByte;
    }
}
