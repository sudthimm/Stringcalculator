// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class ResourceValueType {

    public static final int enSingleValue = 0x0001;

    public static final int enListValue = 0x0002;

    public static final int enRangeValue = 0x0003;

}
