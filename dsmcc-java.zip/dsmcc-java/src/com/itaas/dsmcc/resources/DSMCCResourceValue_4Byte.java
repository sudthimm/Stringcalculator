// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 10, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.resources;

import com.itaas.dsmcc.base.DSMCCObject;

public class DSMCCResourceValue_4Byte extends DSMCCResourceDescriptorValue {

    protected long m__Value;

    public DSMCCResourceValue_4Byte() {
    }

    public DSMCCResourceValue_4Byte(final int val) {
        this.m__Value = 0x00000000L | val;
    }

    public DSMCCResourceValue_4Byte(final long val) {
        this.setValue(val);
    }

    public long getValue() {
        return this.m__Value;
    }

    public void setValue(final long valValue) {
        this.m__Value = valValue;
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCResourceValue_4Byte();
    }
}
