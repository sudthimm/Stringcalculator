// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 9, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCQueue;

public class DSMCCResourceValue_List extends DSMCCResourceValue_Variable {

    protected int M__EncodingType;

    protected DSMCCQueue M__ValueList;

    public DSMCCResourceValue_List(final DSMCCResourceDescriptorValue type) {
        super(type);
        this.M__EncodingType = DSMCCResourceValue_Variable.LIST_ENCODING;
        this.M__ValueList = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, type);
    }

    public int readValueList(final DSMCCInputStream dis) throws IOException {
        final int iRet = 0;
        this.M__ValueList.read(dis);
        return iRet;
    }

    public DSMCCQueue getValueList() {
        return this.M__ValueList;
    }

    public void setValueList(final DSMCCQueue valValueList) {
        this.M__ValueList = valValueList;
    }

    @Override
    public int getEncodingType() {
        return this.M__EncodingType;
    }

    @Override
    protected void setEncodingType(final int valEncodingType) {
        this.M__EncodingType = valEncodingType;
    }

    public int readEncodingType(final DSMCCInputStream dis) throws IOException {
        // We do not want to read it, it has alredy been read
        return 0;
    }

    @Override
    public int getLength() {
        return super.getLength();
    }

    public int addValue(final DSMCCResourceDescriptorValue value) {
        this.M__ValueList.add(value);
        return this.M__ValueList.size();
    }

    /*
     * (non-Javadoc) This method might return null if the resource list is empty
     * @see com.itaas.dsmcc.resources.DSMCCResourceValue_Variable#getDefaultValue()
     */
    @Override
    public DSMCCResourceDescriptorValue getDefaultValue() {
        if (this.M__ValueList.size() > 0) {
            return (DSMCCResourceDescriptorValue) this.M__ValueList.getElement(0);
        } else {
            return null;
        }
    }

}
