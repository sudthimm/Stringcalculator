/*
 * DSMCCHeadEndIdResourceDescriptor.java Created on August 5, 2003, 3:10 PM
 */

/**
 * @author Chintan Desai
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.util.ByteConvertor;

/**
 * The HeadEnd shall be used to specify the HeadEnd and/or transport stream for distribution of a session to
 * the access network.
 */

public class DSMCCHeadEndIdResourceDescriptor extends DSMCCResourceDescriptor {

    DSMCCResourceValue_Fixed m__HeadEndFlag;

    DSMCCResourceValue_Fixed m__HeadEndId;

    DSMCCResourceValue_Fixed m__TransportStreamId;

    public static final int TYPE = 0xF003;

    public DSMCCHeadEndIdResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    public DSMCCHeadEndIdResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Fixed headEndFlag, final DSMCCResourceValue_Fixed headEndId,
            final DSMCCResourceValue_Fixed transportStreamId) {
        this.setHeader(hdr);
        this.m__HeadEndFlag = headEndFlag;
        this.m__HeadEndId = headEndId;
        this.m__TransportStreamId = transportStreamId;

    }

    private void init_Construct() {
        this.m__HeadEndFlag = new DSMCCResourceValue_Fixed((byte) 2);
        this.m__HeadEndId = new DSMCCResourceValue_Fixed((byte) 20);
        this.m__TransportStreamId = new DSMCCResourceValue_Fixed((byte) 4);
    }

    // /////////////////////////////////////////////////////////////////////////////
    public void setTransportStreamId(final DSMCCResourceValue_Fixed val) {
        this.m__TransportStreamId = val;
    }

    public DSMCCResourceValue_Fixed getTransportStreamId() {
        return this.m__TransportStreamId;
    }

    public void setHeadEndFlag(final DSMCCResourceValue_Fixed val) {
        this.m__HeadEndFlag = val;

    }

    public DSMCCResourceValue_Fixed getHeadEndFlag() {
        return this.m__HeadEndFlag;
    }

    public void setHeadEndId(final DSMCCResourceValue_Fixed headEndId) {
        this.m__HeadEndId = headEndId;
    }

    public DSMCCResourceValue_Fixed getHeadEndId() {
        return this.m__HeadEndId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__HeadEndFlag = new DSMCCResourceValue_Fixed((byte) 2);
        iRet += this.m__HeadEndFlag.read(dis);

        this.m__HeadEndId = new DSMCCResourceValue_Fixed((byte) 20);
        iRet += this.m__HeadEndId.read(dis);

        this.m__TransportStreamId = new DSMCCResourceValue_Fixed((byte) 4);
        iRet += this.m__TransportStreamId.read(dis);

        return iRet;
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(2);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCHeadEndIdResourceDescriptor.TYPE);
    }

    public static DSMCCHeadEndIdResourceDescriptor createresourceFromTSID_IN(final int tsIDIn) {
        final DSMCCCommonResourceDescriptorHeader cmnHdr = DSMCCCommonResourceDescriptorHeader.getDefaultCommonHeader();
        final DSMCCHeadEndIdResourceDescriptor retVal = new DSMCCHeadEndIdResourceDescriptor(cmnHdr);

        retVal.m__HeadEndFlag = new DSMCCResourceValue_Fixed((byte) 2);
        retVal.m__HeadEndFlag.setValue(4);

        retVal.m__HeadEndId = new DSMCCResourceValue_Fixed((byte) 20);
        final byte[] ba = new byte[20];
        ba[0] = (byte) (0x2d);
        retVal.m__HeadEndId.setValue(new ByteArray(ba));

        retVal.m__TransportStreamId = new DSMCCResourceValue_Fixed((byte) 4);
        retVal.m__TransportStreamId.m__Value = new ByteArray(ByteConvertor.toByteArray(tsIDIn));

        return retVal;
    }
}
