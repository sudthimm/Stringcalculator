/*
 * DSMCCTSDSBWResourceDescriptor.java Created on August 4, 2003, 4:24 PM
 */

/**
 * @author chintan Desai This is DSMCCTSDownStreamBandWidthResourceDescriptor
 */
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 *The TSUpstreamBandwidth resource descriptor is requested to allocate a portion of the upstream transport
 * stream for a session. Multiple TSUpstreamBandwidth resource descriptors may be requested for a session.
 * Table 4-79 defines the format of the TSUpstreamBandwidth resource descriptor.
 */

public class DSMCCTSDSBWResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__DownstreamBandwidth;

    protected DSMCCResourceValue_Variable m__DownstreamTransportId;

    public static final int TYPE = 0x0006;

    public DSMCCTSDSBWResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__DownstreamBandwidth = new DSMCCResourceValue_Single(new DSMCCResourceValue_4Byte());
        this.m__DownstreamTransportId = new DSMCCResourceValue_Single(new DSMCCResourceValue_4Byte());
    }

    public DSMCCTSDSBWResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Variable downstreamBandwidth,
            final DSMCCResourceValue_Variable downstreamTransportId) {
        this.setHeader(hdr);
        this.m__DownstreamBandwidth = downstreamBandwidth;
        this.m__DownstreamTransportId = downstreamTransportId;
    }

    public void setDownstreamBandwidth(final DSMCCResourceValue_Variable val) {
        this.m__DownstreamBandwidth = val;
    }

    public DSMCCResourceValue_Variable getDownstreamBandwidth() {
        return this.m__DownstreamBandwidth;
    }

    public void setDownstreamTransportId(final DSMCCResourceValue_Variable val) {
        this.m__DownstreamTransportId = val;
    }

    public DSMCCResourceValue_Variable getDownstreamTransportId() {
        return this.m__DownstreamTransportId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final int iTmp = 0;
        final Integer iRead = new Integer(0);

        this.m__DownstreamBandwidth = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        this.m__DownstreamTransportId = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(2);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCTSDSBWResourceDescriptor.TYPE);
    }

    public static DSMCCTSDSBWResourceDescriptor createResource(final long bandWidth, final long tsid) {
        final DSMCCCommonResourceDescriptorHeader cmnHdr = DSMCCCommonResourceDescriptorHeader.getDefaultCommonHeader();
        final DSMCCTSDSBWResourceDescriptor retVal = new DSMCCTSDSBWResourceDescriptor(cmnHdr);
        retVal.setDownstreamBandwidth(new DSMCCResourceValue_Single(bandWidth));
        retVal.setDownstreamTransportId(new DSMCCResourceValue_Single(tsid));

        return retVal;
    }

}
