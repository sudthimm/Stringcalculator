/*
 * DSMCCServerCASResourceDescriptor.java Created on August 11, 2003, 2:41 PM
 */

/**
 * @author Chintan Desai
 */
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCQueue;

/**
 *The server conditional access Resource Descriptor is sent from the server to the Network to instruct it to
 * protect the contents of the session using the conditional access system provided by the Network,this
 * descriptor also instructs the network to grant access to the session to a list of clients.
 */

public class DSMCCServerCASResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__CaSystemId;

    protected DSMCCResourceValue_Fixed m__CopyProtection;

    protected DSMCCResourceValue_Fixed m__UserCount;

    protected DSMCCQueue m__UserId;

    public static final int TYPE = 0xF004;

    /* Creates a new instance of DSMCCServerCASResourceDescriptor */
    public DSMCCServerCASResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
        this.m__UserId = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCNsapAddress());
    }

    private void init_Construct() {
        this.m__CaSystemId = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte());
        this.m__CopyProtection = new DSMCCResourceValue_Fixed((byte) 2);
        this.m__UserCount = new DSMCCResourceValue_Fixed((byte) 2);
        this.m__UserId = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCNsapAddress());
    }

    public DSMCCResourceValue_Variable getCaSystemId() {
        return this.m__CaSystemId;
    }

    public void setCaSystemId(final DSMCCResourceValue_Variable valCaSystemId) {
        this.m__CaSystemId = valCaSystemId;
    }

    public DSMCCResourceValue_Fixed getCopyProtection() {
        return this.m__CopyProtection;
    }

    public void setCopyProtection(final DSMCCResourceValue_Fixed valCopyProtection) {
        this.m__CopyProtection = valCopyProtection;
    }

    public DSMCCResourceValue_Fixed getUserCount() {
        return this.m__UserCount;
    }

    public void setUserCount(final DSMCCResourceValue_Fixed valUserCount) {
        this.m__UserCount = valUserCount;
    }

    public DSMCCQueue getUserId() {
        return this.m__UserId;
    }

    public void setUserId(final DSMCCQueue valUserId) {
        this.m__UserId = valUserId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        int iTmp = 0;
        final Integer iRead = new Integer(0);

        this.m__CaSystemId = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__CopyProtection = new DSMCCResourceValue_Fixed((byte) 2);
        iTmp += this.m__CopyProtection.read(dis);

        this.m__UserCount = new DSMCCResourceValue_Fixed((byte) 2);
        iTmp += this.m__UserCount.read(dis);

        this.m__UserId = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCNsapAddress());
        iTmp += this.m__UserId.read(dis);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(3);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCServerCASResourceDescriptor.TYPE);
    }

}
