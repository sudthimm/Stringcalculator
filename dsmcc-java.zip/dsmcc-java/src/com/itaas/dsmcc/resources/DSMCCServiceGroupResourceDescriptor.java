/*
 * Copyright iTaas, Inc. 2005 Created by krishna on Jun 21, 2005 No Portion of this file can be copied or
 * reproduced in any form without prior written approval. TODO To change the template for this generated file
 * go to Window - Preferences - Java - Code Style - Code Templates
 */
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.util.ByteConvertor;

/**
*
*
*/

public class DSMCCServiceGroupResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Fixed m__SericeGroup;

    public static final int TYPE = 0xf007;

    public DSMCCServiceGroupResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__SericeGroup = new DSMCCResourceValue_Fixed((byte) 6);
    }

    public DSMCCServiceGroupResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Fixed sericeGroup) {
        this.setHeader(hdr);
        this.m__SericeGroup = sericeGroup;
    }

    public void setSericeGroup(final DSMCCResourceValue_Fixed val) {
        this.m__SericeGroup = val;
    }

    public void setSericeGroup(final int val) {
        final byte[] ba = ByteConvertor.toByteArrayFromUnsignedShort(val);
        final byte[] ba6 = new byte[6];
        // ba6[3] = (byte)(1);
        ba6[4] = ba[0];
        ba6[5] = ba[1];
        this.m__SericeGroup = new DSMCCResourceValue_Fixed((byte) 6);
        this.m__SericeGroup.setValue(new ByteArray(ba6));
    }

    public DSMCCResourceValue_Fixed getSericeGroup() {
        return this.m__SericeGroup;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final int iTmp = 0;
        final Integer iRead = new Integer(0);

        this.m__SericeGroup = new DSMCCResourceValue_Fixed((byte) 6);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(1);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCServiceGroupResourceDescriptor.TYPE);
    }

    public static DSMCCServiceGroupResourceDescriptor createResource(final int serviceGrp) {
        final DSMCCCommonResourceDescriptorHeader cmnHdr = DSMCCCommonResourceDescriptorHeader.getDefaultCommonHeader();
        final DSMCCServiceGroupResourceDescriptor retVal = new DSMCCServiceGroupResourceDescriptor(cmnHdr);
        retVal.setSericeGroup(serviceGrp);

        return retVal;
    }

}
