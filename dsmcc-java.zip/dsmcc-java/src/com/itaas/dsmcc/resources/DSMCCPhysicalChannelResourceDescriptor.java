/*
 * DSMCCPhysicalChannelResourceDescriptor.java Created on August 4, 2003, 11:12 AM
 */

/**
 * @author chintan.Desai
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

/**
 *The intended use for the PhysicalChannel resource descriptor is to allocate and/or indicate the use of a
 * specific logical channel in a frequency division multiplexed medium, e.g. the tuner channels on a Hybrid
 * Fiber Coax (HFC) system.
 */

public class DSMCCPhysicalChannelResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__ChannleId;

    protected DSMCCResourceValue_Fixed m__Direction;

    public static final int TYPE = 0x0004;

    /** Creates a new instance of DSMCCPhysicalChannelResourceDescriptor */
    public DSMCCPhysicalChannelResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.setHeader(hdr);
    }

    public DSMCCPhysicalChannelResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Variable valchannleId, final DSMCCResourceValue_Fixed valdirection) {
        this.setHeader(hdr);
        this.m__ChannleId = valchannleId;
        this.m__Direction = valdirection;
    }

    public void setDirection(final DSMCCResourceValue_Fixed valdirection) {
        this.m__Direction = valdirection;
    }

    public DSMCCResourceValue_Fixed getDirection() {
        return this.m__Direction;
    }

    public void setChannleId(final DSMCCResourceValue_Variable valchannleId) {
        this.m__ChannleId = valchannleId;
    }

    public DSMCCResourceValue_Variable getChannleId() {
        return this.m__ChannleId;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iTmp = 0;
        final Integer iRead = new Integer(0);
        this.m__ChannleId = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        this.m__Direction = new DSMCCResourceValue_Fixed((byte) 2);
        iTmp += this.m__Direction.read(dis);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        // int i = 1/0;
        this.m__Header.setResourceDataFieldCount(2);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCPhysicalChannelResourceDescriptor.TYPE);
    }

}
