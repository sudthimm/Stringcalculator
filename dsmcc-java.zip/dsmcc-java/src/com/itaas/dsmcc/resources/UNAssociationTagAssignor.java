// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNAssociationTagAssignor {

    public static final int enAssTagByClient = 0x01;

    public static final int enAssTagByServer = 0x10;

    public static final int enAssTagByNetwork = 0x11;

}
