// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 10, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCQueue;
import com.itaas.dsmcc.base.DSMCCSessionID;

/**
 *The ContinuousFeedSession resource descriptor is requested by the Server to connect a Client session to a
 * continuous feed session which has been previously established. When the Network receives this resource in a
 * response from the Server to a session set-up indication or in a session set-up request from the server,
 * then the Network shall connect the indicated resources from that continuous feed session to the session
 * which is being established. Table 4-74 defines the format of the ContinuousFeedSession descriptor.
 */

public class DSMCCContinuousFeedSessionResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__CFSessionId;

    protected DSMCCQueue m__ResourceNumbers;

    public static final int TYPE = 0x0001;

    public DSMCCContinuousFeedSessionResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__CFSessionId = new DSMCCResourceValue_Single(new DSMCCResourceValue_Object(new DSMCCSessionID()));
        this.m__ResourceNumbers = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, null);
    }

    public DSMCCResourceValue_Variable getCFSessionId() {
        return this.m__CFSessionId;
    }

    public DSMCCSessionID getCFSessionId_() {
        DSMCCSessionID sess = null;
        if (this.m__CFSessionId instanceof DSMCCResourceValue_Single) {
            final DSMCCResourceValue_Single singleObj = (DSMCCResourceValue_Single) this.m__CFSessionId;
            final DSMCCObject obj = singleObj.getValue();
            sess = (DSMCCSessionID) obj;
        }
        return sess;
    }

    public void setCFSessionId(final DSMCCSessionID valCFSessionId) {
        final DSMCCResourceValue_Object obj = new DSMCCResourceValue_Object(valCFSessionId);
        this.m__CFSessionId = new DSMCCResourceValue_Single(obj);
    }

    public void setCFSessionId(final DSMCCResourceValue_Variable valCFSessionId) {
        this.m__CFSessionId = valCFSessionId;
    }

    public DSMCCQueue getResourceNumbers() {
        return this.m__ResourceNumbers;
    }

    public void setResourceNumbers(final DSMCCQueue valResourceNumbers) {
        this.m__ResourceNumbers = valResourceNumbers;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final Integer iRead = new Integer(0);
        this.m__CFSessionId = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_Object(
                new DSMCCSessionID()), iRead);

        // Create the queue
        if (this.m__ResourceNumbers == null) {
            // We will not use the read method of the queue so we can pass null
            // as the second argument
            this.m__ResourceNumbers = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, null);
        }
        // Read the resource numbers
        final int iResCnt = dis.readUShort();

        for (int iCnt = 0; iCnt < iResCnt; iCnt++) {
            final DSMCCResourceDescriptorValue typeObj = new DSMCCResourceValue_2Byte();
            final DSMCCResourceValue_Variable resNum = DSMCCResourceValue_Variable.create(dis, typeObj, iRead);
            this.m__ResourceNumbers.add(resNum);
        }

        return iRead.intValue();
    }

    public int addResourceResourceNumber(final int resNumber) {
        this.m__ResourceNumbers.add(new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(resNumber)));

        return this.m__ResourceNumbers.size();
    }

    @Override
    public void updateResourceDataFieldCount() {
        final int iRet = this.m__ResourceNumbers.size();
        this.m__Header.setResourceDataFieldCount(1 + iRet);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCContinuousFeedSessionResourceDescriptor.TYPE);
    }

    @Override
    public int getLength() {
        return super.getLength();
    }

}
