// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNResourceAllocator {

    public static final int enResAllocByUnspecified = 0x00;

    public static final int enResAllocByClient = 0x01;

    public static final int enResAllocByServer = 0x10;

    public static final int enResAllocByNetwork = 0x11;

}
