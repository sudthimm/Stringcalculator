// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 18, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCInputStream;

public class DSMCCUnknownResource extends DSMCCResourceDescriptor {

    protected ByteArray M__PayLoad;

    public DSMCCUnknownResource(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.setHeader(hdr);
    }

    public int readPayLoad(final DSMCCInputStream dis) throws IOException {
        final int iLen = this.m__Header.getResourceLength();
        this.M__PayLoad = new ByteArray(iLen, ByteArray.EMPTY);
        return this.M__PayLoad.read(dis);
    }

    public ByteArray getPayLoad() {
        return this.M__PayLoad;
    }

    public void setPayLoad(final ByteArray valPayLoad) {
        this.M__PayLoad = valPayLoad;
    }

    @Override
    public void updateResourceDataFieldCount() {
        final int i = 0; // 1/0;
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        // m__Header.setResourceDescriptorType(0x0000);
    }

}
