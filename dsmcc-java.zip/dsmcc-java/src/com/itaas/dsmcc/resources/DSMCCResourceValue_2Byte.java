// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 10, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.resources;

import com.itaas.dsmcc.base.DSMCCObject;

public class DSMCCResourceValue_2Byte extends DSMCCResourceDescriptorValue {

    protected int m__Value;

    public DSMCCResourceValue_2Byte() {
    }

    public DSMCCResourceValue_2Byte(final int val) {
        this.setValue(val);
    }

    public int getValue() {
        return this.m__Value;
    }

    public void setValue(final int valValue) {
        this.m__Value = valValue;
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCResourceValue_2Byte();
    }
}
