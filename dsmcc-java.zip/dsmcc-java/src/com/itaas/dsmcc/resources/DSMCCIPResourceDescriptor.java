/*
 * DSMCCIpResourceDescriptor.java Created on August 4, 2003, 12:53 PM
 */

/**
 * @author chintan.Desai.
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.util.ByteConvertor;

/**
 *The IP resource descriptor is requested by the server to indicate that IP data is being transported.
 */

public class DSMCCIPResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__SourceIPAddress;

    protected DSMCCResourceValue_Variable m__SourceIPPort;

    protected DSMCCResourceValue_Variable m__DestinationIPAddress;

    protected DSMCCResourceValue_Variable m__DestinationIPPort;

    protected DSMCCResourceValue_Variable m__IPProtocol;

    public static final int TYPE = 0x0009;

    private void init_Construct() {
        this.m__SourceIPAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_4Byte(0));
        this.m__SourceIPPort = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(0));
        this.m__DestinationIPAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_4Byte(0));
        this.m__DestinationIPPort = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(0));
        this.m__IPProtocol = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(0));
    }

    public DSMCCIPResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    public DSMCCIPResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Variable sourceIP, final DSMCCResourceValue_Variable sourcePort,
            final DSMCCResourceValue_Variable destinationIP, final DSMCCResourceValue_Variable destinationPort,
            final DSMCCResourceValue_Variable protocol) {
        this.setHeader(hdr);
        this.m__SourceIPAddress = sourceIP;
        this.m__SourceIPPort = sourcePort;
        this.m__DestinationIPAddress = destinationIP;
        this.m__DestinationIPPort = destinationPort;
        this.m__IPProtocol = protocol;
    }

    public void setSourceIPAddress(final DSMCCResourceValue_Variable val) {
        this.m__SourceIPAddress = val;
    }

    public DSMCCResourceValue_Variable getSourceIPAddress() {
        return this.m__SourceIPAddress;

    }

    public void setSourceIPPort(final DSMCCResourceValue_Variable val) {
        this.m__SourceIPPort = val;
    }

    public DSMCCResourceValue_Variable getSourceIPPort() {
        return this.m__SourceIPPort;
    }

    // /////////////////////////////////////////////////////////////////////////////

    // /////////////////////////////////////////////////////////////////////////////
    public void setDestinationIPAddress(final DSMCCResourceValue_Variable val) {
        this.m__DestinationIPAddress = val;
    }

    public DSMCCResourceValue_Variable getDestinationIPAddress() {
        return this.m__DestinationIPAddress;

    }

    // /////////////////////////////////////////////////////////////////////////////

    // /////////////////////////////////////////////////////////////////////////////
    public void setDestinationIPPort(final DSMCCResourceValue_Variable val) {
        this.m__DestinationIPPort = val;
    }

    public DSMCCResourceValue_Variable getDestinationIPPort() {
        return this.m__DestinationIPPort;
    }

    // /////////////////////////////////////////////////////////////////////////////

    // /////////////////////////////////////////////////////////////////////////////
    public void setIPProtocol(final DSMCCResourceValue_Variable val) {
        this.m__IPProtocol = val;
    }

    public DSMCCResourceValue_Variable getIPProtocol() {
        return this.m__IPProtocol;

    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final int iTmp = 0;
        final Integer iRead = new Integer(0);
        this.m__SourceIPAddress = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        this.m__SourceIPPort = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__DestinationIPAddress = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        this.m__DestinationIPPort = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__IPProtocol = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(5);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCIPResourceDescriptor.TYPE);
    }

    public static DSMCCIPResourceDescriptor getResource() {
        final DSMCCIPResourceDescriptor ipDesc = new DSMCCIPResourceDescriptor(DSMCCCommonResourceDescriptorHeader
                .getDefaultCommonHeader());
        return ipDesc;

    }

    public void setSourceIP(final Inet4Address ipAddress) {
        final byte[] bytes = ipAddress.getAddress();
        this.m__SourceIPAddress = DSMCCResourceValue_Single.get4BytesValuefromLong(ByteConvertor
                .fromByteArrayToLong(bytes));
    }

    public void setDestinationIP(final Inet4Address ipAddress) {
        final byte[] bytes = ipAddress.getAddress();
        this.m__DestinationIPAddress = DSMCCResourceValue_Single.get4BytesValuefromLong(ByteConvertor
                .fromByteArrayToLong(bytes));
    }

    public Inet4Address getSourceIP() {

        Inet4Address ret = null;
        final DSMCCResourceDescriptorValue val = this.m__SourceIPAddress.getDefaultValue();
        if (val != null) {
            final long value = ((DSMCCResourceValue_4Byte) (val)).m__Value;
            try {
                ret = (Inet4Address) (Inet4Address.getByAddress(ByteConvertor.toByteArray(value)));
            } catch (final UnknownHostException e) {
            }
        }

        return ret;
    }

    public Inet4Address getDestinationIP() {
        Inet4Address ret = null;
        final DSMCCResourceDescriptorValue val = this.m__DestinationIPAddress.getDefaultValue();
        if (val != null) {
            final long value = ((DSMCCResourceValue_4Byte) (val)).m__Value;
            try {
                ret = (Inet4Address) (Inet4Address.getByAddress(ByteConvertor.toByteArray(value)));
            } catch (final UnknownHostException e) {
            }
        }
        return ret;
    }

    public void setSourcePort(final int port) {
        this.m__SourceIPPort = DSMCCResourceValue_Single.get2BytesValuefromInt(port);
    }

    public int getSourcePort() {
        int iret = 0;
        final DSMCCResourceDescriptorValue val = this.m__SourceIPPort.getDefaultValue();
        if (val != null) {
            iret = ((DSMCCResourceValue_2Byte) (val)).m__Value;
        }

        return iret;
    }

    public void setDestinationPort(final int port) {
        this.m__SourceIPPort = DSMCCResourceValue_Single.get2BytesValuefromInt(port);
    }

    public int getDestinationPort() {
        int iret = 0;
        final DSMCCResourceDescriptorValue val = this.m__DestinationIPPort.getDefaultValue();
        if (val != null) {
            iret = ((DSMCCResourceValue_2Byte) (val)).m__Value;
        }

        return iret;
    }

}
