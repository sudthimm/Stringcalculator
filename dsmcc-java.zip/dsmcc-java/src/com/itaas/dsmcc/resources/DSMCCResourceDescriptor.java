// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;
import java.io.PrintStream;

import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCOutputStream;

public abstract class DSMCCResourceDescriptor extends DSMCCObject {

    protected DSMCCCommonResourceDescriptorHeader m__Header;

    // protected Vector m__DataFields;

    /*
     * public DSMCCResourceDescriptor(DSMCCCommonResourceDescriptorHeader hdr) { setHeader(hdr); }
     */
    public DSMCCResourceDescriptor() {

    }

    public DSMCCCommonResourceDescriptorHeader getHeader() {
        return this.m__Header;
    }

    public abstract void setHeader(DSMCCCommonResourceDescriptorHeader valHeader);

    // {
    // m__Header= valHeader;
    // }

    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        this.updateResourceDataFieldCount();
        this.m__Header.setResourceLength(super.getLength());
        // Write the header
        iRet = this.m__Header.write(dos);

        // write our fields
        iRet += super.write(dos);

        return iRet;
    }

    @Override
    public void dump(final PrintStream ps) throws IOException {
        // setPrintWriter(ps);
        ps.println(DSMCCObject.m_strIndent + this.getClass());
        this.m__Header.dump(ps);
        ps.println("");
        super.dump(ps);
    }

    public abstract void updateResourceDataFieldCount();

    @Override
    public int getLength() {
        return (this.m__Header.getLength() + super.getLength());
    }

}
