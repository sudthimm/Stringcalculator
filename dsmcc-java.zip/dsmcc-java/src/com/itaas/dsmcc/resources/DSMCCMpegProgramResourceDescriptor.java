// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 10, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCQueue;

/**
 *The MpegProgram descriptor is requested by the Server to request the allocation of MPEG resources (Program
 * Number and PIDs) needed to deliver an MPEG Program to the Client. If the Server is the resourceAllocator,
 * the Server shall fill in the mpegProgramNum and PIDs (mpegPmtPid, mpegPid) values to inform the Network of
 * the values selected by the Server. If the resourceAllocator is the Network the mpegProgramNum and PIDs must
 * be initially set to 0 by the Server and the Network will return Network allocated values.
 */

public class DSMCCMpegProgramResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__MpegProgramNumber;

    protected DSMCCResourceValue_Variable m__MpegPmtPid;

    protected DSMCCResourceValue_Fixed m__MpegCaPid;

    protected DSMCCQueue m__ElementoryStreams;

    protected DSMCCResourceValue_Variable m__MpegPcr;

    public static final int TYPE = 0x0003;

    public DSMCCMpegProgramResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__MpegProgramNumber = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte());
        this.m__MpegPmtPid = new DSMCCResourceValue_Single(0xffff);
        this.m__MpegCaPid = DSMCCResourceValue_Fixed.creteDSMCCResourceValues_FixedFromUnsignedShort(0xffff);
        this.m__ElementoryStreams = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCElementoryStream());
        this.m__MpegPcr = new DSMCCResourceValue_Single(0xffff);
    }

    public DSMCCResourceValue_Variable getMpegProgramNumber() {
        return this.m__MpegProgramNumber;
    }

    public void setMpegProgramNumber(final DSMCCResourceValue_Variable valMpegProgramNumber) {
        this.m__MpegProgramNumber = valMpegProgramNumber;
    }

    public void setMpegProgramNumber(final int pgmNumber) {
        this.m__MpegProgramNumber = new DSMCCResourceValue_Single(pgmNumber);
    }

    public DSMCCResourceValue_Variable getMpegPmtPid() {
        return this.m__MpegPmtPid;
    }

    public void setMpegPmtPid(final DSMCCResourceValue_Variable valMpegPmtPid) {
        this.m__MpegPmtPid = valMpegPmtPid;
    }

    public DSMCCResourceValue_Fixed getMpegCaPid() {
        return this.m__MpegCaPid;
    }

    public void setMpegCaPid(final DSMCCResourceValue_Fixed valMpegCaPid) {
        this.m__MpegCaPid = valMpegCaPid;
    }

    public DSMCCQueue getElementoryStreams() {
        return this.m__ElementoryStreams;
    }

    public void setElementoryStreams(final DSMCCQueue valElementoryStreams) {
        this.m__ElementoryStreams = valElementoryStreams;
    }

    public DSMCCResourceValue_Variable getMpegPcr() {
        return this.m__MpegPcr;
    }

    public void setMpegPcr(final DSMCCResourceValue_Variable valMpegPcr) {
        this.m__MpegPcr = valMpegPcr;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        final Integer iRead = new Integer(0);

        this.m__MpegProgramNumber = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__MpegPmtPid = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__MpegCaPid = new DSMCCResourceValue_Fixed((byte) 2);
        int iTmp = this.m__MpegCaPid.read(dis);

        this.m__ElementoryStreams = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCElementoryStream());
        iTmp += this.m__ElementoryStreams.read(dis);

        this.m__MpegPcr = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(this.m__ElementoryStreams.size() + 4);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCMpegProgramResourceDescriptor.TYPE);
    }

    public static DSMCCMpegProgramResourceDescriptor createMpegProgramNumberServerView(final int pgmNumber) {
        final DSMCCCommonResourceDescriptorHeader cmnHdr = DSMCCCommonResourceDescriptorHeader.getDefaultCommonHeader();

        final DSMCCMpegProgramResourceDescriptor retVal = new DSMCCMpegProgramResourceDescriptor(cmnHdr);
        retVal.setMpegProgramNumber(pgmNumber);
        return retVal;
    }

    public static DSMCCMpegProgramResourceDescriptor getSRMMpegProgramNumber(final int pgmNumber) {
        return null;
    }

}
