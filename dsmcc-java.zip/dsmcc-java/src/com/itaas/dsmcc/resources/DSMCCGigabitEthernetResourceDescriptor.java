/*
 * DSMCCIpResourceDescriptor.java Created on Oct 18, 2004, 10:23 AM
 */

/**
 * @author Krishna C Tripathi.
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.IpAddress;
import com.itaas.dsmcc.base.MacAddress;

/**
 * Giga bit ethernet is can be used in place of ASI to transmit video
 */
public class DSMCCGigabitEthernetResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__SourceIPPort;

    protected DSMCCResourceValue_Variable m__SourceIPAddress;

    protected DSMCCResourceValue_Variable m__SourceMacAddress;

    protected DSMCCResourceValue_Variable m__DestinationIPPort;

    protected DSMCCResourceValue_Variable m__DestinationIPAddress;

    protected DSMCCResourceValue_Variable m__DestinationMacAddress;

    public static final int TYPE = 0xf006;

    public DSMCCGigabitEthernetResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__SourceIPAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_Object(new IpAddress()));
        this.m__SourceIPPort = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(0));
        this.m__SourceMacAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_Object(new MacAddress()));

        this.m__DestinationIPAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_Object(new IpAddress()));
        this.m__DestinationIPPort = new DSMCCResourceValue_Single(new DSMCCResourceValue_2Byte(0));
        this.m__DestinationMacAddress = new DSMCCResourceValue_Single(new DSMCCResourceValue_Object(new MacAddress()));
    }

    public DSMCCGigabitEthernetResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Variable sourceIPPort, final DSMCCResourceValue_Variable sourceIPAddress,
            final DSMCCResourceValue_Variable sourceMacAddress, final DSMCCResourceValue_Variable destinationIPPort,
            final DSMCCResourceValue_Variable destinationIPAddress,
            final DSMCCResourceValue_Variable destinationMacAddress) {
        this.setHeader(hdr);
        this.m__SourceIPPort = sourceIPPort;
        this.m__SourceIPAddress = sourceIPAddress;
        this.m__SourceMacAddress = sourceMacAddress;
        this.m__DestinationIPPort = destinationIPPort;
        this.m__DestinationIPAddress = destinationIPAddress;
        this.m__DestinationMacAddress = destinationMacAddress;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final int iTmp = 0;
        final Integer iRead = new Integer(0);

        this.m__SourceIPPort = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);
        this.m__SourceIPAddress = DSMCCResourceValue_Variable.create(dis,
                new DSMCCResourceValue_Object(new IpAddress()), iRead);
        this.m__SourceMacAddress = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_Object(
                new MacAddress()), iRead);

        this.m__DestinationIPPort = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);
        this.m__DestinationIPAddress = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_Object(
                new IpAddress()), iRead);
        this.m__DestinationMacAddress = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_Object(
                new MacAddress()), iRead);

        return iTmp + iRead.intValue();
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(6);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCGigabitEthernetResourceDescriptor.TYPE);
    }

    /**
     * @return Returns the m__DestinationIPAddress.
     */
    public DSMCCResourceValue_Variable getDestinationIPAddress() {
        return this.m__DestinationIPAddress;
    }

    /**
     * @param destinationIPAddress
     *            The m__DestinationIPAddress to set.
     */
    public void setDestinationIPAddress(final DSMCCResourceValue_Variable destinationIPAddress) {
        this.m__DestinationIPAddress = destinationIPAddress;
    }

    /**
     * @return Returns the m__DestinationIPPort.
     */
    public DSMCCResourceValue_Variable getDestinationIPPort() {
        return this.m__DestinationIPPort;
    }

    /**
     * @param destinationIPPort
     *            The m__DestinationIPPort to set.
     */
    public void setDestinationIPPort(final DSMCCResourceValue_Variable destinationIPPort) {
        this.m__DestinationIPPort = destinationIPPort;
    }

    /**
     * @return Returns the m__DestinationMacAddress.
     */
    public DSMCCResourceValue_Variable getDestinationMacAddress() {
        return this.m__DestinationMacAddress;
    }

    /**
     * @param destinationMacAddress
     *            The m__DestinationMacAddress to set.
     */
    public void setDestinationMacAddress(final DSMCCResourceValue_Variable destinationMacAddress) {
        this.m__DestinationMacAddress = destinationMacAddress;
    }

    /**
     * @return Returns the m__SourceIPAddress.
     */
    public DSMCCResourceValue_Variable getSourceIPAddress() {
        return this.m__SourceIPAddress;
    }

    /**
     * @param sourceIPAddress
     *            The m__SourceIPAddress to set.
     */
    public void setSourceIPAddress(final DSMCCResourceValue_Variable sourceIPAddress) {
        this.m__SourceIPAddress = sourceIPAddress;
    }

    /**
     * @return Returns the m__SourceIPPort.
     */
    public DSMCCResourceValue_Variable getSourceIPPort() {
        return this.m__SourceIPPort;
    }

    /**
     * @param sourceIPPort
     *            The m__SourceIPPort to set.
     */
    public void setSourceIPPort(final DSMCCResourceValue_Variable sourceIPPort) {
        this.m__SourceIPPort = sourceIPPort;
    }

    /**
     * @return Returns the m__SourceMacAddress.
     */
    public DSMCCResourceValue_Variable getSourceMacAddress() {
        return this.m__SourceMacAddress;
    }

    /**
     * @param sourceMacAddress
     *            The m__SourceMacAddress to set.
     */
    public void setSourceMacAddress(final DSMCCResourceValue_Variable sourceMacAddress) {
        this.m__SourceMacAddress = sourceMacAddress;
    }

}
