// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObjectFactory;

public class DSMCCResourceDescriptorFactory extends DSMCCObjectFactory {

    public static DSMCCResourceDescriptor create(final DSMCCInputStream dis, final Integer IRead) {
        DSMCCResourceDescriptor ret = null;
        int iRead = 0;
        DSMCCCommonResourceDescriptorHeader cmnHdr = null;
        try {
            cmnHdr = new DSMCCCommonResourceDescriptorHeader();
            iRead = cmnHdr.read(dis);
            if (iRead > 0) {
                switch (cmnHdr.getResourceDescriptorType()) {

                    case DSMCCMpegProgramResourceDescriptor.TYPE: {
                        ret = new DSMCCMpegProgramResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCIPResourceDescriptor.TYPE: {
                        ret = new DSMCCIPResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCPhysicalChannelResourceDescriptor.TYPE: {
                        ret = new DSMCCPhysicalChannelResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCTSDSBWResourceDescriptor.TYPE: {
                        ret = new DSMCCTSDSBWResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCSharedResourceDescriptor.TYPE: {
                        ret = new DSMCCSharedResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCHeadEndIdResourceDescriptor.TYPE: {
                        ret = new DSMCCHeadEndIdResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCATSCModulationModeResourceDescriptor.TYPE: {
                        ret = new DSMCCATSCModulationModeResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCContinuousFeedSessionResourceDescriptor.TYPE: {
                        ret = new DSMCCContinuousFeedSessionResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCClientCASResourceDescriptor.TYPE: {
                        ret = new DSMCCClientCASResourceDescriptor(cmnHdr);
                        break;
                    }
                    case DSMCCGigabitEthernetResourceDescriptor.TYPE: {
                        ret = new DSMCCGigabitEthernetResourceDescriptor(cmnHdr);
                        break;
                    }
                    default: {
                        ret = new DSMCCUnknownResource(cmnHdr);
                    }
                }
                if (ret == null) {
                    // System.out.println("could not create resource for " );
                    cmnHdr.dump(System.out);
                }
                iRead += ret.read(dis);
            }
        } catch (final IOException ex) {
            try {
                cmnHdr.dump(System.out);
            } catch (final Exception e) {

            }
            // ret = null;
        }

        Integer.parseInt("" + iRead);
        return ret;
    }
}
