// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 18, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCOutputStream;

/**
 * @author developer TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class DSMCCCommonResourceDescriptorHeader extends DSMCCObject {

    public static final int RESOURCE_NUMBER_ASSIGNER_SERVER = 0x8000;

    public static final int RESOURCE_NUMBER_ASSIGNER_NETWORK = 0xC000;

    public static final int ASSOCIATION_TAG_ASSIGNER_SERVER = 0x8000;

    public static final int ASSOCIATION_TAG_ASSIGNER_NETWORK = 0xC000;

    public static final short RESOURCE_VIEW_RESERVED_1 = 0x00;

    public static final short RESOURCE_VIEW_CLIENT = 0x40;

    public static final short RESOURCE_VIEW_SERVER = 0x80;

    public static final short RESOURCE_VIEW_RESERVED_2 = 0xC0;

    public static final short RESOURCE_ALLOCATOR_UNSPECIFIED = 0x00;

    public static final short RESOURCE_ALLOCATOR_CLIENT = 0x01;

    public static final short RESOURCE_ALLOCATOR_SERVER = 0x02;

    public static final short RESOURCE_ALLOCATOR_NETWORK = 0x03;

    public static final short RESOURCE_ATTRIBUTE_MANDATORY_NONNEGOTIABLE = 0x00;

    public static final short RESOURCE_ATTRIBUTE_MANDATORY_NEGOTIABLE = 0x04;

    public static final short RESOURCE_ATTRIBUTE_NONMANDATORY_NONNEGOTIABLE = 0x08;

    public static final short RESOURCE_ATTRIBUTE_NONMANDATORY_NEGOTIABLE = 0x0C;

    public static final short RESOURCE_STATUS_RESERVED = 0x00;

    public static final short RESOURCE_STATUS_REQUESTED = 0x01;

    public static final short RESOURCE_STATUS_INPROGRESS = 0x02;

    public static final short RESOURCE_STATUS_ALTERNATE_ASSIGNED = 0x03;

    public static final short RESOURCE_STATUS_ASSIGNED = 0x04;

    public static final short RESOURCE_STATUS_FAILED = 0x05;

    public static final short RESOURCE_STATUS_UNPROCESSED = 0x06;

    public static final short RESOURCE_STATUS_INVALID = 0x07;

    public static final short RESOURCE_STATUS_RELEASED = 0x08;

    public static short m_ResourceNumber;

    protected int m__ResourceRequestId;

    protected int m__ResourceDescriptorType;

    protected int m__ResourceNum;

    protected int m__AssociationTag;

    protected short m__ResourceFlags;

    protected short m__ResourceStatus;

    protected int m__ResourceLength;

    protected int m__ResourceDataFieldCount;

    protected int m_TypeOwnerId;

    protected int m_TypeOwnerValue;

    static {
        DSMCCCommonResourceDescriptorHeader.m_ResourceNumber = 1;
    }

    public DSMCCCommonResourceDescriptorHeader() {
        // Nothing needs to be done, as all the memebers are primary data types.
    }

    /**
     * The methof used by the constructors
     * 
     * @param rrid
     *            ResourceRequestId
     * @param rdt
     *            ResourceDescriptorType
     * @param rn
     *            ResourceNum
     * @param at
     *            AssociationTag
     * @param rf
     *            ResourceFlags
     * @param rs
     *            ResourceStatus
     * @param rl
     *            ResourceLength
     * @param rdfc
     *            ResourceDataFieldCount
     * @param toi
     *            TypeOwnerId
     * @param tov
     *            TypeOwnerValue
     */
    private void init_Construct(final int rrid, // ResourceRequestId
            final int rdt, // ResourceDescriptorType
            final int rn, // ResourceNum
            final int at, // AssociationTag
            final short rf, // ResourceFlags
            final short rs, // ResourceStatus
            final int rl, // ResourceLength
            final int rdfc, // ResourceDataFieldCount
            final int toi, // TypeOwnerId
            final int tov // TypeOwnerValue
    ) {
        this.m__ResourceRequestId = rrid;
        this.m__ResourceDescriptorType = rdt;
        this.m__ResourceNum = rn;
        this.m__AssociationTag = at;
        this.m__ResourceFlags = rf;
        this.m__ResourceStatus = rs;
        this.m__ResourceLength = rl;
        this.m__ResourceDataFieldCount = rdfc;
        if (this.m__ResourceDescriptorType == 0xffff) {
            this.m_TypeOwnerId = toi;
            this.m_TypeOwnerValue = tov;
        }
    }

    // The exhaustive constructor
    /**
     * @param rrid
     *            ResourceRequestId
     * @param rdt
     *            ResourceDescriptorType
     * @param rn
     *            ResourceNum
     * @param at
     *            AssociationTag
     * @param rf
     *            ResourceFlags
     * @param rs
     *            ResourceStatus
     * @param rl
     *            ResourceLength
     * @param rdfc
     *            ResourceDataFieldCount
     * @param toi
     *            TypeOwnerId
     * @param tov
     *            TypeOwnerValue
     */
    public DSMCCCommonResourceDescriptorHeader(final int rrid, // ResourceRequestId
            final int rdt, // ResourceDescriptorType
            final int rn, // ResourceNum
            final int at, // AssociationTag
            final short rf, // ResourceFlags
            final short rs, // ResourceStatus
            final int rl, // ResourceLength
            final int rdfc, // ResourceDataFieldCount
            final int toi, // TypeOwnerId
            final int tov // TypeOwnerValue
    ) {
        this.init_Construct(rrid, rdt, rn, at, rf, rs, rl, rdfc, toi, tov);
    }

    // A constructor for the cases when we are not defining the "not so relevant" fileds.
    /**
     * @param rrid
     *            ResourceRequestId
     * @param rdt
     *            ResourceDescriptorType
     * @param rn
     *            ResourceNum
     * @param at
     *            AssociationTag
     * @param rf
     *            ResourceFlags
     * @param rs
     *            ResourceStatus
     */
    public DSMCCCommonResourceDescriptorHeader(final int rrid, // ResourceRequestId
            final int rdt, // ResourceDescriptorType
            final int rn, // ResourceNum
            final int at, // AssociationTag
            final short rf, // ResourceFlags
            final short rs // ResourceStatus
    ) {
        this.init_Construct(rrid, rdt, rn, at, rf, rs, 0, 0, 0, 0);
    }

    // A constructor for the cases when we want to define only what is must
    /**
     * @param rrid
     *            ResourceRequestId
     * @param rn
     *            ResourceNum
     * @param at
     *            AssociationTag
     * @param rf
     *            ResourceFlags
     * @param rs
     *            ResourceStatus
     */
    public DSMCCCommonResourceDescriptorHeader(final int rrid, // ResourceRequestId
            final int rn, // ResourceNum
            final int at, // AssociationTag
            final short rf, // ResourceFlags
            final short rs // ResourceStatus
    ) {
        this.init_Construct(rrid, 0, rn, at, rf, rs, 0, 0, 0, 0);
    }

    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        dos.writeUShort(this.m__ResourceRequestId);
        iRet += 2;
        dos.writeUShort(this.m__ResourceDescriptorType);
        iRet += 2;
        dos.writeUShort(this.m__ResourceNum);
        iRet += 2;
        dos.writeUShort(this.m__AssociationTag);
        iRet += 2;
        dos.writeUByte(this.m__ResourceFlags);
        iRet++;
        dos.writeUByte(this.m__ResourceStatus);
        iRet++;
        dos.writeUShort(this.m__ResourceLength);
        iRet += 2;
        dos.writeUShort(this.m__ResourceDataFieldCount);
        iRet += 2;
        if (this.m__ResourceDescriptorType == 0xffff) {
            int sh1, sh2, sh3;
            sh1 = this.m_TypeOwnerId >>> 8;
            sh2 = (this.m_TypeOwnerId & 0x000000FF) << 8 | (this.m_TypeOwnerValue & 0x00FF0000) >>> 8;
            sh3 = this.m_TypeOwnerValue & 0x0000FFFF;
            dos.writeUShort(sh1);
            iRet += 2;
            dos.writeUShort(sh2);
            iRet += 2;
            dos.writeUShort(sh3);
            iRet += 2;
        }

        return iRet;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;
        this.m__ResourceRequestId = dis.readUShort();
        iRet += 2;
        this.m__ResourceDescriptorType = dis.readUShort();
        iRet += 2;
        this.m__ResourceNum = dis.readUShort();
        iRet += 2;
        this.m__AssociationTag = dis.readUShort();
        iRet += 2;
        this.m__ResourceFlags = dis.readUByte();
        iRet++;
        this.m__ResourceStatus = dis.readUByte();
        iRet++;
        this.m__ResourceLength = dis.readUShort();
        iRet += 2;
        this.m__ResourceDataFieldCount = dis.readUShort();
        iRet += 2;
        if (this.m__ResourceDescriptorType == 0xffff) {
            int sh1, sh2, sh3;
            sh1 = dis.readUShort();
            iRet++;
            sh2 = dis.readUShort();
            iRet++;
            sh3 = dis.readUShort();
            iRet++;
            this.m_TypeOwnerId = (sh1 << 8) | ((sh2 & 0xff00) >> 8);
            this.m_TypeOwnerValue = ((sh2 & 0x00ff) << 16) | sh3;
        }

        return iRet;
    }

    public int getResourceRequestId() {
        return this.m__ResourceRequestId;
    }

    public void setResourceRequestId(final int valResourceRequestId) {
        this.m__ResourceRequestId = valResourceRequestId;
    }

    public int getResourceDescriptorType() {
        return this.m__ResourceDescriptorType;
    }

    public void setResourceDescriptorType(final int valResourceDescriptorType) {
        this.m__ResourceDescriptorType = valResourceDescriptorType;
    }

    public int getResourceNum() {
        return this.m__ResourceNum;
    }

    public void setResourceNum(final int valResourceNum) {
        this.m__ResourceNum = valResourceNum;
    }

    public int getAssociationTag() {
        return this.m__AssociationTag;
    }

    public void setAssociationTag(final int valAssociationTag) {
        this.m__AssociationTag = valAssociationTag;
    }

    public short getResourceFlags() {
        return this.m__ResourceFlags;
    }

    public void setResourceFlags(final short valResourceFlags) {
        this.m__ResourceFlags = valResourceFlags;
    }

    public short getResourceStatus() {
        return this.m__ResourceStatus;
    }

    public void setResourceStatus(final short valResourceStatus) {
        this.m__ResourceStatus = valResourceStatus;
    }

    public int getResourceLength() {
        return this.m__ResourceLength;
    }

    public void setResourceLength(final int valResourceLength) {
        this.m__ResourceLength = valResourceLength;
    }

    public int getResourceDataFieldCount() {
        return this.m__ResourceDataFieldCount;
    }

    public void setResourceDataFieldCount(final int valResourceDataFieldCount) {
        this.m__ResourceDataFieldCount = valResourceDataFieldCount;
    }

    public int getypeOwnerId() {
        return this.m_TypeOwnerId;
    }

    public void setTypeOwnerId(final int valTypeOwnerId) {
        this.m_TypeOwnerId = valTypeOwnerId;
    }

    public int getTypeOwnerValue() {
        return this.m_TypeOwnerValue;
    }

    public void setTypeOwnerValue(final int valTypeOwnerValue) {
        this.m_TypeOwnerValue = valTypeOwnerValue;
    }

    public static DSMCCCommonResourceDescriptorHeader getDefaultCommonHeader() {

        // Create the common descriptor header
        final DSMCCCommonResourceDescriptorHeader cmnHeader = new DSMCCCommonResourceDescriptorHeader(
                0x0001, // ResourceRequestId
                0, // ResourceDescriptorType
                DSMCCCommonResourceDescriptorHeader.RESOURCE_NUMBER_ASSIGNER_SERVER
                        | DSMCCCommonResourceDescriptorHeader.m_ResourceNumber++, //
                DSMCCCommonResourceDescriptorHeader.ASSOCIATION_TAG_ASSIGNER_SERVER | 0x01, // All are
                                                                                            // assciated in
                                                                                            // only one group
                (short) (DSMCCCommonResourceDescriptorHeader.RESOURCE_VIEW_SERVER
                        | DSMCCCommonResourceDescriptorHeader.RESOURCE_ATTRIBUTE_MANDATORY_NONNEGOTIABLE | DSMCCCommonResourceDescriptorHeader.RESOURCE_ALLOCATOR_SERVER),
                DSMCCCommonResourceDescriptorHeader.RESOURCE_STATUS_REQUESTED);

        return cmnHeader;

    }
}
