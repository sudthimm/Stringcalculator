// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 9, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

public class DSMCCResourceValue_Range extends DSMCCResourceValue_Variable {

    protected int M__EncodingType;

    protected DSMCCResourceDescriptorValue M__BestValue;

    protected DSMCCResourceDescriptorValue M__WorstValue;

    public DSMCCResourceValue_Range(final DSMCCResourceDescriptorValue bestValue) {
        super(bestValue);
        this.M__EncodingType = DSMCCResourceValue_Variable.RANGE_ENCODING;
        this.M__BestValue = bestValue;
        this.M__WorstValue = (DSMCCResourceDescriptorValue) bestValue.createNewInstance();
    }

    public DSMCCResourceValue_Range(final DSMCCResourceDescriptorValue bestValue,
            final DSMCCResourceDescriptorValue worstValue) {
        super(bestValue);
        this.M__EncodingType = DSMCCResourceValue_Variable.RANGE_ENCODING;
        this.M__BestValue = bestValue;
        this.M__WorstValue = worstValue;
    }

    public DSMCCResourceDescriptorValue getBestValue() {
        return this.M__BestValue;
    }

    public void setBestValue(final DSMCCResourceDescriptorValue valBestValue) {
        this.M__BestValue = valBestValue;
    }

    public DSMCCResourceDescriptorValue getWorstValue() {
        return this.M__WorstValue;
    }

    public void setWorstValue(final DSMCCResourceDescriptorValue valWorstValue) {
        this.M__WorstValue = valWorstValue;
    }

    @Override
    public int getEncodingType() {
        return this.M__EncodingType;
    }

    @Override
    protected void setEncodingType(final int valEncodingType) {
        this.M__EncodingType = valEncodingType;
    }

    public int readEncodingType(final DSMCCInputStream dis) throws IOException {
        // We do not want to read it, it has alredy been read
        return 0;
    }

    public int readBestValue(final DSMCCInputStream dis) throws IOException {
        // We do not want to read it, it has alredy been read
        this.M__BestValue.read(dis);
        return 0;
    }

    public int readWorstValue(final DSMCCInputStream dis) throws IOException {
        // We do not want to read it, it has alredy been read
        this.M__WorstValue = (DSMCCResourceDescriptorValue) this.M__BestValue.createNewInstance();
        this.M__WorstValue.read(dis);
        return 0;
    }

    @Override
    public DSMCCResourceDescriptorValue getDefaultValue() {
        return this.getBestValue();
    }

}
