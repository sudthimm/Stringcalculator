// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNResourceAttribute {

    public static final int enMandatoryNonNegotiable = 0x0000;

    public static final int enMandatoryNegotiable = 0x0001;

    public static final int enNonMandatoryNonNegotiable = 0x0010;

    public static final int enNonMandatoryNegotiable = 0x0011;

}
