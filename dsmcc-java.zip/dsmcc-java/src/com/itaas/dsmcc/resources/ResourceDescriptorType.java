// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class ResourceDescriptorType {

    public static final int enReserved = 0x0000;

    public static final int enUnknownResource = 0x0000;

    public static final int enContinuousFeedSession = 0x0001;

    public static final int enAtmConnection = 0x0002;

    public static final int enMpegProgram = 0x0003;

    public static final int enPhysicalChannel = 0x0004;

    public static final int enTsUpStreamBandwidth = 0x0005;

    public static final int enTSDownStreamBandwidth = 0x0006;

    public static final int enAtmSvcConnection = 0x0007;

    public static final int enConnectionNotify = 0x0008;

    public static final int enIP = 0x0009;

    public static final int enClientTDMAAssignment = 0x000A;

    public static final int enPSTNSetup = 0x000B;

    public static final int enNISDNSetup = 0x000C;

    public static final int enNISDNConnection = 0x000D;

    public static final int enQ922Connections = 0x000E;

    public static final int enHeadEndList = 0x000F;

    public static final int enAtmVcConnection = 0x0010;

    public static final int enSdbContinuousFeed = 0x0011;

    public static final int enSdbAssociations = 0x0012;

    public static final int enSdbEntitlemaent = 0x0013;

    public static final int enATSCModulationMode = 0xF001;

    public static final int enHeadEndIdResource = 0xF003; // It is the one in Pegasus document

    public static final int enEthernetResource = 0xF006;

    public static final int enSharedResource = 0x7FFE;

    public static final int enSharedRequestId = 0x7FFF;

    public static final int enTypeOwner = 0xffff;

}
