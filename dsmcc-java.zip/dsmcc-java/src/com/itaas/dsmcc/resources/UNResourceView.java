// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNResourceView {

    public static final int enClientResourceView = 0x01;

    public static final int enServerResourceView = 0x10;

}
