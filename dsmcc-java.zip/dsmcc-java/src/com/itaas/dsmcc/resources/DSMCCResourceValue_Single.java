// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date July 9, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

public class DSMCCResourceValue_Single extends DSMCCResourceValue_Variable {

    protected int M__EncodingType;

    protected DSMCCResourceDescriptorValue M__Value;

    public DSMCCResourceValue_Single(final DSMCCResourceDescriptorValue value) {
        super(value);
        this.M__EncodingType = DSMCCResourceValue_Variable.SINGLE_ENCODING;
        this.M__Value = value;
    }

    public DSMCCResourceValue_Single(final int value) {
        super(new DSMCCResourceValue_2Byte(value));
        this.M__EncodingType = DSMCCResourceValue_Variable.SINGLE_ENCODING;
        this.M__Value = this.m_ObjectType;

    }

    public DSMCCResourceValue_Single(final long value) {
        super(new DSMCCResourceValue_4Byte(value));
        this.M__EncodingType = DSMCCResourceValue_Variable.SINGLE_ENCODING;
        this.M__Value = this.m_ObjectType;

    }

    public DSMCCResourceDescriptorValue getValue() {
        return this.M__Value;
    }

    public void setValue(final DSMCCResourceDescriptorValue valValue) {
        this.M__Value = valValue;
    }

    public void setValue(final DSMCCResourceValue_1Byte valValue) {
        this.M__Value = valValue;
    }

    public void setValue(final DSMCCResourceValue_2Byte valValue) {
        this.M__Value = valValue;
    }

    public void setValue(final DSMCCResourceValue_4Byte valValue) {
        this.M__Value = valValue;
    }

    @Override
    public int getEncodingType() {
        return this.M__EncodingType;
    }

    @Override
    protected void setEncodingType(final int valEncodingType) {
        this.M__EncodingType = valEncodingType;
    }

    public int readEncodingType(final DSMCCInputStream dis) throws IOException {
        // We do not want to read it, it has alredy been read
        return 0;
    }

    public int readValue(final DSMCCInputStream dis) throws IOException {
        return this.M__Value.read(dis);
    }

    @Override
    public int getLength() {
        return super.getLength();
    }

    public static DSMCCResourceValue_Single get1BytesValuefromShort(final short value) {
        final DSMCCResourceValue_1Byte temp = new DSMCCResourceValue_1Byte();
        temp.setValue(value);
        return new DSMCCResourceValue_Single(temp);
    }

    public static DSMCCResourceValue_Single get2BytesValuefromInt(final int value) {
        final DSMCCResourceValue_2Byte temp = new DSMCCResourceValue_2Byte();
        temp.setValue(value);
        return new DSMCCResourceValue_Single(temp);
    }

    public static DSMCCResourceValue_Single get4BytesValuefromLong(final long value) {
        final DSMCCResourceValue_4Byte temp = new DSMCCResourceValue_4Byte();
        temp.setValue(value);
        return new DSMCCResourceValue_Single(temp);
    }

    @Override
    public DSMCCResourceDescriptorValue getDefaultValue() {
        return this.getValue();
    }

}
