// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCQueue;

public class DSMCCResourceValueQueue extends DSMCCQueue {

    DSMCCResourceValueQueue(final int iSize, final DSMCCObject valFactory) {
        super(-1 * iSize, valFactory);
    }
}
