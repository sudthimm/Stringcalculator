// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;

public abstract class DSMCCResourceValue_Variable extends DSMCCObject {

    public static final short SINGLE_ENCODING = 1;

    public static final short LIST_ENCODING = 2;

    public static final short RANGE_ENCODING = 3;

    // public final short RESERVED_ENCODING = 0x0004-0x7fff;
    // public final short USERDEFINED_ENCODING= 0x8000-0xffff;

    protected DSMCCResourceDescriptorValue m_ObjectType;

    protected DSMCCResourceValue_Variable(final DSMCCResourceDescriptorValue objType) {
        this.m_ObjectType = objType;
    }

    public static DSMCCResourceValue_Variable create(final DSMCCInputStream dis,
            final DSMCCResourceDescriptorValue objectType, final Integer iRead) throws IOException {
        int iRet = 0;
        DSMCCResourceValue_Variable valRet = null;

        final int encodingType = dis.readUShort();
        iRet += 2;

        switch (encodingType) {
            case SINGLE_ENCODING: {
                valRet = new DSMCCResourceValue_Single(objectType);
                iRet += valRet.read(dis);
                break;
            }
            case LIST_ENCODING: {
                valRet = new DSMCCResourceValue_List(objectType);
                iRet += valRet.read(dis);
                break;
            }
            case RANGE_ENCODING: {
                valRet = new DSMCCResourceValue_Range(objectType);
                iRet += valRet.read(dis);
                break;
            }
            default: {
                DSMCCResourceValue_Variable.otherEncoding(dis);
            }
        }
        Integer.parseInt("" + (iRet + iRead.intValue()));

        return valRet;
    }

    /**
     * This method can be overwritten by the sub-classes if other encoding methods are needed.
     * 
     * @param dis
     *            the input stream.
     */
    public static int otherEncoding(final DSMCCInputStream dis) throws IOException {
        throw new IOException("Unknown Encoding");
    }

    public abstract int getEncodingType();

    protected abstract void setEncodingType(int valEncodingType);

    protected abstract DSMCCResourceDescriptorValue getDefaultValue();

}
