// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;

public class DSMCCElementoryStream extends DSMCCResourceDescriptorValue {

    protected DSMCCResourceValue_Variable m__MpegPid;

    protected DSMCCResourceValue_Variable m__StreamType;

    protected DSMCCResourceValue_Fixed m__Reserved;

    protected DSMCCResourceValue_Variable m__AssociationTag;

    public DSMCCElementoryStream() {
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        final Integer iRead = new Integer(0);
        int iTmp = 0;
        this.m__MpegPid = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        this.m__StreamType = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_1Byte(), iRead);

        this.m__Reserved = new DSMCCResourceValue_Fixed((byte) 1);
        iTmp += this.m__Reserved.read(dis);

        this.m__AssociationTag = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_2Byte(), iRead);

        return iTmp + iRead.intValue();
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCElementoryStream();
    }
}
