// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.util.ByteConvertor;

public class DSMCCResourceValue_Fixed extends DSMCCResourceDescriptorValue {

    protected ByteArray m__Value;

    public DSMCCResourceValue_Fixed(final byte iSize) {
        this.m__Value = new ByteArray(iSize, ByteArray.EMPTY);
    }

    private DSMCCResourceValue_Fixed() {
        this.m__Value = null;
    }

    public ByteArray getValue() {
        return this.m__Value;
    }

    public void setValue(final ByteArray valValue) {
        this.m__Value = valValue;
    }

    public void setValue(final int iVal) {
        this.m__Value = new ByteArray(ByteConvertor.toByteArrayFromUnsignedShort(iVal));
    }

    public static DSMCCResourceValue_Fixed creteDSMCCResourceValues_FixedFromUnsignedShort(final int iVal) {
        final DSMCCResourceValue_Fixed retVal = new DSMCCResourceValue_Fixed();
        retVal.setValue(iVal);
        return retVal;
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCResourceValue_Fixed();
    }

}
