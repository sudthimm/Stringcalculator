// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

public class UNResourceNumAssignor {

    public static final int enResNumAssignedByClient = 0x01;

    public static final int enResNumAssignedByServer = 0x10;

    public static final int enResNumAssignedByNetwork = 0x11;

}
