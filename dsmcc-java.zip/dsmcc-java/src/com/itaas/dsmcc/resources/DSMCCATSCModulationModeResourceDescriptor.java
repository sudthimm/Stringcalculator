/*
 * DSMCCATSCModulationModeResDesc.java Created on August 4, 2003, 8:59 AM
 */

/**
 * @author chintan Desai No Documentation found for this in chapter-4
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

public class DSMCCATSCModulationModeResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Fixed m__TransmissionSystem;

    protected DSMCCResourceValue_Fixed m__InnerCodingMode;

    protected DSMCCResourceValue_Fixed m__SplitBitStreamMode;

    protected DSMCCResourceValue_Fixed m__ModulationFormat;

    protected DSMCCResourceValue_Fixed m__SymbolRate;

    protected DSMCCResourceValue_Fixed m__Reserved;

    protected DSMCCResourceValue_Fixed m__InterleaveDepth;

    protected DSMCCResourceValue_Fixed m__ModulationMode;

    protected DSMCCResourceValue_Fixed m__ForwardErrorCorrection;

    public static final int TYPE = 0XF001;

    /** Creates a new instance of DSMCCATSCModulationModeResDesc */
    public DSMCCATSCModulationModeResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    private void init_Construct() {
        this.m__TransmissionSystem = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__InnerCodingMode = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__SplitBitStreamMode = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__ModulationFormat = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__SymbolRate = new DSMCCResourceValue_Fixed((byte) 4);
        this.m__Reserved = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__InterleaveDepth = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__ModulationMode = new DSMCCResourceValue_Fixed((byte) 1);
        this.m__ForwardErrorCorrection = new DSMCCResourceValue_Fixed((byte) 1);
    }

    public void setTransmissionSystem(final DSMCCResourceValue_Fixed valTransmissionSystem) {
        this.m__TransmissionSystem = valTransmissionSystem;
    }

    public DSMCCResourceValue_Fixed getTransmissionSystem() {
        return this.m__TransmissionSystem;
    }

    public void setInnerCodingMode(final DSMCCResourceValue_Fixed valInnerCodingMode) {
        this.m__InnerCodingMode = valInnerCodingMode;
    }

    public DSMCCResourceValue_Fixed getInnerCodingMode() {
        return this.m__InnerCodingMode;
    }

    public void setSplitBitStreamMode(final DSMCCResourceValue_Fixed valSplitBitStreamMode) {
        this.m__SplitBitStreamMode = valSplitBitStreamMode;
    }

    public DSMCCResourceValue_Fixed getSplitBitStreamMode() {
        return this.m__SplitBitStreamMode;
    }

    public void setModulationFormat(final DSMCCResourceValue_Fixed valModulationFormat) {
        this.m__ModulationFormat = valModulationFormat;
    }

    public DSMCCResourceValue_Fixed getModulationFormat() {
        return this.m__ModulationFormat;
    }

    public void setSymbolRate(final DSMCCResourceValue_Fixed valSymbolRate) {
        this.m__SymbolRate = valSymbolRate;
    }

    public DSMCCResourceValue_Fixed getSymbolRate() {
        return this.m__SymbolRate;
    }

    public void setReserved(final DSMCCResourceValue_Fixed valReserved) {
        this.m__Reserved = valReserved;
    }

    public DSMCCResourceValue_Fixed getReserved() {
        return this.m__Reserved;
    }

    public void setInterleaveDepth(final DSMCCResourceValue_Fixed valInterleaveDepth) {
        this.m__InterleaveDepth = valInterleaveDepth;
    }

    public DSMCCResourceValue_Fixed getInterleaveDepth() {
        return this.m__InterleaveDepth;
    }

    public void setModulationMode(final DSMCCResourceValue_Fixed valModulationMode) {
        this.m__ModulationMode = valModulationMode;
    }

    public DSMCCResourceValue_Fixed getModulationMode() {
        return this.m__ModulationMode;
    }

    public void setForwardErrorCorrection(final DSMCCResourceValue_Fixed valForwardErrorCorrection) {
        this.m__ForwardErrorCorrection = valForwardErrorCorrection;
    }

    public DSMCCResourceValue_Fixed getForwardErrorCorrection() {
        return this.m__ForwardErrorCorrection;
    }

    /*
     * The number of Bytes required by each of these attributes is not known due to no availabledocumentation
     * on DSMCCATSCModulationModeResourceDescriptor ,so the number of bytes areassumed,not the real one
     */

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m__TransmissionSystem = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__TransmissionSystem.read(dis);

        this.m__InnerCodingMode = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__InnerCodingMode.read(dis);

        this.m__SplitBitStreamMode = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__SplitBitStreamMode.read(dis);

        this.m__ModulationFormat = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__ModulationFormat.read(dis);

        this.m__SymbolRate = new DSMCCResourceValue_Fixed((byte) 4);
        iRet += this.m__SymbolRate.read(dis);

        this.m__Reserved = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__Reserved.read(dis);

        this.m__InterleaveDepth = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__InterleaveDepth.read(dis);

        this.m__ModulationMode = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__ModulationMode.read(dis);

        this.m__ForwardErrorCorrection = new DSMCCResourceValue_Fixed((byte) 1);
        iRet += this.m__ForwardErrorCorrection.read(dis);

        return iRet;
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(9);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCATSCModulationModeResourceDescriptor.TYPE);
    }

}
