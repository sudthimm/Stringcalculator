// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCQueue;

public class DSMCCResourceDescriptorContainer extends DSMCCQueue {

    public DSMCCResourceDescriptorContainer(final int iLength) {
        super(DSMCCQueue.UNSIGNED_SHORT, null);
    }

    public DSMCCResourceDescriptorContainer() {
        super(DSMCCQueue.UNSIGNED_SHORT, null);
    }

    public void addResourceField(final DSMCCResourceDescriptor drdf) {
        this.add(drdf);
    }

    public DSMCCResourceDescriptor getResourceField(final int idx) {
        final DSMCCResourceDescriptor ret = (DSMCCResourceDescriptor) this.getElement(idx);
        return ret;
    }

    public int getResourceFieldCount() {
        return this.size();
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        final Integer iRead = new Integer(0);
        int iRet = 0;

        final int size = dis.readUShort();

        for (int iCnt = 0; iCnt < size; iCnt++) {
            final DSMCCResourceDescriptor val = DSMCCResourceDescriptorFactory.create(dis, iRead);
            this.add(val);
            iRet += iRead.intValue();
        }
        return iRet;
    }

}
