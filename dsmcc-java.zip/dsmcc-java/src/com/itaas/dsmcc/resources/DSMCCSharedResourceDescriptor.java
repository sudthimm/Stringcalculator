/*
 * DSMCCSharedResourceDescriptor.java Created on August 4, 2003, 12:01 PM
 */

/**
 * @author chintan.desai
 */

package com.itaas.dsmcc.resources;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;

public class DSMCCSharedResourceDescriptor extends DSMCCResourceDescriptor {

    protected DSMCCResourceValue_Variable m__sharedResourceNum;

    public static final int TYPE = 0x07ffe;

    /** Creates a new instance of DSMCCSharedResourceDescriptor */

    public DSMCCSharedResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr) // /<constructor
    {
        this.setHeader(hdr);
    }

    public DSMCCSharedResourceDescriptor(final DSMCCCommonResourceDescriptorHeader hdr,
            final DSMCCResourceValue_Variable valsharedResourceRequestId) {

        this.setHeader(hdr);
        this.m__sharedResourceNum = valsharedResourceRequestId;
    }

    private void init_Construct() {
        this.m__sharedResourceNum = new DSMCCResourceValue_Single(new DSMCCResourceValue_4Byte());
    }

    public void setSharedResourceRequestId(final DSMCCResourceValue_Variable valsharedResourceRequestId) {
        this.m__sharedResourceNum = valsharedResourceRequestId;
    }

    public DSMCCResourceValue_Variable getSharedResourceRequestId() {
        return this.m__sharedResourceNum;
    }

    @Override
    public void updateResourceDataFieldCount() {
        this.m__Header.setResourceDataFieldCount(1);
    }

    @Override
    public void setHeader(final DSMCCCommonResourceDescriptorHeader hdr) {
        this.m__Header = hdr;
        this.m__Header.setResourceDescriptorType(DSMCCSharedResourceDescriptor.TYPE);
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {

        final int iTmp = 0;
        final Integer iRead = new Integer(0);

        this.m__sharedResourceNum = DSMCCResourceValue_Variable.create(dis, new DSMCCResourceValue_4Byte(), iRead);

        return iTmp + iRead.intValue();
    }

}
