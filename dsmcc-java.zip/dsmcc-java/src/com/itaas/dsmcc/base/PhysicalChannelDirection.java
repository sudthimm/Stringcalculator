// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class PhysicalChannelDirection {

    public static final int enPhChDownstream = 0x0000;

    public static final int enPhChUpstream = 0x0001;

}
