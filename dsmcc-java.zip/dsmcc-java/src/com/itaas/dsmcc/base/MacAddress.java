// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 24, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import com.itaas.dsmcc.util.ByteConvertor;

public class MacAddress extends ByteArray {

    private String asString = null;

    private String asNoColonString = null;

    /**
     * Construct an all zero mac address.
     */
    public MacAddress() {
        super(6, ByteArray.EMPTY);
    }

    /**
     * Construct from colon separated byte string.
     */
    public MacAddress(final String mac) {
        super(6, ByteArray.EMPTY);
        if (this.setMacFromString(mac)) {
            this.asString = mac;
        }
    }

    /**
     * Copy constructor.
     */
    public MacAddress(final MacAddress mac) {
        super(mac);
    }

    /**
     * Construct from byte array
     */
    public MacAddress(final byte[] bytes) {
        // FIXME size check.
        super(bytes, 6, ByteArray.EMPTY);
    }

    public boolean setMacFromString(final String mac) {
        boolean success = false;
        // FIXME validate format of string
        for (int iCnt = 0; iCnt < 6; iCnt++) {
            final String str = mac.substring(iCnt * 3, iCnt * 3 + 2);
            final int iByte = Integer.parseInt(str, 16);
            this.m_Data[iCnt] = (byte) iByte;
        }
        success = true;
        return success;
    }

    public String getMacAsString() {
        if (this.asString == null) {
            this.asString = ByteConvertor.toHexWithDelim(this.m_Data, ':', 0, 6);
        }
        return this.asString;
    }

    /**
    *
    */
    public String toNoColonString() {
        if (this.asNoColonString == null) {
            this.asNoColonString = ByteConvertor.toHex(this.getBytes());
        }
        return this.asNoColonString;
    }

    /**
     * @param str
     *            a string of 12 hexadecimal characters separated by colons.
     * @return a new MacAddress object. Should throw IllegalArgumentException
     */
    public static MacAddress valueOf(final String str) {
        final MacAddress ret = new MacAddress(str);
        // catch (NumberFormatException nfEx)
        // {
        // throw new
        // IllegalArgumentException("Invalid string not hexidecimal: "
        // + str);
        // }
        return ret;
    }

    /**
    *
    */
    @Override
    public DSMCCObject createNewInstance() {
        return new MacAddress();
    }
}
