package com.itaas.dsmcc.base;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ResourceBundle;

public class ObjectCreator {

    String m_classMapFile;

    Hashtable m_HashTable;

    ObjectCreator(final String classMapName) {
        this.m_classMapFile = classMapName;
        this.m_HashTable = new Hashtable();
        this.load(this.m_classMapFile);
    }

    private void load(final String classMapName) {
        // ResourceBundle res = ResourceBundle.getBundle("com.itaas.dsmcc.base.SessionMessagesMap.ini");
        final ResourceBundle res = ResourceBundle.getBundle(classMapName);
        for (final Enumeration enumer = res.getKeys(); enumer.hasMoreElements();) {
            final Object key = enumer.nextElement();
            final Object val = res.getObject(key.toString());
            // The key is an integer and value is a class name
            final Integer iKey = new Integer(key.toString());
            this.m_HashTable.put(iKey, val);
        }
    }

    Object createObject(final int objectType) {
        Object ret = null;
        final Integer iKey = new Integer(objectType);

        if (this.m_HashTable.containsKey(iKey)) {
            final String strClassName = this.m_HashTable.get(iKey).toString();
            try {
                ret = Class.forName(strClassName);
            } catch (final ClassNotFoundException cnfe) {
                ret = null;
                cnfe.printStackTrace(System.err);
            }
        }
        return ret;
    }

}
