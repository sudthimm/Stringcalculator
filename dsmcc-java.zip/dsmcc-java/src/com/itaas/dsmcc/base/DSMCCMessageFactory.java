// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.EnumMap;

import com.itaas.dsmcc.client.DSMCCClientReleaseConfirm;
import com.itaas.dsmcc.client.DSMCCClientReleaseIndication;
import com.itaas.dsmcc.client.DSMCCClientReleaseRequest;
import com.itaas.dsmcc.client.DSMCCClientReleaseResponse;
import com.itaas.dsmcc.client.DSMCCClientSessionInProgress;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpConfirm;
import com.itaas.dsmcc.client.DSMCCClientSessionSetUpRequest;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.passthru.DSMCCPassthruIndicationMessage;
import com.itaas.dsmcc.server.DSMCCServerAddResourceConfirm;
import com.itaas.dsmcc.server.DSMCCServerAddResourceRequest;
import com.itaas.dsmcc.server.DSMCCServerReleaseConfirm;
import com.itaas.dsmcc.server.DSMCCServerReleaseIndication;
import com.itaas.dsmcc.server.DSMCCServerReleaseResponse;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpIndication;
import com.itaas.dsmcc.server.DSMCCServerSessionSetUpResponse;
import com.itaas.dsmcc.server.DSMCCServerStatusConfirm;
import com.itaas.dsmcc.server.DSMCCServerStatusIndication;
import com.itaas.dsmcc.server.DSMCCServerStatusRequest;
import com.itaas.dsmcc.server.DSMCCServerStatusResponse;
import com.itaas.dsmcc.util.ByteConvertor;

public class DSMCCMessageFactory extends DSMCCObjectFactory {

    public static DSMCCMessage create(final DSMCCInputStream dis) throws IOException {
        DSMCCMessage msgRet = null;
        final DSMCCMessageCommonHeader cmn = new DSMCCMessageCommonHeader();
        try {
            cmn.read(dis);
            if (cmn.getProtocolDiscriminator() != 0x11) {
                return null;
            }
            switch (cmn.getDsmccType()) {
                case 0x02: {
                    msgRet = DSMCCMessageFactory.createSessionMessage(cmn);
                    break;
                }
                case 0x05: {
                    msgRet = DSMCCMessageFactory.createPassthruMessage(cmn);
                    break;
                }
            }
            final int iRead = msgRet.read(dis);
        } catch (final IOException ex) {
            if (msgRet != null) {
                msgRet.dump(System.out);
            }
            throw ex;
        }
        return msgRet;
    }

    public static DSMCCMessage createSessionMessage(final DSMCCMessageCommonHeader cmn) {
        DSMCCMessage msgRet = null;

   
        DSMCCClientMessageType message = DSMCCClientMessageType.valueOf(cmn.getMessageId());
        switch (message) {

            /*
             * en_Client_Session_Setup_Request as well as all the other client message codes are defined in
             * DSMCCClientMessageType
             */

            case enClient_Session_Setup_Request:

                msgRet = new DSMCCClientSessionSetUpRequest(cmn);
                break;

            case enClient_Release_Request:

                msgRet = new DSMCCClientReleaseRequest(cmn);
                break;

            case enClient_Release_Confirm:

                msgRet = new DSMCCClientReleaseConfirm(cmn);
                break;

            case enClient_Release_Indication:

                msgRet = new DSMCCClientReleaseIndication(cmn);
                break;

            case enClient_Release_Response:

                msgRet = new DSMCCClientReleaseResponse(cmn);
                break;

            case enClient_Session_In_Progress:

                msgRet = new DSMCCClientSessionInProgress(cmn);
                break;
            case enClient_Session_Setup_Confirm:
                msgRet = new DSMCCClientSessionSetUpConfirm(cmn);
                break;
        }

        if (msgRet == null) { // Still Haven't Found The Message
            DSMCCServerMessageType serverMessage = DSMCCServerMessageType.valueOf(cmn.getMessageId());

            switch (serverMessage) {
                /*
                 * en_Server_Session_Setup_Indication as well as all the other server message codes are
                 * defined in DSMCCServerMessageType
                 */
                case enServer_Session_Setup_Indication:

                    msgRet = new DSMCCServerSessionSetUpIndication(cmn);
                    break;

                case enServer_Release_Response:

                    msgRet = new DSMCCServerReleaseResponse(cmn);
                    break;

                case enServer_Release_Indication:

                    msgRet = new DSMCCServerReleaseIndication(cmn);
                    break;

                case enServer_Release_Request:

                    msgRet = new DSMCCServerReleaseIndication(cmn);
                    break;

                case enServer_Release_Confirm:

                    msgRet = new DSMCCServerReleaseConfirm(cmn);
                    break;

                case enServer_Add_Resource_Request:
                    msgRet = new DSMCCServerAddResourceRequest(cmn);
                    break;

                case enServer_Add_Resource_Confirm:
                    msgRet = new DSMCCServerAddResourceConfirm(cmn);
                    break;
                case enServer_Session_Setup_Response:
                    msgRet = new DSMCCServerSessionSetUpResponse(cmn);
                    break;

                case enServer_Status_Request:
                    msgRet = new DSMCCServerStatusRequest(cmn);
                    break;

                case enServer_Status_Response:
                    msgRet = new DSMCCServerStatusResponse(cmn);
                    break;

                case enServer_Status_Confirm:
                    msgRet = new DSMCCServerStatusConfirm(cmn);
                    break;

                case enServer_Status_Indication:
                    msgRet = new DSMCCServerStatusIndication(cmn);
                    break;

                default:
                    msgRet = new DSMCCUnknownMessage(cmn);

            }
        }
        return msgRet;
    }

    public static DSMCCMessage createPassthruMessage(final DSMCCMessageCommonHeader cmn) {
        DSMCCMessage msgRet = null;
        switch (cmn.getMessageId()) {

            case DSMCCPassthruIndicationMessage.DSMCCPassthruIndication: {
                msgRet = new DSMCCPassthruIndicationMessage(cmn);
                break;
            }
            default:
                msgRet = new DSMCCUnknownMessage(cmn);

        }
        return msgRet;
    }

    public static void main(final String[] args) {

        try {
            final java.io.FileInputStream fis = new java.io.FileInputStream(args[0]);
            final DSMCCInputStream dis = new DSMCCInputStream(fis);
            int iCnt = 1;
            while (true) {
                final String State = "";
                Thread.sleep(1000);
                final DSMCCMessage msg = DSMCCMessageFactory.create(dis);
                msg.dump(System.out);
                System.out.print("Created...");
                final ByteArrayOutputStream baos = new ByteArrayOutputStream();
                final DSMCCOutputStream dos = new DSMCCOutputStream(baos);
                msg.write(dos);
                System.out.print("Wrote...");
                final byte[] bytes = baos.toByteArray();
                final String str1 = ByteConvertor.toHex(bytes);
                final ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                final DSMCCInputStream dis2 = new DSMCCInputStream(bais);
                final DSMCCMessage msg2 = DSMCCMessageFactory.create(dis2);
                System.out.print("Created...");
                final ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
                final DSMCCOutputStream dos2 = new DSMCCOutputStream(baos2);
                msg2.write(dos2);
                System.out.print("Wrote...");
                final byte[] bytes2 = baos2.toByteArray();
                final String str2 = ByteConvertor.toHex(bytes2);

                if (str1.equalsIgnoreCase(str2)) {
                    System.out.println("" + (iCnt++) + "\t" + msg2.getClass().toString() + " is fine: ");
                    System.out.flush();
                    // ByteArray ba = new ByteArray(bytes);
                    // ba.dump(System.out);
                } else {
                    System.out.println(msg2.getClass().toString() + " has some problems");
                    System.out.println(str1);
                    System.out.println(str2);
                    msg2.dump(System.out);
                    System.out.flush();
                }
            }
        } catch (final Exception ex) {
            // ex.printStackTrace();
            System.exit(0);
        }
    }
}
