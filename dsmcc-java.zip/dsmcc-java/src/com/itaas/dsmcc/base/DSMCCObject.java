// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 17, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.EOFException;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.itaas.dsmcc.util.ItaasSerializable;

/**
 * DSMCCObject is the base class for all streamable message elements. Data members named with with prefix
 * "m__" are written in the order they appear in the class definition. java.lang.Short maps to 1 byte in the
 * stream. java.lang.Integer maps to 2 bytes in the stream. java.lang.Long maps to 4 bytes in the stream. All
 * other data members must implement from ItaasSerializble to be written. ByteArray is often used as the class
 * for other data members.
 */
public class DSMCCObject implements ItaasSerializable {

    protected PrintStream m_ps;

    protected static String m_strIndent = "  ";

    /** Convenience members to avoid 1.5 Compiler complaints */
    private static final Class[] nullClassArray = null;

    private static final Object[] nullObjArray = null;

    public DSMCCObject() {
    }

    public void setPrintWriter(final PrintStream ps) {
        this.m_ps = ps;
    }

    public void dump(final Object target) {
        this.dump(target, true);
    }

    public void dump(final Object target, final boolean newLine) {

        this.increaseIndent();
        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();
        this.m_ps.println(DSMCCObject.m_strIndent + objClass.toString());

        final int iLen = fields.length;
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            try {
                final Field fld = fields[iCnt];
                final Class fldClass = fld.getType();
                final String classname = fldClass.toString();
                final String name = fld.getName();
                final String methodName = "get" + name.substring(3);
                if (name.startsWith("m__") || name.startsWith("M__")) {

                    final Method method = objClass.getMethod(methodName, DSMCCObject.nullClassArray);
                    final Object ret = method.invoke(target, DSMCCObject.nullObjArray);
                    final String val;
                    if (ret != null) {
                        if (ret instanceof DSMCCObject) {
                            final ItaasSerializable da = (ItaasSerializable) (ret);
                            this.m_ps.print(DSMCCObject.m_strIndent + name + ":");
                            da.dump(this.m_ps);
                        } else if (ret instanceof Short) {
                            this.m_ps.println(DSMCCObject.m_strIndent + name + ":" + ret.toString() + " (0x"
                                    + Integer.toHexString(((Short) ret).shortValue()) + ")");
                        } else if (ret instanceof Integer) {
                            this.m_ps.println(DSMCCObject.m_strIndent + name + ":" + ret.toString() + " (0x"
                                    + Integer.toHexString(((Integer) ret).intValue()) + ")");
                        } else if (ret instanceof Long) {
                            this.m_ps.println(DSMCCObject.m_strIndent + name + ":" + ret.toString() + " (0x"
                                    + Long.toHexString(((Long) ret).longValue()) + ")");
                        } else {
                            this.m_ps.println(DSMCCObject.m_strIndent + name + ":" + ret.toString());
                        }
                    } else {
                        // m_ps.println(fldClass.toString() + ":" + name + ":" + null );
                    }
                }
            } catch (final Exception ex) {
                // StackTrace in method dump()
                if (this.m_ps != null) {
                    ex.printStackTrace(this.m_ps);
                }
            }
        }
        if (newLine) {
            this.m_ps.println();
        }
        this.decreaseIndent();
    }

    public void dump(final PrintStream ps) throws IOException {
        this.setPrintWriter(ps);
        this.dump(this);
    }

    public int read(final DSMCCInputStream dis) throws IOException {
        final Object target = this;
        int iRet = 0;
        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();
        final int iLen = fields.length;
        final Object[] args = new Object[1];
        final Class[] parameters = new Class[1];
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            final Field fld = fields[iCnt];
            final Class fldClass = fld.getType();
            final String name = fld.getName();
            String methodName = "XXXXX";
            try {
                if (name.startsWith("m__")) {
                    methodName = "set" + name.substring(3);
                    Method method = null;
                    final String fldclassName = fldClass.toString();
                    if (fldclassName.equals("short")) {
                        final short bRead = dis.readUByte();
                        parameters[0] = fldClass;
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = new Short(bRead);
                        iRet += 1;
                    } else if (fldclassName.equals("long")) {
                        final long iRead = dis.readUInteger();
                        parameters[0] = fldClass;
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = new Long(iRead);
                        iRet += 4;
                    } else if (fldclassName.equals("int")) {
                        final int sRead = dis.readUShort();
                        parameters[0] = fldClass;
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = new Integer(sRead);
                        iRet += 2;
                    } else {
                        final Method getMethod = objClass.getMethod("get" + name.substring(3),
                                DSMCCObject.nullClassArray);
                        final Object retObj = getMethod.invoke(target, DSMCCObject.nullObjArray);
                        DSMCCObject oRead;
                        if (retObj == null) {
                            oRead = (DSMCCObject) fldClass.newInstance();
                            // throw new IOException("Default Constructors did not initialize members");
                        } else {
                            oRead = (DSMCCObject) retObj;
                        }
                        iRet += oRead.read(dis);
                        parameters[0] = oRead.getClass();
                        try {
                            method = objClass.getMethod(methodName, parameters);
                        } catch (final Exception ex) {
                            System.err.println("While reading " + fldClass + ": " + name + " in " + this.toString());
                            System.err.println(this.getClass().toString() + "." + methodName + "("
                                    + parameters[0].getClass().getName() + ")");
                        }
                        args[0] = oRead;
                    }
                    final Object ret = method.invoke(target, args);
                } else if (name.startsWith("M__")) {
                    methodName = "read" + name.substring(3);
                    Method method = null;
                    {
                        parameters[0] = dis.getClass();
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = dis;
                    }
                    final Object ret = method.invoke(target, args);
                    if (ret instanceof Integer) {
                        iRet += ((Integer) ret).intValue();
                    }
                }
            } catch (final EOFException ioex) {
                throw (ioex);
            } catch (final Exception ex) {
                ex.printStackTrace(System.err);
                System.err.flush();
            }
        }
        return iRet;
    }

    public int write(final DSMCCOutputStream dos) throws IOException {
        return this.write(this, dos);
    }

    public int write(final Object target, final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();

        final int iLen = fields.length;
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            try {
                final Field fld = fields[iCnt];
                final Class fldClass = fld.getType();
                final String classname = fldClass.toString();
                final String name = fld.getName();
                final String methodName = "get" + name.substring(3);

                if (name.startsWith("m__") || name.startsWith("M__")) {
                    final Method method = objClass.getMethod(methodName, DSMCCObject.nullClassArray);
                    final Object ret = method.invoke(this, DSMCCObject.nullObjArray);

                    if (ret != null) {
                        final String strRetClass = ret.getClass().toString().substring(6);
                        if (strRetClass.equals("java.lang.Short")) {
                            // System.out.print(name + "\t" + ret);
                            dos.writeUByte(((Short) ret).shortValue());
                            // System.out.println();
                            iRet += 1;
                        } else if (strRetClass.equals("java.lang.Integer")) {
                            // System.out.print(name + "\t" + ret);
                            dos.writeUShort(((Integer) ret).intValue());
                            // System.out.println();
                            iRet += 2;
                        } else if (strRetClass.equals("java.lang.Long")) {
                            // System.out.print(name + "\t" + ret);
                            dos.writeUInteger(((Long) ret).longValue());
                            // System.out.println();
                            iRet += 4;
                        } else if (ret instanceof DSMCCObject) {
                            // System.out.println(name + ":");
                            final ItaasSerializable da = (ItaasSerializable) (ret);
                            iRet += da.write(dos);
                        }
                    } else {
                        // m_ps.println(fldClass.toString() + ":" + name + ":" + null );
                    }
                }
            } catch (final Exception ex) {
                // StackTrace in method write()
                if (this.m_ps != null) {
                    ex.printStackTrace(this.m_ps);
                }
            }
        }
        return iRet;
    }

    /*
     * public int _read(DSMCCInputStream dis) throws IOException { int iRet = 0; return iRet; }
     */
    public int getLength() {
        final int iRet = this.getLength(this);

        return iRet;
    }

    public int getLength(final Object target) {
        int iRet = 0;

        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();

        final int iLen = fields.length;
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            try {
                final Field fld = fields[iCnt];
                final Class fldClass = fld.getType();
                final String classname = fldClass.toString();
                final String name = fld.getName();
                final String methodName = "get" + name.substring(3);
                if (name.startsWith("m__") || name.startsWith("M__")) {
                    final Method method = objClass.getMethod(methodName, DSMCCObject.nullClassArray);
                    final Object ret = method.invoke(this, DSMCCObject.nullObjArray);

                    if (ret != null) {
                        final String strRetClass = ret.getClass().toString().substring(6);
                        if (strRetClass.equals("java.lang.Short")) {
                            iRet += 1;
                        } else if (strRetClass.equals("java.lang.Integer")) {
                            iRet += 2;
                        } else if (strRetClass.equals("java.lang.Long")) {
                            iRet += 4;
                        } else if (ret instanceof DSMCCObject) {
                            final ItaasSerializable da = (ItaasSerializable) (ret);
                            iRet += da.getLength();
                        }
                    } else {
                        // m_ps.println(fldClass.toString() + ":" + name + ":" + null );
                    }
                }
                // System.out.println(getClass().toString() + ": " + name + ":" + iRet);
            } catch (final Exception ex) {
                // StackTrace in method getLength()
                if (this.m_ps != null) {
                    ex.printStackTrace(this.m_ps);
                }

            }
        }

        return iRet;
    }

    public DSMCCObject createNewInstance() {
        System.err.println(this.getClass().toString() + ": createNewInstance Not implemented");
        return null;
    }

    /*
     * public String getIndent() { return m_strIndent; } public void setIndent(String valIndent) { m_strIndent
     * = valIndent; }
     */
    public void increaseIndent() {
        DSMCCObject.m_strIndent += "  ";
    }

    public void decreaseIndent() {
        DSMCCObject.m_strIndent = DSMCCObject.m_strIndent.substring(2);
    }

}
