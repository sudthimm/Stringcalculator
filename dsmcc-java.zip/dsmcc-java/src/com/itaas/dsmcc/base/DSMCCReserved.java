// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class DSMCCReserved {

    public static final int enReserved_00 = 0x0000;

    public static final int enReserved_FF = 0x00ff;

    public static final int enReserved_FFFF = 0xffff;

}
