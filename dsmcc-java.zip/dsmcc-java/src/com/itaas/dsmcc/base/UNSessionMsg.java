package com.itaas.dsmcc.base;

/************************************************************************
 * Copyright (C) 2005 itaas Inc. All rights reserved. This document contains confidential and proprietary
 * information subject to non-disclosure agreements with itaas Inc. This information is to be used solely for
 * evaluation of continued and future business arrangements with itaas Inc. or as otherwise agreed in writing
 * by itaas Inc. This information shall not be distributed or copied without written permission from itaas
 * Inc. $Id: UNSessionMsg.java,v 1.1 2007/09/12 14:11:34 pushkar2546 Exp $
 ************************************************************************/

/************************************************************************
 * UNSessionMsg models DSMCC UNSession Messages.
 ************************************************************************/

public class UNSessionMsg extends DSMCCMessage {

    public static final String rcsid = "$Id: UNSessionMsg.java,v 1.1 2007/09/12 14:11:34 pushkar2546 Exp $";

    // DSMCC Message Ids
    // Session Setup
    public static final int CSessionReq = 0x4010;

    public static final int CSessionCnf = 0x4011;

    public static final int SSessionInd = 0x8012;

    public static final int SSessionRsp = 0x8013;

    // Release
    public static final int CReleaseReq = 0x4020;

    public static final int CReleaseCnf = 0x4021;

    public static final int CReleaseInd = 0x4022;

    public static final int CReleaseRsp = 0x4023;

    public static final int SReleaseReq = 0x8020;

    public static final int SReleaseCnf = 0x8021;

    public static final int SReleaseInd = 0x8022;

    public static final int SReleaseRsp = 0x8023;

    // Add Resources
    public static final int SAddRsrReq = 0x8030;

    public static final int SAddRsrCnf = 0x8031;

    public static final int CAddRsrInd = 0x4032;

    public static final int CAddRsrRsp = 0x4033;

    // Delete Resources
    public static final int SDelRsrReq = 0x8040;

    public static final int SDelRsrCnf = 0x8041;

    public static final int CDelRsrInd = 0x4042;

    public static final int CDelRsrRsp = 0x4043;

    // CFS
    public static final int SCfsReq = 0x8050;

    public static final int SCfsCnf = 0x8051;

    // Status
    public static final int CStatusReq = 0x4060;

    public static final int CStatusCnf = 0x4061;

    public static final int CStatusInd = 0x4062;

    public static final int CStatusRsp = 0x4063;

    public static final int SStatusReq = 0x8060;

    public static final int SStatusCnf = 0x8061;

    public static final int SStatusInd = 0x8062;

    public static final int SStatusRsp = 0x8063;

    // Reset
    public static final int CResetReq = 0x4070;

    public static final int CResetCnf = 0x4071;

    public static final int CResetInd = 0x4072;

    public static final int CResetRsp = 0x4073;

    public static final int SResetReq = 0x8070;

    public static final int SResetCnf = 0x8071;

    public static final int SResetInd = 0x8072;

    public static final int SResetRsp = 0x8073;

    // Proceeding
    public static final int CProceedingInd = 0x4082;

    public static final int SProceedingInd = 0x8082;

    // Connect
    public static final int CConnectReq = 0x4090;

    public static final int SConnectInd = 0x4092;

    // Session Transfer
    public static final int CTransferInd = 0x40a2;

    public static final int CTransferRsp = 0x40a3;

    public static final int STransferReq = 0x80a0;

    public static final int STransferCnf = 0x80a1;

    public static final int STransferInd = 0x80a2;

    public static final int STransferRsp = 0x80a3;

    // Session In Progress
    public static final int CInProgressReq = 0x40b0;

    public static final int SInProgressReq = 0x80b0;

    // 0x6000 <= UserDefined <= 0x7fff
    public static final int UserDef1 = 0x6000;

    public static final int UserDefMax = 0x7fff;

    /** Status Types of DSMCC Status messages */
    public static final int SessionListStatusType = 1;

    public static final int SessionStatusType = 2;

    public static final int ConfigStatusType = 3;

    public static final int ResourceDescriptorStatusType = 4;

    public static final int ResourceStatusType = 5;

    /** 2 byte values for resourceDescriptorType in Rsr Descriptor Header */
    public static final int CfsRsrType = 1;

    public static final int AtmConnRsrType = 2;

    public static final int MpegProgramRsrType = 3;

    public static final int PhysicalChannelRsrType = 4;

    public static final int TsUpstreamBwRsrType = 5;

    public static final int TsDownstreamBwRsrType = 6;

    public static final int AtmSvcConnRsrType = 7;

    public static final int ConnNotifyRsrType = 8;

    public static final int IpRsrType = 9;

    public static final int ClientTdmaRsrType = 0xa;

    public static final int PstnSetupRsrType = 0xb;

    public static final int NisdnSetupRsrType = 0xc;

    public static final int NisdnConnRsrType = 0xd;

    public static final int Q922ConnRsrType = 0xe;

    public static final int HeadEndListRsrType = 0xf;

    public static final int AtmVcConnRsrType = 0x10;

    public static final int SdbCfsRsrType = 0x11;

    public static final int SdbAssociationsRsrType = 0x12;

    public static final int SdbEntitlementRsrType = 0x13;

    public static final int SharedRsrRsrType = 0x7ffe;

    public static final int SharedReqIdRsrType = 0x7fff;

    public static final int AtscModModeRsrType = 0xf001;

    public static final int HeadEndIdRsrType = 0xf003;

    public static final int ServerCARsrType = 0xf004;

    public static final int ClientCARsrType = 0xf005;

    public static final int EthernetIntfcRsrType = 0xf006;

    public static final int TypeOwnerRsrType = 0xffff;

    // FIXME belongs in Message Header
    public static final byte UNSessionDsmcccType = 2;

    /**
    *
    */
    public UNSessionMsg() {
        super(new DSMCCMessageCommonHeader());
        this.m_Header.setDsmccType(UNSessionMsg.UNSessionDsmcccType);
    }

    /**
    *
    */
    public static String msgIdToString(final int msgId) {

        String retStr = null;
        switch (msgId) {
            case CSessionReq:
                retStr = "CSessionReq";
                break;
            case CSessionCnf:
                retStr = "CSessionCnf";
                break;
            case SSessionInd:
                retStr = "SSessionInd";
                break;
            case SSessionRsp:
                retStr = "SSessionRsp";
                break;
            case CReleaseReq:
                retStr = "CReleaseReq";
                break;
            case CReleaseCnf:
                retStr = "CReleaseCnf";
                break;
            case CReleaseInd:
                retStr = "CReleaseInd";
                break;
            case CReleaseRsp:
                retStr = "CReleaseRsp";
                break;
            case SReleaseReq:
                retStr = "SReleaseReq";
                break;
            case SReleaseCnf:
                retStr = "SReleaseCnf";
                break;
            case SReleaseInd:
                retStr = "SReleaseInd";
                break;
            case SReleaseRsp:
                retStr = "SReleaseRsp";
                break;
            case SAddRsrReq:
                retStr = "SAddRsrReq";
                break;
            case SAddRsrCnf:
                retStr = "SAddRsrCnf";
                break;
            case CAddRsrInd:
                retStr = "CAddRsrInd";
                break;
            case CAddRsrRsp:
                retStr = "CAddRsrRsp";
                break;
            case SDelRsrReq:
                retStr = "SDelRsrReq";
                break;
            case SDelRsrCnf:
                retStr = "SDelRsrCnf";
                break;
            case CDelRsrInd:
                retStr = "CDelRsrInd";
                break;
            case CDelRsrRsp:
                retStr = "CDelRsrRsp";
                break;
            case SCfsReq:
                retStr = "SCfsReq";
                break;
            case SCfsCnf:
                retStr = "SCfsCnf";
                break;
            case CStatusReq:
                retStr = "CStatusReq";
                break;
            case CStatusCnf:
                retStr = "CStatusCnf";
                break;
            case CStatusInd:
                retStr = "CStatusInd";
                break;
            case CStatusRsp:
                retStr = "CStatusRsp";
                break;
            case SStatusReq:
                retStr = "SStatusReq";
                break;
            case SStatusCnf:
                retStr = "SStatusCnf";
                break;
            case SStatusInd:
                retStr = "SStatusInd";
                break;
            case SStatusRsp:
                retStr = "SStatusRsp";
                break;
            case CResetReq:
                retStr = "CResetReq";
                break;
            case CResetCnf:
                retStr = "CResetCnf";
                break;
            case CResetInd:
                retStr = "CResetInd";
                break;
            case CResetRsp:
                retStr = "CResetRsp";
                break;
            case SResetReq:
                retStr = "SResetReq";
                break;
            case SResetCnf:
                retStr = "SResetCnf";
                break;
            case SResetInd:
                retStr = "SResetInd";
                break;
            case SResetRsp:
                retStr = "SResetRsp";
                break;
            case CProceedingInd:
                retStr = "CProceedingInd";
                break;
            case SProceedingInd:
                retStr = "SProceedingInd";
                break;
            case CConnectReq:
                retStr = "CConnectReq";
                break;
            case SConnectInd:
                retStr = "SConnectInd";
                break;
            case CTransferInd:
                retStr = "CTransferInd";
                break;
            case CTransferRsp:
                retStr = "CTransferRsp";
                break;
            case STransferReq:
                retStr = "STransferReq";
                break;
            case STransferCnf:
                retStr = "STransferCnf";
                break;
            case STransferInd:
                retStr = "STransferInd";
                break;
            case STransferRsp:
                retStr = "STransferRsp";
                break;
            case CInProgressReq:
                retStr = "CInProgressReq";
                break;
            case SInProgressReq:
                retStr = "SInProgressReq";
                break;

            default:
                break;
        }
        if (retStr == null) {
            final StringBuffer sbuf = new StringBuffer(64);
            if ((msgId >= UNSessionMsg.UserDef1) && (msgId <= UNSessionMsg.UserDefMax)) {
                sbuf.append("User Defined Message Type: ");
            } else {
                sbuf.append("Invalid Message Type: ");
            }
            sbuf.append("0x");
            sbuf.append(Integer.toHexString(msgId));
            retStr = sbuf.toString();
        }
        return retStr;
    }
}
