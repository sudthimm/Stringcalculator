// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class TransactionIdOriginator {

    public static final int enTxnIdAssignedByClient = 0x00;

    public static final int enTxnIdAssignedByServer = 0x01;

    public static final int enTxnIdAssignedByNetwork = 0x02;

    public static final int enTxnIdAssignedByReserved = 0x03;

}
