// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 24, 2003
// //////////////////////////////////////////////////////////////////////////////
/**
 * @author Krishna C Tripathi
 */

package com.itaas.dsmcc.base;

import java.io.IOException;
import java.io.PrintStream;

import com.itaas.dsmcc.Pegasus.SSPDescriptorFactory;

public class DSMCCUserData extends DSMCCObject {

    public static final DSMCCUserData EmptyUserData = new DSMCCUserData();

    protected ByteArray m__UUData;

    protected ByteArray m__PrivateData;

    /*
     * FIXME Enforce size of length field (2 bytes) for both UUData and PrivateData Pad UUData and PrivateData
     * to length in multiples of 4.
     */
    // Constructor
    public DSMCCUserData() {
        this.m__UUData = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        this.m__PrivateData = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
    }

    // Constructor
    public DSMCCUserData(final ByteArray uuData, final ByteArray privateData) {
        this.m__UUData = uuData;
        this.m__PrivateData = privateData;
    }

    public ByteArray getUUData() {
        return this.m__UUData;
    }

    public void setUUData(final ByteArray valUUData) {
        this.m__UUData = valUUData;
    }

    public ByteArray getPrivateData() {
        return this.m__PrivateData;
    }

    public void setPrivateData(final ByteArray valPrivateData) {
        this.m__PrivateData = valPrivateData;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        return super.read(dis);
    }

    @Override
    public void dump(final PrintStream ps) throws IOException {
        this.setPrintWriter(ps);
        this.increaseIndent();
        ps.println();
        if (this.m__UUData != null) {
            ps.println(DSMCCObject.m_strIndent + "m__UUData:");
            this.m__UUData.dump(ps);
        } else {
            ps.println("m__UUData: null");
        }

        if (this.m__PrivateData != null) {
            // m__PrivateData.dump(ps);
            ps.print(DSMCCObject.m_strIndent + "m__PrivateData:");
            final DSMCCObject obj = SSPDescriptorFactory.createUserPrivateData(this.m__PrivateData);
            if (obj != null) {
                obj.dump(ps);
            } else {
                this.m__PrivateData.dump(ps);
            }
        } else {
            ps.println("m__PrivateData: null");
        }
        this.decreaseIndent();
    }

}
