// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.IOException;
import java.io.PrintStream;

import com.itaas.dsmcc.util.ByteConvertor;

public class ByteArray extends DSMCCObject {

    public final static byte EMPTY = 0;

    public final static byte UNSIGNED_BYTE = 1;

    public final static byte UNSIGNED_SHORT = 2;

    public final static byte UNSIGNED_INTEGER = 4;

    public final static byte NULL_TERMINATED = 5;

    protected byte[] m_Data;

    protected byte m_SizeType = ByteArray.UNSIGNED_SHORT;

    /**
     * Default constructor. The default for size of the "length" field is 2 bytes (short).
     */
    public ByteArray() {
    }

    /**
     * Create a byte array of specified length and set the "length" field size to 2 bytes (short). This
     * constructor is only useful preceeding a read() call or if it is intended all the bytes be set to zero.
     * The values in the byte array can only be set to non zero values by the read method.
     * 
     * @param length
     *            the number of bytes to allocate.
     */
    public ByteArray(final int length) {
        this.m_Data = new byte[length];
    }

    /**
     * Copy constructor.
     * 
     * @param ba
     *            the ByteArray to copy.
     */
    public ByteArray(final ByteArray ba) {
        this.copy(ba.m_Data);
        this.m_SizeType = ba.m_SizeType;
    }

    /**
     * Allocate a byte array of the specified length andset the size field length.
     * 
     * @param length
     *            the number of bytes to allocate.
     * @param sizetype
     *            specifies the size of the "length" field. This should be one of {EMPTY, UNSIGNED_BYTE,
     *            UNSIGNED_SHORT, UNSIGNED_INTEGER, NULL_TERMINATED}
     */
    public ByteArray(final int length, final byte sizetype) {
        this.m_Data = new byte[length];
        this.m_SizeType = sizetype;
    }

    /**
     * Construct using an existing array of bytes. The byte array is copied and the size field length is
     * defaults to 0 (no length field or EMPTY).
     * 
     * @param data
     *            the byte array to copy.
     */
    public ByteArray(final byte[] data) {
        this.copy(data);
        this.m_SizeType = ByteArray.EMPTY;
    }

    /**
     * Construct using an existing array of bytes. The byte array is copied and the size field length is
     * defaults to 0 (no size field or EMPTY).
     * 
     * @param data
     *            the byte array to copy.
     * @param sizetype
     *            the type of the length field.
     */
    public ByteArray(final byte[] data, final byte sizetype) {
        this.copy(data);
        this.m_SizeType = sizetype;
    }

    /**
     * Construct using an existing array of bytes. The byte array is copied and the size field length is
     * defaults to 0 (no size field or EMPTY).
     * 
     * @param data
     *            the byte array to copy.
     * @param length
     *            the number of bytes to copy.
     * @param sizetype
     *            the type of the length field.
     */
    public ByteArray(final byte[] data, final int length, final byte sizetype) {
        this.m_Data = new byte[length];
        System.arraycopy(data, 0, this.m_Data, 0, length);
        this.m_SizeType = sizetype;
    }

    /**
     * Construct using an existing array of bytes. The byte array is copied and the size field length is
     * defaults to 0 (no size field or EMPTY).
     * 
     * @param data
     *            the byte array to copy from.
     * @param startNdx
     *            the index in the data byte array to start copying from.
     * @param numBytes
     *            the number of bytes to copy.
     * @param sizetype
     *            the type of the length field.
     * @return an allocated ByteArray with the copied bytes or null if the source data does not have the
     *         requested number of bytes remaining after the startNdx.
     */
    public static ByteArray createFromBytes(final byte[] data, final int startNdx, final int numBytes,
            final byte sizetype) {
        ByteArray retArray = null;
        if (data.length >= startNdx + numBytes) {
            retArray = new ByteArray();
            retArray.m_Data = new byte[numBytes];
            System.arraycopy(data, startNdx, retArray.m_Data, 0, numBytes);
            retArray.m_SizeType = sizetype;
        }
        return retArray;
    }

    /**
    *
    */
    public int copy(final byte[] data) {
        if ((this.m_Data == null) || (this.m_Data.length != data.length)) {
            this.m_Data = new byte[data.length];
        }
        System.arraycopy(data, 0, this.m_Data, 0, this.m_Data.length);
        return this.m_Data.length;
    }

    /**
    *
    */
    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        if (this.m_SizeType == ByteArray.UNSIGNED_SHORT) {
            dos.writeUShort(this.m_Data.length);
        } else if (this.m_SizeType == ByteArray.UNSIGNED_BYTE) {
            dos.writeUByte((short) this.m_Data.length);
        } else if (this.m_SizeType == ByteArray.UNSIGNED_INTEGER) {
            dos.writeUInteger(this.m_Data.length);
        }
        iRet += this.m_SizeType;

        if (this.m_Data.length > 0) {
            dos.write(this.m_Data);
        }
        iRet += this.m_Data.length;

        return iRet;
    }

    /**
    *
    */
    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;
        int iLength = 0;

        switch (this.m_SizeType) {
            case UNSIGNED_SHORT: {
                iLength = dis.readUShort();
                iRet += this.m_SizeType;

                if ((this.m_Data == null) || (this.m_Data.length == 0)) {
                    this.m_Data = new byte[iLength];
                }

                dis.read(this.m_Data);
                iRet += this.m_Data.length;
                break;
            }
            case UNSIGNED_BYTE: {
                iLength = dis.readUByte();
                iRet += this.m_SizeType;

                if ((this.m_Data == null) || (this.m_Data.length == 0)) {
                    this.m_Data = new byte[iLength];
                }

                dis.read(this.m_Data);
                iRet += this.m_Data.length;
                break;
            }
            case UNSIGNED_INTEGER: {
                iLength = (int) dis.readUInteger();
                iRet += this.m_SizeType;

                if ((this.m_Data == null) || (this.m_Data.length == 0)) {
                    this.m_Data = new byte[iLength];
                }

                dis.read(this.m_Data);
                iRet += this.m_Data.length;
                break;
            }
            case EMPTY: {
                if ((this.m_Data == null) || (this.m_Data.length == 0)) {
                    this.m_Data = new byte[iLength];
                }

                dis.read(this.m_Data);
                iRet += this.m_Data.length;
                break;
            }
            case NULL_TERMINATED: {
                byte[] tempBytes = new byte[128];
                byte bt = 0;
                int count = 0;
                do {
                    bt = dis.readByte();
                    tempBytes[count++] = bt;
                    if (count == tempBytes.length) {
                        final byte[] tt = new byte[count + 128];
                        System.arraycopy(tempBytes, 0, tt, 0, count);
                        tempBytes = tt;
                    }
                } while (bt != 0);

                this.m_Data = new byte[count];
                System.arraycopy(tempBytes, 0, this.m_Data, 0, count);
                break;
            }
            default:
                ;
        }
        return iRet;
    }

    /**
    *
    */
    @Override
    public void dump(final PrintStream ps) throws IOException {

        if (this.m_Data != null) {
            if (this.m_Data.length < 16) {
                for (int iCnt = 0; iCnt < this.m_Data.length;) {
                    ps.print("\t(" + this.m_Data.length + ") ");
                    ps.println(ByteConvertor.toHexWithSpaces(this.m_Data, iCnt, 16));
                    iCnt += 16;
                }
            } else {
                ps.print(DSMCCObject.m_strIndent);
                ps.print("(" + this.m_Data.length + ") ");
                this.increaseIndent();
                final byte[] asciiBytes = new byte[this.m_Data.length];
                for (int iCnt0 = 0; iCnt0 < this.m_Data.length; iCnt0++) {
                    if ((this.m_Data[iCnt0] > 31) || (this.m_Data[iCnt0] < 0)) {
                        asciiBytes[iCnt0] = this.m_Data[iCnt0];
                    } else {
                        asciiBytes[iCnt0] = (byte) 46;
                    }

                }
                ps.println();
                for (int iCnt = 0; iCnt < this.m_Data.length;) {
                    ps.print(DSMCCObject.m_strIndent);
                    String strDump = ByteConvertor.toHexWithSpaces(this.m_Data, iCnt, 16);
                    ps.print(strDump);
                    int len = (this.m_Data.length - iCnt);
                    final String ascii = "  " + new String(asciiBytes, iCnt, (len > 16) ? 16 : len);
                    if (len < 16) {

                        while (len++ < 16) {
                            ps.print("   ");
                        }
                    }
                    ps.print(ascii);
                    ps.println("");
                    iCnt += 16;
                    strDump = null;
                }
                this.decreaseIndent();
            }
        }

    }

    /**
    *
    */
    @Override
    public int getLength() {
        // FIXME this is incorrect for NULL_TERMINATED sizeType
        return (this.m_Data.length + this.m_SizeType);
    }

    /**
    *
    */
    public void setSizeType(final byte type) {
        this.m_SizeType = type;
    }

    /**
    *
    */
    public byte[] getBytes() {
        return this.m_Data;
    }

    /**
    *
    */
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof ByteArray) {
            final ByteArray target = (ByteArray) obj;
            if (target.m_Data.length == this.m_Data.length) {
                for (int iCnt = this.m_Data.length - 1; iCnt > -1; iCnt--) {
                    if (this.m_Data[iCnt] != target.m_Data[iCnt]) {
                        return false;
                    }
                }
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    /**
    *
    */
    @Override
    public int hashCode() {
        int iRet = 0;
        for (int iCnt = 0; iCnt < this.m_Data.length;) {
            iRet = (iRet << 6) ^ (this.m_Data[1] ^ this.m_Data.length);
            iCnt += 4;
        }
        return iRet;
    }
}
