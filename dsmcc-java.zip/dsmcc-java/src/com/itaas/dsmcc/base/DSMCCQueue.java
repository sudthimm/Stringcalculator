// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

public class DSMCCQueue extends DSMCCObject {

    public static final int UNSIGNED_BYTE = 1;

    public static final int UNSIGNED_SHORT = 2;

    public static final int UNSIGNED_INTEGER = 4;

    public static final int EMPTY = 0;

    private final Vector mVect;

    private int mSizeType;

    private final DSMCCObject mValFactory;

    /**
     * @param sizeType
     *            specifies the size of the length field: EMPTY: no length field UNSIGNED_BYTE: 1 byte length
     *            field. UNSIGNED_SHORT: 2 byte length field. UNSIGNED_INTEGER: 4 length field.
     */
    public DSMCCQueue(final int sizeType, final DSMCCObject valFactory) {
        this.mVect = new Vector();
        this.mSizeType = sizeType;
        this.mValFactory = valFactory;
    }

    public void add(final Object obj) {
        this.mVect.add(obj);
    }

    public int size() {
        return this.mVect.size();
    }

    public Enumeration getElementsEnumeration() {
        return this.mVect.elements();
    }

    public int getSizeType() {
        return this.mSizeType;
    }

    public void setSizeType(final int type) {
        this.mSizeType = type;
    }

    public DSMCCObject getElement(final int idx) {
        return (DSMCCObject) this.mVect.get(idx);
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;
        int iLength = 0;

        if (this.mSizeType > 0) {
            if (this.mSizeType == DSMCCQueue.UNSIGNED_SHORT) {
                iLength = dis.readUShort();
            } else if (this.mSizeType == DSMCCQueue.UNSIGNED_BYTE) {
                iLength = dis.readUByte();
            } else if (this.mSizeType == DSMCCQueue.UNSIGNED_INTEGER) {
                iLength = (int) dis.readUInteger();
            }
            iRet += this.mSizeType;
        } else {
            iLength = (-1) * this.mSizeType;
            this.mSizeType = DSMCCQueue.EMPTY;
        }

        iRet += this.read(dis, iLength);
        return iRet;
    }

    public int read(final DSMCCInputStream dis, final int size) throws IOException {
        int iRet = 0;

        for (int iCnt = 0; iCnt < size; iCnt++) {
            final DSMCCObject obj = this.mValFactory.createNewInstance();
            iRet += obj.read(dis);
            this.mVect.add(obj);
        }
        return iRet;
    }

    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        // Write the size
        if (this.mSizeType > 0) {
            if (this.mSizeType == DSMCCQueue.UNSIGNED_SHORT) {
                dos.writeUShort(this.mVect.size());
            } else if (this.mSizeType == DSMCCQueue.UNSIGNED_BYTE) {
                dos.writeUByte((short) this.mVect.size());
            } else if (this.mSizeType == DSMCCQueue.UNSIGNED_INTEGER) {
                dos.writeUInteger(this.mVect.size());
            }
            iRet += this.mSizeType;
        }
        // Write the values
        for (int iCnt = 0; iCnt < this.mVect.size(); iCnt++) {
            final DSMCCObject val = (DSMCCObject) this.mVect.get(iCnt);
            iRet += val.write(dos);
        }

        return iRet;
    }

    @Override
    public void dump(final PrintStream ps) throws IOException {
        this.increaseIndent();
        if (this.mSizeType > 0) {
            ps.println("ValueCount = " + this.mVect.size());
        }
        for (int iCnt = 0; iCnt < this.mVect.size(); iCnt++) {
            final DSMCCObject val = (DSMCCObject) this.mVect.get(iCnt);
            if (val != null) {
                val.dump(ps);
            }
        }
        this.decreaseIndent();
    }

    @Override
    public int getLength() {
        int iRet = 0;

        if (this.mSizeType > 0) {
            iRet += this.mSizeType;
        }

        for (int iCnt = 0; iCnt < this.mVect.size(); iCnt++) {
            final DSMCCObject val = (DSMCCObject) this.mVect.get(iCnt);
            iRet += val.getLength();
        }
        return iRet;
    }

}
