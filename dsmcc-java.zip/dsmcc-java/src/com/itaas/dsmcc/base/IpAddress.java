// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 24, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.net.InetAddress;

public class IpAddress extends ByteArray {

    private String asString = null;

    public IpAddress() {
        super(4, ByteArray.EMPTY);
    }

    public IpAddress(final byte[] bytes) {
        super(4, ByteArray.EMPTY);
        this.copy(bytes);
    }

    public InetAddress getIPAddress() {
        String strBuf = "";
        for (int iCnt = 0; iCnt < 4; iCnt++) {
            final short sh = this.m_Data[iCnt];
            if (sh < 0) {
                strBuf += ("" + (256 + sh));
            } else {
                strBuf += sh;
            }
            if (iCnt != 3) {
                strBuf += ".";
            }
        }
        try {
            final InetAddress addr = InetAddress.getByName(strBuf);
            return addr;
        } catch (final Exception ex) {
        }
        return null;
    }

    public void setIPAddress(final InetAddress addr) {
        this.copy(addr.getAddress());
        this.asString = null;
    }

    @Override
    public String toString() {
        if (this.asString == null) {
            final StringBuffer strBuf = new StringBuffer();
            for (int iCnt = 0; iCnt < 4; iCnt++) {
                final short sh = this.m_Data[iCnt];
                if (sh < 0) {
                    strBuf.append("" + (256 + sh));
                } else {
                    strBuf.append(sh);
                }
                if (iCnt != 3) {
                    strBuf.append(".");
                }
            }
            this.asString = strBuf.toString();
        }
        return this.asString;
    }

    public static IpAddress valueOf(final String str) throws IllegalArgumentException {
        IpAddress ret = null;
        if (str == null) {
            throw new IllegalArgumentException("Null String parameter.");
        } else {
            final String[] eachByteStrs = str.split("[.]");
            if (eachByteStrs.length != 4) {
                throw new IllegalArgumentException("String needs 3 dots.");
            } else {
                final byte[] tmpBytes = new byte[4];
                int ndx;
                for (ndx = 0; ndx < 4; ndx++) {
                    try {
                        tmpBytes[ndx] = (byte) (Integer.parseInt(eachByteStrs[ndx]));
                    } catch (final Exception ex) {
                        throw new IllegalArgumentException("Non numeric field.");
                    }
                } // End for
                ret = new IpAddress(tmpBytes);
            }
        }
        return ret;
    }

    public static void main(final String[] args) {
        try {
            final InetAddress addr = InetAddress.getByName("www.yahoo.com");
            final IpAddress ip = new IpAddress();
            ip.setIPAddress(addr);
            final InetAddress addr2 = ip.getIPAddress();
            System.out.println("" + addr.getHostAddress() + ":" + addr2.getHostAddress());
        } catch (final Exception ex) {
        }
    }

    /**
    *
    */
    @Override
    public DSMCCObject createNewInstance() {
        return new IpAddress();
    }
}
