// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.base;

public class DSMCCByteObject extends DSMCCObject {

    private short m__Value;

    public DSMCCByteObject(final short val) {
        this.m__Value = val;
    }

    public DSMCCByteObject() {
        // m__Value = 0;
    }

    public short getValue() {
        return this.m__Value;
    }

    public void setValue(final short valValue) {
        this.m__Value = valValue;
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCByteObject();
    }

}
