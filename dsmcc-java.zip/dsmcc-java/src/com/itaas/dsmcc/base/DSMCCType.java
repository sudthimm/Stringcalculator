// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class DSMCCType {

    // This value may be wrong but for the time being its fine.
    public static short enUNSession = 0x02;

    public static short enPassthru = 0x05;

}
