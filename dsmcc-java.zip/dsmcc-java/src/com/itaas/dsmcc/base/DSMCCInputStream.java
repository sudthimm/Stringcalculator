// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 18, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.itaas.dsmcc.util.ByteConvertor;

public class DSMCCInputStream extends DataInputStream {

    public DSMCCInputStream(final InputStream os) {
        super(os);
    }

    public long readUInteger() throws IOException {
        final int iRead = this.readInt();
        long lRet = 0;
        if (iRead < 0) {
            lRet = (0xffffffffL) + iRead + 1;
        } else {
            lRet = iRead;
        }
        return lRet;
    }

    public int readUShort() throws IOException {
        return this.readUnsignedShort();
    }

    public short readUByte() throws IOException {
        return (short) this.readUnsignedByte();
    }

    public int read3BytesAsUInteger() throws IOException {
        final byte[] ba = new byte[4];
        this.readFully(ba, 1, 3);
        return ByteConvertor.fromByteArrayToInt(ba);
    }

    public long read4BytesAsUInteger() throws IOException {
        final byte[] ba = new byte[4];
        this.readFully(ba, 0, 3);
        return ByteConvertor.fromByteArrayToLong(ba);
    }

    public int read4BytesAsInteger() throws IOException {
        final byte[] ba = new byte[4];
        this.readFully(ba, 0, 3);
        return ByteConvertor.fromByteArrayToInt(ba);
    }
}
