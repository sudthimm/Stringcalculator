// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 24, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class DSMCCNsapAddress extends DSMCCObject {

    protected short m__AFIValue;// /< ISO/IEC 8348 registered

    protected ByteArray m__E164;

    protected IpAddress m__IpAddress;

    protected MacAddress m__MacAddress;

    protected short m__Selector;

    public DSMCCNsapAddress() {
        this.init_Construct(new MacAddress(), new IpAddress());
    }

    public DSMCCNsapAddress(final MacAddress mac) {
        this.init_Construct(mac, new IpAddress());
    }

    public DSMCCNsapAddress(final IpAddress ip) {
        this.init_Construct(new MacAddress(), ip);
    }

    private void init_Construct(final MacAddress mac, final IpAddress ip) {
        this.m__AFIValue = 0x2d;
        this.m__E164 = new ByteArray(8, ByteArray.EMPTY);
        this.m__IpAddress = ip;
        this.m__MacAddress = mac;
        this.m__Selector = 0x00;
    }

    @Override
    public int getLength() {
        return 20;
    }

    public MacAddress getMacAddress() {
        return this.m__MacAddress;
    }

    public void setMacAddress(final MacAddress valMacAddress) {
        this.m__MacAddress = valMacAddress;
    }

    public IpAddress getIpAddress() {
        return this.m__IpAddress;
    }

    public void setIpAddress(final IpAddress valIpAddress) {
        this.m__IpAddress = valIpAddress;
    }

    public ByteArray getE164() {
        return this.m__E164;
    }

    public void setE164(final ByteArray valE164) {
        this.m__E164 = valE164;
    }

    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCNsapAddress();
    }

    public short getAFIValue() {
        return this.m__AFIValue;
    }

    public void setAFIValue(final short valAFIValue) {
        this.m__AFIValue = valAFIValue;
    }

    public short getSelector() {
        return this.m__Selector;
    }

    public void setSelector(final short valSelector) {
        this.m__Selector = valSelector;
    }

    public byte[] getBytes() {
        final byte[] bRet = new byte[20];
        // copy the AFI
        bRet[0] = (byte) this.m__AFIValue;

        // copy the E164
        if (this.m__E164 != null) {
            System.arraycopy(this.m__E164.getBytes(), 0, bRet, 1, 8);
        }

        // copy the ip address
        if (this.m__IpAddress != null) {
            System.arraycopy(this.m__IpAddress.getBytes(), 0, bRet, 9, 4);
        }

        // copy the mac address
        if (this.m__MacAddress != null) {
            System.arraycopy(this.m__MacAddress.getBytes(), 0, bRet, 13, 6);
        }

        // Assign the selector
        bRet[19] = (byte) this.m__Selector;

        // return
        return bRet;
    }

}
