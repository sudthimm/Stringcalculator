// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.IOException;

import com.itaas.dsmcc.util.ItaasSerializable;

public class DSMCCMessageCommonHeader extends DSMCCObject implements ItaasSerializable {

    protected short m__ProtocolDiscriminator;

    protected short m__DsmccType;

    protected int m__MessageId;

    protected long m__TransactionId;

    protected short m__Reserved;

    protected short m__AdaLength;

    protected int m__MessageLength;

    protected DSMCCAdaptationHeader M__AdaptationHeader;

    public DSMCCMessageCommonHeader(final byte pd, final byte dt, final short mid, final int tid, final byte res,
            final short msglen, final DSMCCAdaptationHeader adaHdr) {
        this.init_Construct(pd, dt, mid, tid, res, msglen, adaHdr);
    }

    public DSMCCMessageCommonHeader(final DSMCCMessageCommonHeader hdr) {

        this.m__ProtocolDiscriminator = hdr.m__ProtocolDiscriminator;
        this.m__DsmccType = hdr.m__DsmccType;
        this.m__MessageId = hdr.m__MessageId;
        this.m__TransactionId = hdr.m__TransactionId;
        this.m__Reserved = hdr.m__Reserved;
        this.m__AdaLength = hdr.m__AdaLength;
        this.m__MessageLength = hdr.m__MessageLength;
        if (hdr.M__AdaptationHeader != null) {
            this.M__AdaptationHeader = new DSMCCAdaptationHeader(hdr.M__AdaptationHeader);
        } else {
            this.M__AdaptationHeader = null;
        }

    }

    public DSMCCMessageCommonHeader(final int dt, final int mid, final int tid, final DSMCCAdaptationHeader adaHdr) {
        byte adalength = 0;
        if (adaHdr != null) {
            adalength = (byte) adaHdr.getLength();
        }
        this.init_Construct(ProtocolDiscriminator.enDsmccProtocolDiscriminator, (byte) dt, (short) mid, tid, 0xff, 0,
                adaHdr);
    }

    public DSMCCMessageCommonHeader() {
        this.init_Construct(ProtocolDiscriminator.enDsmccProtocolDiscriminator, (byte) 0, (short) 0, 0, 0xff, 0, null);
    }

    public DSMCCMessageCommonHeader(final int dt, final int mid, final int tid) {
        this.init_Construct(ProtocolDiscriminator.enDsmccProtocolDiscriminator, (byte) dt, (short) mid, tid, 0xff, 0,
                null);
    }

    private void init_Construct(final byte pd, final byte dt, final short mid, final int tid, final int res,
            final int msglen, final DSMCCAdaptationHeader adaHdr) {
        this.m__ProtocolDiscriminator = pd;
        this.m__DsmccType = dt;
        this.m__MessageId = mid;
        this.m__TransactionId = tid;
        this.m__Reserved = (short) res;
        this.m__MessageLength = (short) msglen;
        this.M__AdaptationHeader = adaHdr;

    }

    @Override
    public int getLength() {
        int iRet = 11;// 1+1+2+4+1+2
        if (this.M__AdaptationHeader != null) {
            iRet += this.M__AdaptationHeader.getLength();
        }
        return iRet;
    }

    public void setAdaptationHeader(final DSMCCAdaptationHeader AdaptationHeader) {
        this.M__AdaptationHeader = AdaptationHeader;
        this.m__AdaLength = (byte) this.M__AdaptationHeader.getLength();
    }

    public DSMCCAdaptationHeader getAdaptationHeader() {
        return this.M__AdaptationHeader;
    }

    public int readAdaptationHeader(final DSMCCInputStream dis) throws IOException {
        if (this.m__AdaLength > 0) {
            this.M__AdaptationHeader = new DSMCCAdaptationHeader(this.m__AdaLength);
            return this.M__AdaptationHeader.read(dis);
        } else {
            return 0;
        }
    }

    public short getProtocolDiscriminator() {
        return this.m__ProtocolDiscriminator;
    }

    public void setProtocolDiscriminator(final short valProtocolDiscriminator) {
        this.m__ProtocolDiscriminator = valProtocolDiscriminator;
    }

    public short getDsmccType() {
        return this.m__DsmccType;
    }

    public void setDsmccType(final short valDsmccType) {
        this.m__DsmccType = valDsmccType;
    }

    public int getMessageId() {
        return this.m__MessageId;
    }

    public void setMessageId(final int valMessageId) {
        this.m__MessageId = valMessageId;
    }

    public long getTransactionId() {
        return this.m__TransactionId;
    }

    public void setTransactionId(final long valTransactionId) {
        this.m__TransactionId = valTransactionId;
    }

    public short getReserved() {
        return this.m__Reserved;
    }

    public void setReserved(final short valReserved) {
        this.m__Reserved = valReserved;
    }

    public short getAdaLength() {
        return this.m__AdaLength;
    }

    public void setAdaLength(final short valAdaLength) {
        this.m__AdaLength = valAdaLength;
    }

    public int getMessageLength() {
        return this.m__MessageLength;
    }

    public void setMessageLength(final int valMessageLength) {
        this.m__MessageLength = valMessageLength;
    }

}
