// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.IOException;

public class DSMCCUnknownMessage extends DSMCCMessage {

    private ByteArray M__Data;

    public DSMCCUnknownMessage(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
    }

    public int readData(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        final int iLen = this.m_Header.getMessageLength();

        if (iLen > 0) {
            this.M__Data = new ByteArray(iLen);
            this.M__Data.setSizeType(ByteArray.EMPTY);
            iRet += this.M__Data.read(dis);
        }

        return iRet;
    }

    public ByteArray getData() {
        return this.M__Data;
    }

    public void setData(final ByteArray valData) {
        this.M__Data = valData;
    }
}
