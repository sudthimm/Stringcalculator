// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class ReasonCode {

    public static final int enRsnOK = 0x0000;

    public static final int enRsnNormal = 0x0001;

    public static final int enRsnClProcError = 0x0002;

    public static final int enRsnNeProcError = 0x0003;

    public static final int enRsnSeProcError = 0x0004;

    public static final int enRsnClFormatError = 0x0005;

    public static final int enRsnNeFormatError = 0x0006;

    public static final int enRsnSeFormatError = 0x0007;

    public static final int enRsnNeConfigCnf = 0x0008;

    public static final int enRsnSeTranRefuse = 0x0009;

    public static final int enRsnSeForwardOvl = 0x000A;

    public static final int enRsnSeForwardMnt = 0x000B;

    public static final int enRsnSeForwardUncond = 0x000C;

    public static final int enRsnSeRejResource = 0x000D;

    public static final int enRsnNeBroadcast = 0x000E;

    public static final int enRsnSeServiceTransfer = 0x000F;

    public static final int enRsnClNoSession = 0x0010;

    public static final int enRsnSeNoSession = 0x0011;

    public static final int enRsnNeNoSession = 0x0012;

    public static final int enRsnRetrans = 0x0013;

    public static final int enRsnNoTransaction = 0x0014;

    public static final int enRsnClNoResource = 0x0015;

    public static final int enRsnClRejResource = 0x0016;

    public static final int enRsnNeRejResource = 0x0017;

    public static final int enRsnTimerExpired = 0x0018;

    public static final int enRsnClSessionRelease = 0x0019;

    public static final int enRsnSeSessionRelease = 0x001A;

    public static final int enRsnNeSessionRelease = 0x001B;
}
