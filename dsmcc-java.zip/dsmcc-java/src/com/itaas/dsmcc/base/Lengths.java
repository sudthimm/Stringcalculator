// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class Lengths {

    public static final int enSessionIdLen = 0x0A;

    public static final int enResourceNumCountLen = 0x02;

    public static final int enResourceNumLen = 0x02;

    public static final int enUUDataLen = 0x02;

    public static final int enPvtDataLen = 0x02;

    public static final int enResDescCntLen = 0x02;

    public static final int enDeviceIdLen = 0x06;

    public static final int enForwardCountLen = 0x02;

    public static final int enPrivateDataCountLen = 0x02;

    public static final int enReasonLen = 0x02;

    public static final int enResourceCountLen = 0x02;

    public static final int enResponseLen = 0x02;

    public static final int enSdbIdLen = 0x06;

    public static final int enSessionCountLen = 0x02;

    public static final int enSessionNumLen = 0x04;

    public static final int enStatusCountLen = 0x02;

    public static final int enStatusTypeLen = 0x02;

    public static final int enUserIdLen = 0x14;

    public static final int enUuDataCountLen = 0x02;

    public static final int enAdaptationTypeLen = 0x01;

    public static final int enTypeOwnerIdLen = 0x03;

    public static final int enTypeOwnerValueLen = 0x03;

}
