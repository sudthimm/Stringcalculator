// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class DSMCCMessage extends DSMCCObject {

    protected DSMCCMessageCommonHeader m_Header;

    public DSMCCMessage() {
    }

    public DSMCCMessage(final DSMCCMessageCommonHeader hdr) {
        this.m_Header = hdr;
    }

    public DSMCCMessageCommonHeader getHeader() {
        return this.m_Header;
    }

    public void setHeader(final DSMCCMessageCommonHeader valHdr) {
        this.m_Header = valHdr;
    }

    @Override
    public void dump(final PrintStream ps) throws IOException {
        ps.println(DSMCCObject.m_strIndent + this.getClass());
        super.dump(ps);
        this.setPrintWriter(ps);
        this.m_Header.dump(ps);
        ps.println();
    }

    public int getMessageType() {
        return this.m_Header.getMessageId();
    }

    public long getTransactionId() {
        return this.m_Header.getTransactionId();
    }

    public void setTransactionId(final long txnId) {
        this.m_Header.setTransactionId(txnId);
    }

    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        final ByteArrayOutputStream byteStrm = new ByteArrayOutputStream(8192);
        final DSMCCOutputStream tmpStrm = new DSMCCOutputStream(byteStrm);

        // Get length
        int length = this.getLength();
        if (this.m_Header.getAdaptationHeader() != null) {
            length += this.m_Header.getAdaptationHeader().getLength();
            ;
        }
        this.m_Header.setMessageLength(length);

        int iRet = this.m_Header.write(tmpStrm);
        iRet += this.write(this, tmpStrm);
        final byte[] msgBytes = byteStrm.toByteArray();

        dos.write(msgBytes, 0, msgBytes.length);
        dos.flush();
        return iRet;
    }
}
