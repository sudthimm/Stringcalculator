// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 17, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.base;

import java.io.IOException;
import java.io.PrintStream;

import com.itaas.dsmcc.util.ByteConvertor;

public class DSMCCAdaptationHeader extends DSMCCObject
// implements ItaasSerializable
{

    protected short m_AdaptationType;

    private byte[] m_DataBytes;

    public DSMCCAdaptationHeader(final int length) {
        this.m_AdaptationType = 0;
        this.m_DataBytes = new byte[length - 1];
    }

    public DSMCCAdaptationHeader(final short type, final byte[] data) {
        this.m_AdaptationType = type;
        this.m_DataBytes = data;
    }

    public DSMCCAdaptationHeader(final DSMCCAdaptationHeader adaHdr) {
        if (adaHdr != null) {
            this.m_AdaptationType = adaHdr.m_AdaptationType;
            this.m_DataBytes = new byte[adaHdr.m_DataBytes.length];
            System.arraycopy(adaHdr.m_DataBytes, 0, this.m_DataBytes, 0, this.m_DataBytes.length);
        } else {
            this.m_AdaptationType = 0;
        }
    }

    @Override
    public int getLength() {
        if (this.m_DataBytes != null) {
            return (this.m_DataBytes.length + 1);
        } else {
            return 0;
        }
    }

    @Override
    public int write(final DSMCCOutputStream dos) throws IOException {
        int iRet = 0;
        dos.writeUByte(this.m_AdaptationType);
        iRet += 1;

        dos.Write(this.m_DataBytes);
        iRet += 1;

        return iRet;
    }

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;

        this.m_AdaptationType = dis.readUByte();
        iRet += 1;

        dis.read(this.m_DataBytes);
        iRet += this.m_DataBytes.length;

        return iRet;
    }

    public short getAdaptationType() {
        return this.m_AdaptationType;
    }

    public void setAdaptationType(final short valAdaptationType) {
        this.m_AdaptationType = valAdaptationType;
    }

    public byte[] getDataBytes() {
        return this.m_DataBytes;
    }

    public void setDataBytes(final byte[] val) {
        this.m_DataBytes = val;
    }

    @Override
    public void dump(final PrintStream ps) {
        ps.println("AdaptationType " + this.m_AdaptationType);
        ps.println("AdaptationData ");
        ps.println(ByteConvertor.toHexWithSpaces(this.m_DataBytes, 0, -1));
    }

    public static DSMCCAdaptationHeader createUserIdAdaptationHeader(final DSMCCNsapAddress nsap) {
        final byte[] bytes = new byte[21];
        bytes[0] = (byte) 0xFF; // reserved
        // Copy the NSAP to the byte array
        System.arraycopy(nsap.getBytes(), 0, bytes, 1, 20);

        // create the adaptation header
        final DSMCCAdaptationHeader adaptHeader = new DSMCCAdaptationHeader(AdaptationType.enAdaptationTypeUserID,
                bytes);

        return adaptHeader;
    }
}
