// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class AdaptationType {

    public static final short enAdaptationTypeReserved = (short) 0x00;

    public static final short enAdaptationTypeCondAccess = (short) 0x01;

    public static final short enAdaptationTypeUserID = (short) 0x02;

}
