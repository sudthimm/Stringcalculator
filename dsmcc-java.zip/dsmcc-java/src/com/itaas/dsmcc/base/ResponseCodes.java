// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class ResponseCodes {

    public static final int enRspOK = 0x0000;

    public static final int enRspClNoSession = 0x0001;

    public static final int enRspNeNoCalls = 0x0002;

    public static final int enRspNeInvalidClient = 0x0003;

    public static final int enRspNeInvalidServer = 0x0004;

    public static final int enRspNeNoSession = 0x0005;

    public static final int enRspSeNoCalls = 0x0006;

    public static final int enRspSeInvalidClient = 0x0007;

    public static final int enRspSeNoService = 0x0008;

    public static final int enRspSeNoCFS = 0x0009;

    public static final int enRspClNoResponse = 0x000A;

    public static final int enRspSeNoResponse = 0x000B;

    public static final int enRspSeNoSession = 0x0010;

    public static final int enRspNeResourceContinue = 0x0011;

    public static final int enRspNeResourceFailed = 0x0012;

    public static final int enRspNeResourceOK = 0x0013;

    public static final int enRspResourceNegotiate = 0x0014;

    public static final int enRspClSessProceed = 0x0015;

    public static final int enRspClUnkRequestID = 0x0016;

    public static final int enRspClNoResource = 0x0017;

    public static final int enRspClNoCalls = 0x0018;

    public static final int enRspNeNoResource = 0x0019;

    public static final int enRspSeNoResource = 0x0020;

    public static final int enRspSeRejResource = 0x0021;

    public static final int enRspClProcError = 0x0022;

    public static final int enRspNeProcError = 0x0023;

    public static final int enRspSeProcError = 0x0024;

    public static final int enRspNeFormatError = 0x0026;

    public static final int enRspSeFormatError = 0x0027;

    public static final int enRspSeForwardOvl = 0x0028;

    public static final int enRspForwardMnt = 0x0029;

    public static final int enRspClRejResource = 0x002A;

    public static final int enRspForwardUncond = 0x0030;

    public static final int enRspNeTransferFailed = 0x0031;

    public static final int enRspClTransferReject = 0x0032;

    public static final int enRspSeTransferReject = 0x0033;

    public static final int enRspTransferResource = 0x0034;

    public static final int enRspResourceCompleted = 0x0035;

    public static final int enRspForward = 0x0036;

    public static final int enRspNeForwardFailed = 0x0037;

    public static final int enRspClForwarded = 0x0038;

    public static final int enRspSeTransferNoRes = 0x0041;

    public static final int enRspNeNotOwner = 0x0042;

}
