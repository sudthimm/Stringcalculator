// ////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// ////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import com.itaas.dsmcc.util.ByteConvertor;

public class DSMCCSessionID extends DSMCCObject {

    public static final int SizeOf = 10;

    protected ByteArray m__the10Bytes;

    // Convenience members.
    protected MacAddress macAddress;

    protected long sessionNumber = 0;

    /**
     * Default constructor
     */
    public DSMCCSessionID() {
        this.init_Construct(new MacAddress(), 0);
    };

    /**
    *
    */
    public DSMCCSessionID(final String mac, final long sessionNum) {
        // Set the mac from the string;
        this.init_Construct(new MacAddress(mac), sessionNum);
    }

    /**
     *@param sessionId
     *            string representation of a session Id where the string is in format of 6 colon separated hex
     *            bytes, followed by a "/" and then the decimal sessionNumber (e.g. "01:02:03:04:05:06/100").
     */
    public DSMCCSessionID(final String sessionId) {
        // FIXME check for bad format
        this.init_Construct(new MacAddress(sessionId.substring(0, 17)), Long.parseLong(sessionId.substring(18)));
    }

    /**
    *
    */
    private void init_Construct(final MacAddress mac, final long sessionNum) {
        this.macAddress = mac;
        this.sessionNumber = sessionNum;

        final byte[] macBytes = this.macAddress.getBytes();
        final int totalByteCnt = macBytes.length + 4;

        final byte[] allTheBytes = new byte[totalByteCnt];

        System.arraycopy(macBytes, 0, allTheBytes, 0, macBytes.length);
        int ndx;

        // bytes at index 0 to 5 are the MAC Address bytes.
        // Session number is put into bytes 6 to 9, high byte first.
        for (ndx = macBytes.length; ndx < totalByteCnt; ndx++) {
            allTheBytes[ndx] = (byte) ((this.sessionNumber >> ((totalByteCnt - 1 - ndx) * 8)) & 0xff);
        }

        this.m__the10Bytes = new ByteArray(allTheBytes, ByteArray.EMPTY);
    }

    /**
    *
    */
    public MacAddress getMacAddress() {
        return this.macAddress;
    }

    /**
    *
    */
    public void setMacAddress(final MacAddress valMacAddress) {
        this.macAddress = valMacAddress;
        this.init_Construct(this.macAddress, this.sessionNumber);
    }

    /**
    *
    */
    public long getSessionNumber() {
        return this.sessionNumber;
    }

    /**
    *
    */
    public void setSessionNumber(final long sessionNum) {
        this.sessionNumber = sessionNum;
        this.init_Construct(this.macAddress, this.sessionNumber);
    }

    /**
    *
    */
    public void setthe10Bytes(final ByteArray byteArray) {
        final byte[] bytes = byteArray.getBytes();
        // FIXME check for exactly 10 bytes and do something about it.
        if (bytes.length >= 10) {
            this.m__the10Bytes = new ByteArray(bytes, 10, ByteArray.EMPTY);
            this.macAddress = new MacAddress(bytes);
            int ndx;
            this.sessionNumber = 0;
            for (ndx = 6; ndx < 10; ndx++) {
                this.sessionNumber = (this.sessionNumber << 8) | (bytes[ndx] & 0xff);
            }
        }
    }

    /**
    *
    */
    public ByteArray getthe10Bytes() {
        return this.m__the10Bytes;
    }

    /**
    *
    */
    @Override
    public DSMCCObject createNewInstance() {
        return new DSMCCSessionID();
    }

    /**
    *
    */
    public byte[] getAsBytes() {
        return this.m__the10Bytes.getBytes();
    }

    /**
    *
    */
    public ByteArray getAsByteArray() {
        return this.m__the10Bytes;
    }

    /**
    *
    */
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer(24);
        sb.append(ByteConvertor.toHexWithDelim(this.macAddress.getBytes(), ':', 0, 6));
        sb.append(':');
        sb.append(this.sessionNumber);
        return sb.toString();
        // return (ByteConvertor.toHexWithDelim(macAddress.getBytes(),':',0,6) + instanceId);
    }

    /**
    *
    */
    @Override
    public boolean equals(final Object obj) {
        boolean is_equal = false;
        if (obj instanceof DSMCCSessionID) {
            final DSMCCSessionID target = (DSMCCSessionID) obj;
            if ((target.sessionNumber == this.sessionNumber) && target.macAddress.equals(this.macAddress)) {
                is_equal = true;
            }
        }
        return is_equal;
    }

    /**
    *
    */
    @Override
    public int hashCode() {
        final byte[] bytes = this.macAddress.getBytes();
        final int h1 = (int) this.sessionNumber;
        final int h2 = bytes[2];
        final int h3 = bytes[3];
        final int h4 = bytes[4];
        final int h5 = bytes[5] & (0xFFFFFFFD);
        final int hash = // h1
        // ^(
        h5 | h4 << 8 | h3 << 16 | h2 << 24
        // )
        ;
        return hash;
    }
}
