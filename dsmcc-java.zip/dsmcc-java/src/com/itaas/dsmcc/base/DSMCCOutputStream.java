// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 18, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class DSMCCOutputStream extends DataOutputStream {

    public DSMCCOutputStream(final OutputStream os) {
        super(os);
    }

    public int Write(final byte[] bytes) throws IOException {
        if (bytes != null) {
            this.write(bytes);
            return bytes.length;
        } else {
            return 0;
        }

    }

    public void writeUInteger(final long val) throws IOException {
        final int iVal = (int) (0x00000000ffffffff & val);
        this.writeInt(iVal);
    }

    public void writeUShort(final int val) throws IOException {
        this.writeShort(val);
    }

    public void writeUByte(final short val) throws IOException {
        this.writeByte(val);
    }

}
