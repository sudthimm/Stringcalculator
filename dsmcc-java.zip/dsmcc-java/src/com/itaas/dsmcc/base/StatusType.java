// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 16, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

public class StatusType {

    public static final int enStatusTypeReserved = 0x0000;

    public static final int enIdentifySessList = 0x0001;

    public static final int enIdentifySessStatus = 0x0002;

    public static final int enIdentifyConfiguration = 0x0003;

    public static final int enQueryResourceDescriptor = 0x0004;

    public static final int enQueryResourceStatus = 0x0005;

}
