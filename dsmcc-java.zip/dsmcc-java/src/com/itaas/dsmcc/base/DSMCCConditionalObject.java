// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 25, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.base;

import java.io.IOException;

public class DSMCCConditionalObject extends DSMCCObject {

    @Override
    public int read(final DSMCCInputStream dis) throws IOException {
        // Conditional objects do not have this method
        return -1000;
    }

}
