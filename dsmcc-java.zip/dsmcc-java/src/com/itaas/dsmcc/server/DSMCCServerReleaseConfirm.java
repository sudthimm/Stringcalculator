package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the Network to a server in response to a serverReleaseRequest message. This
 * Message falls under the group:Session Release Reference:section-4.2.5.6 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerReleaseConfirm extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Response;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12;

    public DSMCCServerReleaseConfirm(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);

    }

    public DSMCCServerReleaseConfirm(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int response, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Response = response;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;

    }

    /*
     * We don't need this DSMCC_RESULT GetSessionId(DSMCCSessionID psid) { m__SessionID = psid; return }
     */

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public int getResponse() {
        return this.m__Response;

    }

    public void setResponse(final int response) {
        this.m__Response = response;

    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;

    }

    /*
     * we don't need this DSMCC_RESULT GetUserData(DSMCCUserData userData) { m__UserData = userData; }
     */

    public void setUserData(final DSMCCUserData userData) {

        this.m__UserData = userData;

    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCServerReleaseConfirm Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerReleaseConfirm msg = new DSMCCServerReleaseConfirm(hdr);
        msg.read(is);

        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Release_Confirm.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }
}
