package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorContainer;

/**
 *This is the message sent from the server to the network to request that resources be added to a session.
 * This Message falls under the group:Add Resource Reference:section-4.2.6.3 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerAddResourceRequest extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected DSMCCResourceDescriptorContainer m__Resources;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 10;

    public DSMCCServerAddResourceRequest(final DSMCCMessageCommonHeader hdr)// /< Constructor
    {
        this.setHeader(hdr);

    }

    public DSMCCServerAddResourceRequest(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final DSMCCResourceDescriptorContainer resources, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Resources = resources;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public DSMCCSessionID getSessionId() {

        return this.m__SessionId;

    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;

    }

    public DSMCCResourceDescriptorContainer getResources() {
        return this.m__Resources;
    }

    public void setResources(final DSMCCResourceDescriptorContainer resources) {
        this.m__Resources = resources;

    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;

    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCServerAddResourceRequest Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerAddResourceRequest msg = new DSMCCServerAddResourceRequest(hdr);
        msg.read(is);
        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Add_Resource_Request.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

}
