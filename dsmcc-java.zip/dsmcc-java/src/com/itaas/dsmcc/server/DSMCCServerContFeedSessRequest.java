// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorContainer;

/**
 * This message is sent from a Server to the Network to request that a continuous feed session (CFS) be
 * established
 */

public class DSMCCServerContFeedSessRequest extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reserved;

    protected DSMCCNsapAddress m__ServerId;

    protected DSMCCResourceDescriptorContainer m__Resources;

    // Constructor
    public DSMCCServerContFeedSessRequest(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
    }

    public static DSMCCServerContFeedSessRequest Create(final DSMCCMessageCommonHeader hdr, final DSMCCInputStream is)
            throws IOException {
        final DSMCCServerContFeedSessRequest msg = new DSMCCServerContFeedSessRequest(hdr);
        msg.read(is);
        return msg;
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID valSessId) {
        this.m__SessionId = valSessId;
    }

    public int getReserved() {
        return this.m__Reserved;
    }

    public void setReserved(final int valReserved) {
        this.m__Reserved = valReserved;
    }

    public DSMCCNsapAddress getServerId() {
        return this.m__ServerId;
    }

    public void setServerId(final DSMCCNsapAddress valServerId) {
        this.m__ServerId = valServerId;
    }

    public DSMCCResourceDescriptorContainer getResources() {
        return this.m__Resources;
    }

    public void setResources(final DSMCCResourceDescriptorContainer resources) {
        this.m__Resources = resources;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_CFS_Request.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

}
