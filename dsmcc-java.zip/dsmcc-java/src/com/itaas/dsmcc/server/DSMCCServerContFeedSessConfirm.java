// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorContainer;

/**
 * This message is sent from the Network to a Server in response to a ServerContinuousFeedSessionRequest
 * message.
 */

public class DSMCCServerContFeedSessConfirm extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;;

    protected int m__Response;

    protected DSMCCResourceDescriptorContainer m__Resources;

    // Constructor
    public DSMCCServerContFeedSessConfirm(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID valSessionId) {
        this.m__SessionId = valSessionId;
    }

    public int getResponse() {
        return this.m__Response;
    }

    public void setResponse(final int valResponse) {
        this.m__Response = valResponse;
    }

    public DSMCCResourceDescriptorContainer getResources() {
        return this.m__Resources;
    }

    public void setResources(final DSMCCResourceDescriptorContainer resources) {
        this.m__Resources = resources;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_CFS_Confirm.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

}
