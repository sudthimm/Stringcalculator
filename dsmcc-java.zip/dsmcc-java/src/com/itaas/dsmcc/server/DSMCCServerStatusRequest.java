// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCAdaptationHeader;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.StatusType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the server to the network to request a status message. This Message falls
 * under the group:status related messages. Reference:section-4.2.9.5 and 4.9.7 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerStatusRequest extends DSMCCMessage {

    protected int m__Reason;

    protected DSMCCNsapAddress m__ServerId;

    protected int m__StatusType;

    protected ByteArray M__StatusBytes;

    // Constructor
    public DSMCCServerStatusRequest(final DSMCCMessageCommonHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    // Constructor
    public DSMCCServerStatusRequest(final DSMCCMessageCommonHeader hdr, final int statusType) {
        this.init_Construct();
        this.setHeader(hdr);
        this.m__StatusType = statusType;
    }

    // Constructor
    public DSMCCServerStatusRequest(final DSMCCMessageCommonHeader hdr, final int statusType,
            final ByteArray statusBytes) {

        this.setHeader(hdr);
        this.m__StatusType = statusType;
        this.M__StatusBytes = statusBytes;
    }

    private void init_Construct() {
        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int getStatusBytesCount() {
        if (this.M__StatusBytes != null) {
            return this.M__StatusBytes.getLength();
        } else {
            return 0;
        }
    }

    public static DSMCCServerStatusRequest Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerStatusRequest msg = new DSMCCServerStatusRequest(hdr);
        msg.read(is);
        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Status_Request.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

    public ByteArray getStatusBytes() {
        return this.M__StatusBytes;
    }

    public void setStatusBytes(final ByteArray valStatusBytes) {
        this.M__StatusBytes = valStatusBytes;
    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int valReason) {
        this.m__Reason = valReason;
    }

    public int getStatusType() {
        return this.m__StatusType;
    }

    public void setStatusType(final int valStatusType) {
        this.m__StatusType = valStatusType;
    }

    public int readStatusBytes(final DSMCCInputStream dis) throws IOException {

        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        return this.M__StatusBytes.read(dis);

    }

    public DSMCCNsapAddress getServerId() {
        return this.m__ServerId;
    }

    public void setServerId(final DSMCCNsapAddress valServerId) {
        this.m__ServerId = valServerId;
    }

    // this is a utility method to create a request by passing nsap address
    public static DSMCCServerStatusRequest createSessionListRequest(final DSMCCNsapAddress myNsap) {
        // Create the header
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(myNsap);
        final DSMCCMessageCommonHeader hdr = new DSMCCMessageCommonHeader();
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        final DSMCCServerStatusRequest retMsg = new DSMCCServerStatusRequest(hdr);
        retMsg.setServerId(myNsap);
        // set the status type
        retMsg.setStatusType(StatusType.enIdentifySessList);
        retMsg.setReason(0x01);

        return retMsg;
    }

    // this is a utility method to create a request by passing nsap address
    public static DSMCCServerStatusRequest createSessionStatusRequest(final DSMCCNsapAddress myNsap,
            final DSMCCSessionID sess) {
        // Create the header
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(myNsap);
        final DSMCCMessageCommonHeader hdr = new DSMCCMessageCommonHeader();
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        final DSMCCServerStatusRequest retMsg = new DSMCCServerStatusRequest(hdr);

        // set the status type
        retMsg.setStatusType(StatusType.enIdentifySessStatus);

        // set session id
        final ByteArray ba = sess.getAsByteArray();
        ba.setSizeType(ByteArray.UNSIGNED_BYTE);
        retMsg.setStatusBytes(ba);

        return retMsg;
    }

}
