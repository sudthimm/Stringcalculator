package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the server to the network in response to a serverReleaseIndication message
 * sent by the Network. This Message falls under the group:Session Release Reference:section-4.2.5.8 of ISA
 * Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerReleaseResponse extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Response;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12;

    public DSMCCServerReleaseResponse(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
    }

    public DSMCCServerReleaseResponse(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int response, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Response = response;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public short GetPayloadLength() {
        return (short) this.getLength();

    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;

    }

    public int getResponse() {
        return this.m__Response;
    }

    public void setResponse(final int response) {
        this.m__Response = response;
    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;

    }

    public static DSMCCServerReleaseResponse Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerReleaseResponse msg = new DSMCCServerReleaseResponse(hdr);

        msg.read(is);

        return msg;

    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Release_Response.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

}
