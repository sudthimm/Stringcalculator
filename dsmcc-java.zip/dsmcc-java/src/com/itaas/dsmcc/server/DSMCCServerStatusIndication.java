// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCAdaptationHeader;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.StatusType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the Network to the server to request a status message from the server. This
 * Message falls under the group:status related messages. Reference:section-4.2.9.7 and 4.10.4.1 of ISA
 * Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerStatusIndication extends DSMCCMessage {

    protected int m__Reason;

    protected int m__StatusType;

    protected ByteArray M__StatusBytes;

    // Constructor
    public DSMCCServerStatusIndication(final DSMCCMessageCommonHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    // Constructor
    public DSMCCServerStatusIndication(final DSMCCMessageCommonHeader hdr, final int statusType) {
        this.init_Construct();
        this.setHeader(hdr);
        this.m__StatusType = statusType;
    }

    // Constructor
    public DSMCCServerStatusIndication(final DSMCCMessageCommonHeader hdr, final int statusType,
            final ByteArray statusBytes) {

        this.setHeader(hdr);
        this.m__StatusType = statusType;
        this.M__StatusBytes = statusBytes;
    }

    private void init_Construct() {
        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int getStatusBytesCount() {
        if (this.M__StatusBytes != null) {
            return this.M__StatusBytes.getLength();
        } else {
            return 0;
        }
    }

    public static DSMCCServerStatusIndication Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerStatusIndication msg = new DSMCCServerStatusIndication(hdr);
        msg.read(is);
        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Status_Indication.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

    public ByteArray getStatusBytes() {
        return this.M__StatusBytes;
    }

    public void setStatusBytes(final ByteArray valStatusBytes) {
        this.M__StatusBytes = valStatusBytes;
    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int valReason) {
        this.m__Reason = valReason;
    }

    public int getStatusType() {
        return this.m__StatusType;
    }

    public void setStatusType(final int valStatusType) {
        this.m__StatusType = valStatusType;
    }

    public int readStatusBytes(final DSMCCInputStream dis) throws IOException {

        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        return this.M__StatusBytes.read(dis);

    }

    // this is a utility method to create a Indication by passing nsap address
    public static DSMCCServerStatusIndication createSessionListIndication(final DSMCCNsapAddress myNsap) {
        // Create the header
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(myNsap);
        final DSMCCMessageCommonHeader hdr = new DSMCCMessageCommonHeader();
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        final DSMCCServerStatusIndication retMsg = new DSMCCServerStatusIndication(hdr);

        // set the status type
        retMsg.setStatusType(StatusType.enIdentifySessList);

        return retMsg;
    }
}
