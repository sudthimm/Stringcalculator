package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the Network to a server to initiate a session Release which was requested by
 * the client by sending clientReleaseRequest message. This Message falls under the group:Session Release
 * Reference:section-4.2.5.7 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerReleaseIndication extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reason;

    protected DSMCCUserData m__UserData;

    public static final int FixedPayloadSize = 12;

    public DSMCCServerReleaseIndication(final DSMCCMessageCommonHeader hdr) // /< Constructor
    {
        this.setHeader(hdr);
    }

    public DSMCCServerReleaseIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int reason, final DSMCCUserData userData) {

        this.m__SessionId = session;
        this.m__Reason = reason;
        this.m__UserData = userData;

        this.setHeader(hdr);
    }

    public DSMCCSessionID getSessionId() {

        return this.m__SessionId;

    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int reason) {

        this.m__Reason = reason;

    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCServerReleaseIndication Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {

        final DSMCCServerReleaseIndication msg = new DSMCCServerReleaseIndication(hdr);
        msg.read(is);

        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Release_Indication.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

}
