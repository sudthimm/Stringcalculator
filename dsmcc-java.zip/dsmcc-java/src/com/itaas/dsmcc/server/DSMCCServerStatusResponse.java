// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Oct 02, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCAdaptationHeader;
import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.StatusType;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the server to the Network in response to a ServerStatusIndication This
 * Message falls under the group:status related messages. Reference:section-4.2.9.8 and 4.10.4.1 of ISA
 * Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerStatusResponse extends DSMCCMessage {

    protected int m__Response;

    protected int m__StatusType;

    protected ByteArray M__StatusBytes;

    // Constructor
    public DSMCCServerStatusResponse(final DSMCCMessageCommonHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    // Constructor
    public DSMCCServerStatusResponse(final DSMCCMessageCommonHeader hdr, final int statusType) {
        this.init_Construct();
        this.setHeader(hdr);
        this.m__StatusType = statusType;
    }

    // Constructor
    public DSMCCServerStatusResponse(final DSMCCMessageCommonHeader hdr, final int statusType,
            final ByteArray statusBytes) {

        this.setHeader(hdr);
        this.m__StatusType = statusType;
        this.M__StatusBytes = statusBytes;
    }

    private void init_Construct() {
        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int getStatusBytesCount() {
        if (this.M__StatusBytes != null) {
            return this.M__StatusBytes.getLength();
        } else {
            return 0;
        }
    }

    public static DSMCCServerStatusResponse Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerStatusResponse msg = new DSMCCServerStatusResponse(hdr);
        msg.read(is);
        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Status_Response.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);
    }

    public ByteArray getStatusBytes() {
        return this.M__StatusBytes;
    }

    public void setStatusBytes(final ByteArray valStatusBytes) {
        this.M__StatusBytes = valStatusBytes;
    }

    public int getResponse() {
        return this.m__Response;
    }

    public void setResponse(final int valResponse) {
        this.m__Response = valResponse;
    }

    public int getStatusType() {
        return this.m__StatusType;
    }

    public void setStatusType(final int valStatusType) {
        this.m__StatusType = valStatusType;
    }

    public int readStatusBytes(final DSMCCInputStream dis) throws IOException {

        this.M__StatusBytes = new ByteArray(0, ByteArray.UNSIGNED_SHORT);
        return this.M__StatusBytes.read(dis);

    }

    // this is a utility method to create a Response by passing nsap address
    public static DSMCCServerStatusResponse createSessionListResponse(final DSMCCNsapAddress myNsap) {
        // Create the header
        final DSMCCAdaptationHeader adaHdr = DSMCCAdaptationHeader.createUserIdAdaptationHeader(myNsap);
        final DSMCCMessageCommonHeader hdr = new DSMCCMessageCommonHeader();
        hdr.setAdaptationHeader(adaHdr);

        // Create the message
        final DSMCCServerStatusResponse retMsg = new DSMCCServerStatusResponse(hdr);

        // set the status type
        retMsg.setStatusType(StatusType.enIdentifySessList);

        return retMsg;
    }
}
