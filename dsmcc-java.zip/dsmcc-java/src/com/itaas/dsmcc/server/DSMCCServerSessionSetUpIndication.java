// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 23, 2003
// //////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.server;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCMessageFactory;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCQueue;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCType;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.server.DSMCCServerMessageType;

/**
 *This is the message sent from the Network to a server to establish a session which was requested by a
 * client. This Message falls under the group:Session Set-up Reference:section-4.2.4.3 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCServerSessionSetUpIndication extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reserved;

    protected DSMCCNsapAddress m__ClientId;

    protected DSMCCNsapAddress m__ServerId;

    private DSMCCQueue M__ForwardServers;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 24;

    // Constructor
    public DSMCCServerSessionSetUpIndication(final DSMCCMessageCommonHeader hdr) {
        this.init_Construct();
        this.setHeader(hdr);
    }

    // Constructor
    public DSMCCServerSessionSetUpIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final DSMCCNsapAddress clientId, final DSMCCNsapAddress serverId) {
        this.m__SessionId = session;
        this.m__ClientId = clientId;
        this.m__ServerId = serverId;
        this.setHeader(hdr);
    }

    // Constructor
    public DSMCCServerSessionSetUpIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final DSMCCNsapAddress clientId, final DSMCCNsapAddress serverId, final DSMCCQueue ForwardServers) {

        this.setHeader(hdr);
        this.m__SessionId = session;
        this.m__ClientId = clientId;
        this.m__ServerId = serverId;

    }

    // Constructor
    public DSMCCServerSessionSetUpIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final DSMCCNsapAddress serverId, final DSMCCUserData userData) {
        this.setHeader(hdr);
        this.m__SessionId = session;
        this.m__UserData = userData;
        this.m__ServerId = serverId;
    }

    private void init_Construct() {
        this.M__ForwardServers = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCNsapAddress());
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int getForwardCount() {
        if (this.M__ForwardServers != null) {
            return this.M__ForwardServers.size();
        } else {
            return 0;
        }
    }

    public void addForwardServerId(final DSMCCNsapAddress pForwardServerId) {
        if (this.M__ForwardServers == null) {
            this.M__ForwardServers = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCNsapAddress());
        }

        this.M__ForwardServers.add(pForwardServerId);
    }

    public static DSMCCServerSessionSetUpIndication Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCServerSessionSetUpIndication msg = new DSMCCServerSessionSetUpIndication(hdr);
        msg.read(is);
        return msg;
    }

    public int readForwardServers(final DSMCCInputStream dis) throws IOException {
        return this.M__ForwardServers.read(dis);
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID valSessionId) {
        this.m__SessionId = valSessionId;
    }

    public int getReserved() {
        return this.m__Reserved;
    }

    public void setReserved(final int valReserved) {
        this.m__Reserved = valReserved;
    }

    public DSMCCNsapAddress getClientId() {
        return this.m__ClientId;
    }

    public void setClientId(final DSMCCNsapAddress valClienttId) {
        this.m__ClientId = valClienttId;
    }

    public DSMCCNsapAddress getServerId() {
        return this.m__ServerId;
    }

    public void setServerId(final DSMCCNsapAddress valServerId) {
        this.m__ServerId = valServerId;
    }

    public DSMCCQueue getForwardServers() {
        return this.M__ForwardServers;
    }

    public void setForwardServers(final DSMCCQueue valForwardServers) {
        this.M__ForwardServers = valForwardServers;
    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData valUserData) {
        this.m__UserData = valUserData;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setMessageId(DSMCCServerMessageType.enServer_Session_Setup_Indication.getMessageType());
        valHeader.setDsmccType(DSMCCType.enUNSession);
        super.setHeader(valHeader);

    }

    public static void main(final String[] args) {

        try {
            final java.io.FileInputStream fis = new java.io.FileInputStream("d:\\itaas\\isa\\test\\TestData.bin");
            final DSMCCInputStream dis = new DSMCCInputStream(fis);
            while (dis.available() > 0) {
                final DSMCCMessage msg = DSMCCMessageFactory.create(dis);
                if (msg != null) {
                    msg.dump(System.out);
                }
                System.out.println("");
            }
            // DSMCCOutputStream dos = new DSMCCOutputStream( new ByteArrayOutputStream());
            // msg.write(dos);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }
    }

}
