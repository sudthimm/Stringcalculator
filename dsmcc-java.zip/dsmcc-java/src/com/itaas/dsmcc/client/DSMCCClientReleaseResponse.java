/*
 * DSMCCClientReleaseResponse.java Created on July 9, 2003, 8:41 AM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;

/**
 *This is the message sent from the client to the Network in response to a ClientReleaseIndication message to
 * indicate the client's response to the request. This Message falls under the group:Session Release
 * Reference:section-4.2.5.4 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCClientReleaseResponse extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Response;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12;// /<10 bytes for m__SessionID, 2 for response

    public DSMCCClientReleaseResponse(final DSMCCMessageCommonHeader hdr) // /< Constructor
    {
        this.setHeader(hdr);
    }

    public DSMCCClientReleaseResponse(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int response, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Response = response;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {

        this.m__SessionId = sessionId;

    }

    public int getResponse() {
        return this.m__Response;
    }

    public void setResponse(final int response) {

        this.m__Response = response;

    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();

    }

    public static DSMCCClientReleaseResponse Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {

        final DSMCCClientReleaseResponse msg = new DSMCCClientReleaseResponse(hdr);

        msg.read(is);

        return msg;
    }

}
