/*
 * DSMCCClientSessionSetUpRequest.java Created on July 8, 2003, 2:55 PM
 */

package com.itaas.dsmcc.client;

import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;

/**
 *This is the message sent from a client to the Network to request that a session be established wih the
 * requested serverId. This Message falls under the group:Session Set-up Reference:section-4.2.4.1 of ISA
 * Specification
 * 
 * @author chintan Desai
 */

public class DSMCCClientSessionSetUpRequest extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reserved;

    protected DSMCCNsapAddress m__ClientId;

    protected DSMCCNsapAddress m__ServerId;

    protected DSMCCUserData m__UserData;

    // /< 10 bytes for m__SessionID, 2 for response, 20 for ServerId and 20 for next serverId
    static final int FixedPayloadSize = 52;

    public DSMCCClientSessionSetUpRequest(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
    }

    public DSMCCClientSessionSetUpRequest(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final DSMCCNsapAddress clientId, final DSMCCNsapAddress serverId, final DSMCCUserData userData) {
        this.setHeader(hdr);
        this.m__SessionId = session;
        this.m__ClientId = clientId;
        this.m__ServerId = serverId;
        this.m__UserData = userData;
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public DSMCCNsapAddress getClientId() {
        return this.m__ClientId;
    }

    public void setClientId(final DSMCCNsapAddress serverId) {
        this.m__ClientId = serverId;

    }

    public DSMCCNsapAddress getServerId() {
        return this.m__ServerId;

    }

    public void setServerId(final DSMCCNsapAddress NextServerId) {
        this.m__ServerId = NextServerId;

    }

    public DSMCCUserData getUserData() {

        return this.m__UserData;

    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;

    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int getReserved() {
        return this.m__Reserved;
    }

    public void setReserved(final int valReserved) {
        this.m__Reserved = valReserved;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader hdr) {
        hdr.setMessageId(DSMCCClientMessageType.enClient_Session_Setup_Request.getMessageType());
        super.setHeader(hdr);
    }

}
