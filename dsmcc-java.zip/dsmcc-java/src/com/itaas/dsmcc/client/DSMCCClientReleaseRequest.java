/*
 * DSMCCClientReleaseRequest.java Created on July 8, 2003, 3:55 PM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;

/**
 *This is the message sent from the client to the Network to request that a session be torn-down. This
 * Message falls under the group:Session Release Reference:section-4.2.5.1 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCClientReleaseRequest extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reason;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12; // /< 10 bytes for m__SessionID, 2 for reason

    public DSMCCClientReleaseRequest(final DSMCCMessageCommonHeader hdr)// /< Constructor
    {
        this.setHeader(hdr);

    }

    public DSMCCClientReleaseRequest(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int reason, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Reason = reason;
        this.m__UserData = userData;

        this.setHeader(hdr);
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {

        this.m__SessionId = sessionId;

    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int reason) {
        this.m__Reason = reason;
    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {

        this.m__UserData = userData;

    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientReleaseRequest Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCClientReleaseRequest msg = new DSMCCClientReleaseRequest(hdr);

        msg.read(is);

        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader hdr) {
        hdr.setMessageId(DSMCCClientMessageType.enClient_Release_Request.getMessageType());
        super.setHeader(hdr);
    }

}
