/*
 * DSMCCClientSessionProceedingIndication.java Created on July 9, 2003, 7:50 AM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;

/**
 *This is the message sent from the Network to the Client in response to a ClientSessionSetUpRequest message.
 * This Message falls under the group:Session Proceeding messages. Reference:section-4.2.11.1 and 4.8.1 of ISA
 * Specification
 * 
 * @author chintan Desai
 */

public class DSMCCClientSessionProceedingIndication extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reason;

    static final int FixedPayloadSize = 12;// /< 10 bytes for m__SessionID, 2 for reason

    public DSMCCClientSessionProceedingIndication(final DSMCCMessageCommonHeader hdr)// /< Constructor
    {
        this.setHeader(hdr);
    }

    public DSMCCClientSessionProceedingIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int reason) {
        this.m__SessionId = session;

        this.m__Reason = reason;

        this.setHeader(hdr);
    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int reason) {
        this.m__Reason = reason;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientSessionProceedingIndication Create(final DSMCCInputStream is,
            final DSMCCMessageCommonHeader hdr) throws IOException {

        final DSMCCClientSessionProceedingIndication msg = new DSMCCClientSessionProceedingIndication(hdr);

        msg.read(is);

        return msg;
    }
}
