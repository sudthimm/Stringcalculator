/*
 * DSMCCClientReleaseIndication.java Created on July 9, 2003, 8:14 AM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;

/**
 *This is the message sent from the Network to a client in response to a ServerReleaseRequest sent from the
 * server to Network ,to release the session from the server end. This Message falls under the group:Session
 * Release Reference:section-4.2.5.3 of ISA Specification
 * 
 * @author chintan Desai
 */
public class DSMCCClientReleaseIndication extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Reason;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12; // /<10 bytes for m__SessionID, 2 for reason

    public DSMCCClientReleaseIndication(final DSMCCMessageCommonHeader hdr)// /< Constructor
    {
        this.setHeader(hdr);
    }

    public DSMCCClientReleaseIndication(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int reason, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Reason = reason;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public int getReason() {
        return this.m__Reason;
    }

    public void setReason(final int reason) {

        this.m__Reason = reason;
    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientReleaseIndication Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {

        final DSMCCClientReleaseIndication msg = new DSMCCClientReleaseIndication(hdr);

        msg.read(is);

        return msg;

    }

}
