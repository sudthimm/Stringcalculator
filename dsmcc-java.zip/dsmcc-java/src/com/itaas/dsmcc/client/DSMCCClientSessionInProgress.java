/*
 * DSMCCClientSessionInProgress.java Created on July 8, 2003, 4:20 PM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;
import java.util.Enumeration;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCQueue;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;

/**
 *This is the message sent from the Client to Network periodically to inform the Network of the sessions
 * which are active on the client . This Message falls under the group:Session In Progress Messages.
 * Reference:section-4.2.14.1 of ISA Specification.
 * 
 * @author chintan Desai
 */

public class DSMCCClientSessionInProgress extends DSMCCMessage {

    protected DSMCCQueue M__SessionIds;

    // protected CSessionIdQueue::const_iterator mIterator;

    public DSMCCClientSessionInProgress(final DSMCCMessageCommonHeader hdr)// /<Constructor
    {
        this.setHeader(hdr);
        this.M__SessionIds = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCSessionID());
    }

    public DSMCCClientSessionInProgress(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session) {
        this.setHeader(hdr);
        this.M__SessionIds = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCSessionID());
        this.M__SessionIds.add(session);

    }

    public Enumeration getSessionIdsAsEnum() {
        return this.M__SessionIds.getElementsEnumeration();
    }

    public DSMCCQueue getSessionIds() {
        return this.M__SessionIds;
    }

    public void addSessionId(final DSMCCSessionID sessionId) {
        this.M__SessionIds.add(sessionId);
    }

    public int getSessionIdCount() {
        return this.M__SessionIds.size();
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientSessionInProgress Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCClientSessionInProgress msg = new DSMCCClientSessionInProgress(hdr);

        msg.read(is);

        return msg;
    }

    public int readSessionIds(final DSMCCInputStream dis) throws IOException {
        int iRet = 0;
        if (this.M__SessionIds == null) {
            this.M__SessionIds = new DSMCCQueue(DSMCCQueue.UNSIGNED_SHORT, new DSMCCSessionID());
        }

        iRet = this.M__SessionIds.read(dis);
        return iRet;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader hdr) {
        hdr.setMessageId(DSMCCClientMessageType.enClient_Session_In_Progress.getMessageType());
        super.setHeader(hdr);
    }

}
