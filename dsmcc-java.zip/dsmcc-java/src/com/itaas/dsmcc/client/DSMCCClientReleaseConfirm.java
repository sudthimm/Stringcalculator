/*
 * DSMCCClientReleaseConfirm.java Created on July 8, 2003, 4:38 PM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;

/**
 *This is the message sent from the Network to a client in response to a clientReleaseRequest. This Message
 * falls under the group:Session Release Reference:section-4.2.5.2 of ISA Specification
 * 
 * @author chintan Desai
 */
public class DSMCCClientReleaseConfirm extends DSMCCMessage {

    protected DSMCCSessionID m__SessionId;

    protected int m__Response;

    protected DSMCCUserData m__UserData;

    static final int FixedPayloadSize = 12;

    // Constructor
    public DSMCCClientReleaseConfirm(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
        this.m__UserData = new DSMCCUserData();
    }

    public DSMCCClientReleaseConfirm(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int response, final DSMCCUserData userData) {
        this.m__SessionId = session;
        this.m__Response = response;
        this.m__UserData = userData;

        this.setHeader(hdr);

    }

    public DSMCCSessionID getSessionId() {
        return this.m__SessionId;
    }

    public void setSessionId(final DSMCCSessionID sessionId) {
        this.m__SessionId = sessionId;
    }

    public int getResponse() {
        return this.m__Response;
    }

    public void setResponse(final int response) {
        this.m__Response = response;

    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientReleaseConfirm Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCClientReleaseConfirm msg = new DSMCCClientReleaseConfirm(hdr);
        msg.read(is);

        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader hdr) {
        hdr.setMessageId(DSMCCClientMessageType.enClient_Release_Confirm.getMessageType());
        super.setHeader(hdr);
    }

}
