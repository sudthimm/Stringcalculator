/*
 * DSMCCClientSessionSetUpConfirm.java Created on July 8, 2003, 3:21 PM
 */

package com.itaas.dsmcc.client;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCObject;
import com.itaas.dsmcc.base.DSMCCSessionID;
import com.itaas.dsmcc.base.DSMCCUserData;
import com.itaas.dsmcc.message.client.DSMCCClientMessageType;
import com.itaas.dsmcc.resources.DSMCCResourceDescriptorContainer;

/**
 *This is the message sent from the Network to the Client in response to a ClientSessionRequest message. This
 * Message falls under the group:Session Set-up Reference:section-4.2.4.2 of ISA Specification
 * 
 * @author chintan Desai
 */

public class DSMCCClientSessionSetUpConfirm extends DSMCCMessage {

    static final int FixedPayloadSize = 32;

    protected DSMCCSessionID m__SessionID;

    protected int m__ResponseCode;

    protected DSMCCNsapAddress m__ServerId;

    protected DSMCCResourceDescriptorContainer m__Resources;

    protected DSMCCUserData m__UserData;

    public DSMCCClientSessionSetUpConfirm(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);
        this.m__UserData = new DSMCCUserData();

    }

    public DSMCCClientSessionSetUpConfirm(final DSMCCMessageCommonHeader hdr, final DSMCCSessionID session,
            final int response, final DSMCCNsapAddress serverId, final DSMCCResourceDescriptorContainer resources,
            final DSMCCUserData userData) {
        this.m__SessionID = session;
        this.m__ResponseCode = response;
        this.m__ServerId = serverId;
        this.m__Resources = resources;
        this.m__UserData = userData;

        this.setHeader(hdr);
    }

    public DSMCCSessionID getSessionID() {

        return this.m__SessionID;
    }

    public void setSessionID(final DSMCCSessionID sessionID) {
        this.m__SessionID = sessionID;
    }

    public int getResponseCode() {
        return this.m__ResponseCode;
    }

    public void setResponseCode(final int response) {
        this.m__ResponseCode = response;
    }

    public DSMCCNsapAddress getServerId() {
        return this.m__ServerId;
    }

    public void setServerId(final DSMCCNsapAddress serverId) {
        this.m__ServerId = serverId;
    }

    public DSMCCResourceDescriptorContainer getResources() {
        return this.m__Resources;
    }

    public void setResources(final DSMCCResourceDescriptorContainer resources) {
        this.m__Resources = resources;
    }

    public DSMCCUserData getUserData() {
        return this.m__UserData;
    }

    public void setUserData(final DSMCCUserData userData) {
        this.m__UserData = userData;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public static DSMCCClientSessionSetUpConfirm Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCClientSessionSetUpConfirm msg = new DSMCCClientSessionSetUpConfirm(hdr);
        msg.read(is);
        return msg;
    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader hdr) {
        hdr.setMessageId(DSMCCClientMessageType.enClient_Session_Setup_Confirm.getMessageType());
        super.setHeader(hdr);
    }
    
    public String toString() {
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);
        writer.println("class: " +  this.getClass().getName());
        writer.println("m__SessionID: " + m__SessionID);
        writer.flush();
        return stringWriter.toString();
    }

}
