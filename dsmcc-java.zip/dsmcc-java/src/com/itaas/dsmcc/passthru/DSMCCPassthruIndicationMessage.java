/*
 * Created on Feb 3, 2005 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */
package com.itaas.dsmcc.passthru;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCMessage;
import com.itaas.dsmcc.base.DSMCCMessageCommonHeader;
import com.itaas.dsmcc.base.DSMCCNsapAddress;
import com.itaas.dsmcc.base.DSMCCType;

/**
 * @author krishna TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class DSMCCPassthruIndicationMessage extends DSMCCMessage {

    public static final int DSMCCPassthruIndication = 0x0002;

    protected DSMCCNsapAddress m__UserId;

    protected int m__PassthruType;

    protected DSMCCPassthruData M__PassthruData;

    static final int FixedPayloadSize = 22;

    public DSMCCPassthruIndicationMessage(final DSMCCMessageCommonHeader hdr) {
        this.setHeader(hdr);

    }

    public DSMCCNsapAddress getUserId() {
        return this.m__UserId;
    }

    public void setUserId(final DSMCCNsapAddress userId) {
        this.m__UserId = userId;
    }

    public int getPassthruType() {
        return this.m__PassthruType;
    }

    public DSMCCPassthruData getPassthruData() {
        return this.M__PassthruData;
    }

    public void setPassthruData(final DSMCCPassthruData passthruData) {
        this.M__PassthruData = passthruData;
    }

    public void setPassthruType(final int passthruType) {
        this.m__PassthruType = passthruType;
    }

    public short GetPayloadLength() {
        return (short) this.getLength();
    }

    public int readPassthruData(final DSMCCInputStream is) throws IOException {
        int iRead = 0;
        this.M__PassthruData = DSMCCPassthruData.Create(is, this.m__PassthruType);
        iRead = this.M__PassthruData.read(is);

        return iRead;
    }

    public static DSMCCPassthruIndicationMessage Create(final DSMCCInputStream is, final DSMCCMessageCommonHeader hdr)
            throws IOException {
        final DSMCCPassthruIndicationMessage msg = new DSMCCPassthruIndicationMessage(hdr);

        msg.read(is);

        return msg;

    }

    @Override
    public void setHeader(final DSMCCMessageCommonHeader valHeader) {
        valHeader.setDsmccType(DSMCCType.enPassthru);
        valHeader.setMessageId(DSMCCPassthruIndicationMessage.DSMCCPassthruIndication);
        super.setHeader(valHeader);
    }

}
