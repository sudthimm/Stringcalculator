/*
 * Created on Feb 3, 2005 TODO To change the template for this generated file go to Window - Preferences -
 * Java - Code Style - Code Templates
 */
package com.itaas.dsmcc.passthru;

import java.io.IOException;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCObject;

/**
 * @author krishna TODO To change the template for this generated type comment go to Window - Preferences -
 *         Java - Code Style - Code Templates
 */
public class DSMCCPassthruData extends DSMCCObject {

    public static final int MMMMessage = 0x8001;

    public static DSMCCPassthruData Create(final DSMCCInputStream is, final int messageType) throws IOException {
        final DSMCCPassthruData passthruData = null;
        switch (messageType) {
            case MMMMessage:

                // passthruData = new com.itaas.dncs.messages.MMMMessage.MMMMessage(is);

                break;
        }

        return passthruData;

    }

}
