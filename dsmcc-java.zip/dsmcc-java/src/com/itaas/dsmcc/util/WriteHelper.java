// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date Sept 26, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.util;

import java.io.IOException;

import com.itaas.dsmcc.base.ByteArray;
import com.itaas.dsmcc.base.DSMCCOutputStream;

public class WriteHelper {

    public static int Write(final ByteArray bytes, final DSMCCOutputStream os) throws IOException {
        if (bytes != null) {
            bytes.write(os);
            return bytes.getLength();
        } else {
            return 0;
        }

    }
    /*
     * public int Write(DSMCCMessageCommonHeader hdr)throws IOException { if ( hdr == null) { hdr = new
     * DSMCCMessageCommonHeader(); } return hdr.write(this); } public int Write(DSMCCSessionID
     * msessionId)throws IOException { if(msessionId == null) { msessionId = new DSMCCSessionID(); }
     * msessionId.write(this); } public int Write(DSMCCNsapAddr clientId)throws IOException { if(clientId ==
     * null) { clientId = new DSMCCSessionID(); } clientId.write(this); } public int Write(DSMCCUserData
     * ud)throws IOException { if(ud == null) { ud = new DSMCCUserData(); } ud.write(this); }
     */
}
