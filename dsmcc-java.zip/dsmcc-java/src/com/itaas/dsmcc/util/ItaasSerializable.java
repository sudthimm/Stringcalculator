// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 17, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.util;

import java.io.IOException;
import java.io.PrintStream;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCOutputStream;

public interface ItaasSerializable extends Dumpable {

    public int read(DSMCCInputStream dis) throws IOException;

    public int write(DSMCCOutputStream dos) throws IOException;

    public void dump(PrintStream pw) throws IOException;

    public int getLength();
}
