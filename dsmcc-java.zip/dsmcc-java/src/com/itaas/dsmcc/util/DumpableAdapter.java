// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 17, 2003
// /////////////////////////////////////////////////////////////////////////////

package com.itaas.dsmcc.util;

import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.itaas.dsmcc.base.DSMCCInputStream;
import com.itaas.dsmcc.base.DSMCCOutputStream;

public abstract class DumpableAdapter implements ItaasSerializable {

    PrintStream m_ps;

    String m_strIndent;

    /** Convenience members to avoid 1.5 Compiler complaints */
    private static final Class[] nullClassArray = null;

    private static final Object[] nullObjArray = null;

    public DumpableAdapter() {
        this.m_strIndent = "";
    }

    public void setPrintWriter(final PrintStream ps) {
        this.m_ps = ps;
        this.m_strIndent = "";
    }

    public void dump(final Object target) {

        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();
        this.m_ps.println(objClass.toString());
        final int iLen = fields.length;
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            try {
                final Field fld = fields[iCnt];
                final Class fldClass = fld.getType();
                final String classname = fldClass.toString();
                final String name = fld.getName();
                final String methodName = "get" + name.substring(3);
                if (name.startsWith("m__")) {
                    final Method method = objClass.getMethod(methodName, DumpableAdapter.nullClassArray);
                    final Object ret = method.invoke(target, DumpableAdapter.nullObjArray);
                    final String val;
                    if (ret != null) {
                        if (ret instanceof DumpableAdapter) {
                            this.dump(ret);
                        } else {
                            this.m_ps.println(name + ":" + ret.toString());
                        }
                    } else {
                        // m_ps.println(fldClass.toString() + ":" + name + ":" + null );
                    }
                }
            } catch (final Exception ex) {
                ex.printStackTrace(this.m_ps);
            }
        }
    }

    public void dump(final PrintStream ps) throws IOException {
        this.setPrintWriter(ps);
        this.dump(this);
    }

    public int _read(final DSMCCInputStream dis) throws IOException {
        final Object target = this;
        int iRet = 0;
        final Class objClass = target.getClass();
        final Field fields[] = objClass.getDeclaredFields();
        this.m_ps.println(objClass.toString());
        final int iLen = fields.length;
        final Object[] args = new Object[1];
        final Class[] parameters = new Class[1];
        for (int iCnt = 0; iCnt < iLen; iCnt++) {
            try {
                final Field fld = fields[iCnt];
                final Class fldClass = fld.getType();
                final String name = fld.getName();
                final String methodName = "set" + name.substring(3);
                if (name.startsWith("m__")) {
                    Method method = null;
                    if (fldClass.toString().equals("Integer")) {
                        final int iRead = dis.readInt();
                        final Integer Read = new Integer(iRead);
                        parameters[0] = Read.getClass();
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = Read;
                        iRet += 4;
                    } else if (fldClass.toString().equals("Byte")) {
                        final byte bRead = dis.readByte();
                        final Byte Read = new Byte(bRead);
                        parameters[0] = Read.getClass();
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = Read;
                        iRet += 1;
                    } else if (fldClass.toString().equals("Short")) {
                        final short sRead = dis.readShort();
                        final Short Read = new Short(sRead);
                        parameters[0] = Read.getClass();
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = Read;
                        iRet += 2;
                    } else {
                        final DumpableAdapter oRead = (DumpableAdapter) Class.forName(fldClass.toString())
                                .newInstance();
                        iRet += oRead.read(dis);
                        parameters[0] = oRead.getClass();
                        method = objClass.getMethod(methodName, parameters);
                        args[0] = oRead;
                    }
                    final Object ret = method.invoke(target, args);
                }
            } catch (final Exception ex) {
                ex.printStackTrace(this.m_ps);
            }
        }
        return iRet;
    }

    public int _write(final DSMCCOutputStream dos) throws IOException {
        final int iRet = 0;
        return iRet;
    }

    public int write(final DSMCCOutputStream dos) throws IOException {
        final int iRet = 0;
        return iRet;
    }

    public int read(final DSMCCInputStream dis) throws IOException {
        final int iRet = 0;
        return iRet;
    }
}
