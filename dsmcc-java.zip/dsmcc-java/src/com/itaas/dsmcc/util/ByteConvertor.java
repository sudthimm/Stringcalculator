// //////////////////////////////////////////////////////////////////////////////
//
// Copyright 2003, iTaas Inc
// 
//
// Created by Krishna C Tripathi
// Date June 12, 2003
// /////////////////////////////////////////////////////////////////////////////
package com.itaas.dsmcc.util;

public class ByteConvertor {

    private static final String hexChars = "0123456789ABCDEF";

    // returns byte[1]
    public static byte[] toByteArrayFromUnsignedByte(final short val) {
        return ByteConvertor.toByteArray(val, new byte[1]);
    }

    // returns byte[2]
    public static byte[] toByteArrayFromUnsignedShort(final int val) {
        return ByteConvertor.toByteArray(val, new byte[2]);
    }

    // returns byte[4]
    public static byte[] toByteArrayFromUnsignedInt(final long val) {
        return ByteConvertor.toByteArray(val, new byte[4]);
    }

    // returns byte[2]
    public static byte[] toByteArray(final short val) {
        return ByteConvertor.toByteArray(val, new byte[2]);
    }

    // returns byte[4]
    public static byte[] toByteArray(final int val) {
        return ByteConvertor.toByteArray(val, new byte[4]);
    }

    // returns byte[8]
    public static byte[] toByteArray(final long val) {
        return ByteConvertor.toByteArray(val, new byte[8]);
    }

    private static byte[] toByteArray(final long val, final byte[] array) {
        long ll = val;
        long lr = 0;
        for (int iInd = 1; iInd < (array.length + 1); ++iInd) {
            lr = ll & 0xFF;
            array[(array.length - iInd)] = (byte) lr;
            ll = ll >>> 8;
        }
        return array;
    }

    // expects byte[1]
    public static short fromByteArrayToUnsignedByte(final byte[] array) {
        final int i0 = array[0] & 0xFF;
        final short shRet = (short) (i0);
        return shRet;
    }

    // expects byte[2]
    public static int fromByteArrayToUnsignedShort(final byte[] array) {
        final int iRet = ((array[0] & 0xFF) << 8) | ((array[0] & 0xFF));
        return iRet;
    }

    // expects byte[4]
    public static long fromByteArrayToUnsignedInt(final byte[] array) {
        final long lRet1 = ((long) (array[0] & 0xFF) << 24) | ((array[1] & 0xFF) << 16) | ((array[2] & 0xFF) << 8)
                | ((array[3] & 0xFF));
        return lRet1;
    }

    // expects byte[2]
    public static short fromByteArrayToShort(final byte[] array) {
        final int i0 = array[0] & 0xFF;
        final int i1 = array[1] & 0xFF;
        final short shRet = (short) (i0 << 8 | i1);
        return shRet;
    }

    // expects byte[4]
    public static int fromByteArrayToInt(final byte[] array) {
        final int iRet = ((array[0] & 0xFF) << 24) | ((array[1] & 0xFF) << 16) | ((array[2] & 0xFF) << 8)
                | ((array[3] & 0xFF));
        return iRet;
    }

    // expects byte[8]
    public static long fromByteArrayToLong(final byte[] array) {
        final long lRet1 = ((long) (array[0] & 0xFF) << 24) | ((array[1] & 0xFF) << 16) | ((array[2] & 0xFF) << 8)
                | ((array[3] & 0xFF));

        long lRet2 = 0;
        long lRet = 0;
        if (array.length == 8) {
            lRet2 = ((long) (array[4] & 0xFF) << 24) | ((array[5] & 0xFF) << 16) | ((array[6] & 0xFF) << 8)
                    | ((array[7] & 0xFF));
            lRet = ((lRet1 << 32) | (lRet2));
        } else {
            lRet = lRet1;
        }
        return (lRet);

    }

    /**
     * Converts a byte array into a set of hex values stored in a String. The values are not delimited. Each
     * hex value is made up of two characters.
     * 
     * @param bytes
     *            the byte array to be converted.
     * @return hex representation of the bytes.
     */
    public static String toHex(final byte[] bytes) {
        final char[] chars = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int iByte = 0;
            if (bytes[i] >= 0) {
                iByte = bytes[i];
            } else {
                iByte = 256 + bytes[i];
            }
            chars[i * 2 + 1] = ByteConvertor.hexChars.charAt(iByte & 0x000F);
            chars[i * 2] = ByteConvertor.hexChars.charAt((iByte & 0x00F0) >>> 4);
        }
        return new String(chars);
    }

    /**
     * Converts a byte array into a set of hex values stored in a String. String. The values are delimited by
     * single spaces. Each hex value is made up of two characters.
     * 
     * @param bytes
     *            the byte array to be converted.
     * @return hex representation of the bytes.
     */
    public static String toHexWithSpaces(final byte[] bytes, final int offset, final int length) {
        return ByteConvertor.toHexWithDelim(bytes, ' ', offset, length);
    }

    public static String toHexWithDelim(final byte[] bytes, final char delim, final int offset, int length) {
        if (length < 0) {
            length = bytes.length;
        }
        if (offset + length > bytes.length) {
            length = bytes.length - offset;
        }

        char[] chars = new char[length * 3 - 1];
        for (int i = 0; i < (length); i++) {
            int iByte = 0;
            if (bytes[i + offset] >= 0) {
                iByte = bytes[i + offset];
            } else {
                iByte = 256 + bytes[i + offset];
            }

            chars[i * 3 + 1] = ByteConvertor.hexChars.charAt(iByte & 0x000F);
            chars[i * 3] = ByteConvertor.hexChars.charAt((iByte & 0x00F0) >>> 4);
            if (i != (length - 1)) {
                chars[i * 3 + 2] = delim;
            }
        }
        final String ret = new String(chars);
        chars = null;
        return ret;
    }

    public static void main(final String[] args) {
        byte bTest = (byte) 0x7E;
        for (int iCnt = 0; iCnt < 4; iCnt++) {
            System.out.print("bTest = " + bTest);
            bTest++;
            System.out.println("");
        }

        short sTest = (short) 0x7FFE;
        for (int iCnt = 0; iCnt < 4; iCnt++) {
            System.out.print("sTest = " + sTest);
            final byte[] bytes = ByteConvertor.toByteArray(sTest);
            System.out.print("\t" + ByteConvertor.toHex(bytes));
            System.out.print("\t" + ByteConvertor.fromByteArrayToShort(bytes));
            sTest++;
            System.out.println("");
        }

        int iTest = 0x7FFFFFFE;
        for (int iCnt = 0; iCnt < 4; iCnt++) {
            System.out.print("iTest = " + iTest);
            final byte[] bytes = ByteConvertor.toByteArray(iTest);
            System.out.print("\t" + ByteConvertor.toHex(bytes));
            System.out.print("\t" + ByteConvertor.fromByteArrayToInt(bytes));
            iTest++;
            System.out.println("");
        }

        long lTest = 0x7FFFFFFFFFFFFFFEL;
        for (int iCnt = 0; iCnt < 4; iCnt++) {
            System.out.print("iTest = " + lTest);
            final byte[] bytes = ByteConvertor.toByteArray(lTest);
            System.out.print("\t" + ByteConvertor.toHex(bytes));
            System.out.print("\t" + ByteConvertor.fromByteArrayToLong(bytes));
            lTest++;
            System.out.println("");
        }
    }

}
